use std::cell::{Cell, RefCell};
use std::collections::{HashMap, HashSet};
use std::rc::Rc;

use gtk::prelude::*;
use gtk4 as gtk;

use crate::db::{Album, Folder, SidebarCounts};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SidebarFilter {
    Library,
    All,
    Favorites,
    RecentlyAdded,
    History,
    Albums,
    Folder(i64),
    Album(i64),
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum FolderDisplayMode {
    Tree,
    ImportedOnly,
}

impl FolderDisplayMode {
    pub fn from_setting(value: Option<&str>) -> Self {
        match value {
            Some("imported-only") => Self::ImportedOnly,
            _ => Self::Tree,
        }
    }

    pub fn setting_value(self) -> &'static str {
        match self {
            Self::Tree => "tree",
            Self::ImportedOnly => "imported-only",
        }
    }
}

pub const FOLDER_DISPLAY_MODE_SETTING_KEY: &str = "folder-display-mode";
pub const LIBRARY_VISIBLE_SETTING_KEY: &str = "sidebar-library-visible";
pub const ALBUMS_VISIBLE_SETTING_KEY: &str = "sidebar-albums-visible";
pub const FOLDERS_VISIBLE_SETTING_KEY: &str = "sidebar-folders-visible";
pub const NETWORK_SHARES_VISIBLE_SETTING_KEY: &str = "sidebar-network-shares-visible";
pub const ALL_PHOTOS_VISIBLE_SETTING_KEY: &str = "sidebar-all-photos-visible";
pub const FAVOURITES_VISIBLE_SETTING_KEY: &str = "sidebar-favourites-visible";
pub const RECENTLY_ADDED_VISIBLE_SETTING_KEY: &str = "sidebar-recently-added-visible";

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct SidebarVisibility {
    pub library: bool,
    pub albums: bool,
    pub folders: bool,
    pub network_shares: bool,
    pub all_photos: bool,
    pub favourites: bool,
    pub recently_added: bool,
}

impl Default for SidebarVisibility {
    fn default() -> Self {
        Self {
            library: true,
            albums: true,
            folders: true,
            network_shares: true,
            all_photos: true,
            favourites: true,
            recently_added: true,
        }
    }
}

impl SidebarVisibility {
    pub fn from_connection(connection: &rusqlite::Connection) -> Self {
        fn visible(connection: &rusqlite::Connection, key: &str) -> bool {
            crate::db::setting(connection, key)
                .ok()
                .flatten()
                .as_deref()
                != Some("false")
        }

        Self {
            library: visible(connection, LIBRARY_VISIBLE_SETTING_KEY),
            albums: visible(connection, ALBUMS_VISIBLE_SETTING_KEY),
            folders: visible(connection, FOLDERS_VISIBLE_SETTING_KEY),
            network_shares: visible(connection, NETWORK_SHARES_VISIBLE_SETTING_KEY),
            all_photos: visible(connection, ALL_PHOTOS_VISIBLE_SETTING_KEY),
            favourites: visible(connection, FAVOURITES_VISIBLE_SETTING_KEY),
            recently_added: visible(connection, RECENTLY_ADDED_VISIBLE_SETTING_KEY),
        }
    }
}

#[derive(Debug)]
struct SidebarState {
    library_expanded: bool,
    albums_expanded: bool,
    folders_expanded: bool,
    expanded_folders: HashSet<i64>,
    folder_display_mode: FolderDisplayMode,
    network_tree_mode: bool,
    pinned: Cell<bool>,
    hover_open: Cell<bool>,
}

impl Default for SidebarState {
    fn default() -> Self {
        Self {
            library_expanded: true,
            albums_expanded: true,
            folders_expanded: true,
            expanded_folders: HashSet::new(),
            folder_display_mode: FolderDisplayMode::Tree,
            network_tree_mode: true,
            pinned: Cell::new(true),
            hover_open: Cell::new(false),
        }
    }
}

const STATE_KEY: &str = "picasa-sidebar-state";
const LIBRARY_LIST_KEY: &str = "picasa-sidebar-library-list";
const LIBRARY_HEADING_KEY: &str = "picasa-sidebar-library-heading";
const LIBRARY_REVEALER_KEY: &str = "picasa-sidebar-library-revealer";
const LIBRARY_INDICATOR_KEY: &str = "picasa-sidebar-library-indicator";
const ALBUM_LIST_KEY: &str = "picasa-sidebar-album-list";
const ALBUM_HEADING_KEY: &str = "picasa-sidebar-album-heading";
const ALBUM_REVEALER_KEY: &str = "picasa-sidebar-album-revealer";
const ALBUM_INDICATOR_KEY: &str = "picasa-sidebar-album-indicator";
const FOLDER_LIST_KEY: &str = "picasa-sidebar-folder-list";
const FOLDER_HEADING_KEY: &str = "picasa-sidebar-folder-heading";
const FOLDER_SCROLL_KEY: &str = "picasa-sidebar-folder-scroll";
const FOLDER_REVEALER_KEY: &str = "picasa-sidebar-folder-revealer";
const FOLDER_INDICATOR_KEY: &str = "picasa-sidebar-folder-indicator";
const CURRENT_FILTER_KEY: &str = "picasa-sidebar-current-filter";
const VISIBILITY_KEY: &str = "picasa-sidebar-visibility";
const SECTION_PANED_KEY: &str = "picasa-sidebar-section-paned";
const FOLDER_SECTION_KEY: &str = "picasa-sidebar-folder-section";
const SHARE_SECTION_KEY: &str = "picasa-sidebar-share-section";
const FILTER_SYNCING_KEY: &str = "picasa-sidebar-filter-syncing";
const FILTER_COUNT_LABEL_KEY: &str = "picasa-sidebar-filter-count-label";
const FOLDER_REFRESH_KEY: &str = "picasa-sidebar-folder-refresh";
const REFRESH_GATE_KEY: &str = "picasa-sidebar-refresh-gate";
const ALBUM_PANE_ANIMATION_MS: u32 = 250;
const STARTUP_VISIBLE_ALBUM_ROWS: usize = 5;

/// Share the window's refresh sensitivity with existing and future menus.
pub fn bind_refresh_gate(scrolled: &gtk::ScrolledWindow, gate: &gtk::Button) {
    for key in [FOLDER_LIST_KEY, SHARE_LIST_KEY] {
        if let Some(list) = stored_widget::<gtk::ListBox>(scrolled, key) {
            unsafe {
                list.set_data(REFRESH_GATE_KEY, gate.downgrade());
            }
        }
    }
}
const FOLDER_STATISTICS_KEY: &str = "picasa-sidebar-folder-statistics";
const FOLDER_REMOVE_KEY: &str = "picasa-sidebar-folder-remove";
const FOLDER_FAVORITE_KEY: &str = "picasa-sidebar-folder-favorite";
const FOLDER_WATCH_KEY: &str = "picasa-sidebar-folder-watch";
const FOLDER_MODE_TOGGLE_KEY: &str = "picasa-sidebar-folder-mode-toggle";
const SHARE_MODE_TOGGLE_KEY: &str = "picasa-sidebar-share-mode-toggle";
const FOLDER_MODE_CHANGED_KEY: &str = "picasa-sidebar-folder-mode-changed";
const FOLDER_SHARE_PANED_KEY: &str = "picasa-sidebar-folder-share-paned";
const FOLDER_PANE_SAVED_KEY: &str = "picasa-sidebar-folder-pane-saved";
const SHARE_LIST_KEY: &str = "picasa-sidebar-share-list";
const KEYBOARD_GRID_TARGET_KEY: &str = "picasa-sidebar-keyboard-grid-target";
const SCROLL_LOCATION_FOLDER_KEY: &str = "picasa-sidebar-scroll-location-folder";

thread_local! {
    // Guards the coalesced idle pass that follows the Folder scroll position.
    static SCROLL_LOCATION_SCHEDULED: Cell<bool> = const { Cell::new(false) };
}

pub fn build(
    folders: &[Folder],
    albums: &[Album],
    counts: SidebarCounts,
    on_filter: impl Fn(SidebarFilter) + 'static,
    on_create_album: Rc<dyn Fn()>,
    on_import_folder: Rc<dyn Fn()>,
    on_add_share: Rc<dyn Fn()>,
    on_delete_album: Rc<dyn Fn(i64)>,
    on_unavailable: Rc<dyn Fn()>,
    on_refresh_folder: Rc<dyn Fn(String)>,
    on_folder_statistics: Rc<dyn Fn(Folder)>,
    on_remove_folder: Rc<dyn Fn(Folder)>,
    on_folder_favorite: Rc<dyn Fn(Folder, bool)>,
    on_folder_watch: Rc<dyn Fn(Folder, bool)>,
    folder_display_mode: FolderDisplayMode,
    on_folder_display_mode_changed: Rc<dyn Fn(FolderDisplayMode)>,
    visibility: SidebarVisibility,
) -> gtk::ScrolledWindow {
    let on_filter: Rc<dyn Fn(SidebarFilter)> = Rc::new(on_filter);
    let mut initial_state = SidebarState::default();
    initial_state.folder_display_mode = folder_display_mode;
    let state = Rc::new(RefCell::new(initial_state));
    let filter_syncing = Rc::new(Cell::new(false));

    // Keep the public return type exactly as before because window/build.rs,
    // window/availability.rs and window/albums.rs all store this as a
    // GtkScrolledWindow. The outer scroller itself never scrolls; only the
    // dedicated folder scroller below is allowed to scroll.
    let outer = gtk::ScrolledWindow::new();
    outer.set_policy(gtk::PolicyType::Never, gtk::PolicyType::Never);
    outer.set_hexpand(true);
    outer.set_vexpand(true);
    outer.add_css_class("navigation-sidebar");

    let root = gtk::Box::new(gtk::Orientation::Vertical, 0);
    root.set_hexpand(true);
    root.set_vexpand(true);
    root.set_margin_start(10);
    root.set_margin_end(10);
    root.set_margin_top(4);
    root.set_margin_bottom(12);

    // LIBRARY: collapsible.
    let (library_heading, library_indicator) = collapsible_heading(
        "Library",
        None,
        "",
        true,
        Some({
            let on_filter = on_filter.clone();
            Rc::new(move || on_filter(SidebarFilter::Library))
        }),
    );
    root.append(&library_heading);

    let library_list = section_list();
    populate_library(&library_list, counts, &on_unavailable);
    connect_filter_list(&library_list, on_filter.clone(), filter_syncing.clone());
    let library_revealer = gtk::Revealer::new();
    library_revealer.set_transition_type(gtk::RevealerTransitionType::SlideDown);
    library_revealer.set_reveal_child(true);
    library_revealer.set_child(Some(&library_list));
    root.append(&library_revealer);

    {
        let state = state.clone();
        let revealer = library_revealer.clone();
        let indicator = library_indicator.clone();
        library_indicator.connect_clicked(move |_| {
            let expanded = !state.borrow().library_expanded;
            state.borrow_mut().library_expanded = expanded;
            revealer.set_reveal_child(expanded);
            indicator.set_icon_name(if expanded {
                "pan-down-symbolic"
            } else {
                "pan-end-symbolic"
            });
        });
    }

    // ALBUMS + FOLDERS: use GTK's native vertical split control. GtkPaned
    // owns pointer tracking and allocation while the divider is dragged, which
    // avoids the feedback loop caused by resizing a widget underneath a
    // GestureDrag attached to that same moving divider.
    //
    // The Albums heading stays outside the paned. The Folders heading lives at
    // the top of the end pane, so it always follows Albums directly instead of
    // becoming bottom-anchored when the folder rows are collapsed.
    let (album_heading, album_indicator) = collapsible_heading(
        "Albums",
        Some(on_create_album.clone()),
        "Create album",
        true,
        Some({
            let on_filter = on_filter.clone();
            Rc::new(move || on_filter(SidebarFilter::Albums))
        }),
    );
    album_heading.add_css_class("sidebar-sticky-heading");
    root.append(&album_heading);

    let album_list = section_list();
    connect_filter_list(&album_list, on_filter.clone(), filter_syncing.clone());

    let album_scroll = gtk::ScrolledWindow::new();
    album_scroll.set_policy(gtk::PolicyType::Never, gtk::PolicyType::Automatic);
    album_scroll.set_hexpand(true);
    album_scroll.set_vexpand(true);
    // This caps only the initial/natural request. GtkPaned may allocate more
    // when the user drags its native handle, while a short album list still
    // opens at its natural height without a large empty block.
    album_scroll.set_propagate_natural_height(true);
    album_scroll.set_max_content_height(260);
    album_scroll.set_child(Some(&album_list));

    let album_revealer = gtk::Revealer::new();
    album_revealer.set_transition_type(gtk::RevealerTransitionType::SlideDown);
    album_revealer.set_reveal_child(true);
    album_revealer.set_hexpand(true);
    album_revealer.set_vexpand(true);
    album_revealer.set_child(Some(&album_scroll));

    let (folder_heading, folder_indicator) = collapsible_heading(
        "Folders",
        Some(on_import_folder.clone()),
        "Import Folder",
        true,
        None,
    );
    folder_heading.add_css_class("sidebar-sticky-heading");

    let folder_mode_toggle = gtk::Button::from_icon_name(match folder_display_mode {
        FolderDisplayMode::Tree => "folder-symbolic",
        FolderDisplayMode::ImportedOnly => "view-list-symbolic",
    });
    folder_mode_toggle.add_css_class("flat");
    folder_mode_toggle.set_focusable(false);
    folder_mode_toggle.set_size_request(24, 24);
    set_folder_mode_toggle_presentation(&folder_mode_toggle, folder_display_mode);
    // Keep heading controls in the same left-to-right order everywhere:
    // section-specific action, add, collapse. For Folders that means
    // folder-mode, +, collapse. The first child is always the heading label.
    if let Some(label) = folder_heading.first_child() {
        folder_heading.insert_child_after(&folder_mode_toggle, Some(&label));
    } else {
        folder_heading.prepend(&folder_mode_toggle);
    }

    let folder_list = section_list();
    connect_filter_list(&folder_list, on_filter.clone(), filter_syncing.clone());

    let folder_scroll = gtk::ScrolledWindow::new();
    folder_scroll.set_policy(gtk::PolicyType::Never, gtk::PolicyType::Automatic);
    folder_scroll.set_hexpand(true);
    folder_scroll.set_vexpand(true);
    folder_scroll.set_child(Some(&folder_list));

    let folder_revealer = gtk::Revealer::new();
    folder_revealer.set_transition_type(gtk::RevealerTransitionType::SlideDown);
    folder_revealer.set_reveal_child(true);
    folder_revealer.set_hexpand(true);
    folder_revealer.set_vexpand(true);
    folder_revealer.set_child(Some(&folder_scroll));

    // Keep the Folders heading in the paned end child. Even with the rows
    // collapsed, the heading remains the end child's minimum visible content,
    // so the native handle cannot drag over or hide it.
    let folder_section = gtk::Box::new(gtk::Orientation::Vertical, 0);
    folder_section.set_hexpand(true);
    folder_section.set_vexpand(true);
    folder_section.append(&folder_heading);
    // folder_revealer is NOT appended here: it becomes the start child of
    // folder_share_paned below. Appending it to this box as well would leave
    // the widget parented here, the paned's set_start_child would be rejected
    // (Gtk-CRITICAL assertion), and the Folders/Network Shares divider would
    // silently disappear.

    // NETWORK SHARES: registered smb:// and nfs:// roots, listed in their own
    // section below Folders so they can never be mistaken for local folders.
    // The section lives inside the existing Folders pane (no new GtkPaned), so
    // the current Albums/Folders resize behaviour is untouched.
    let (share_heading, share_indicator) = collapsible_heading(
        "Network Shares",
        Some(on_add_share.clone()),
        "Add Network Share",
        true,
        None,
    );
    share_heading.add_css_class("sidebar-sticky-heading");
    let share_mode_toggle = gtk::Button::from_icon_name("folder-symbolic");
    share_mode_toggle.add_css_class("flat");
    share_mode_toggle.set_focusable(false);
    share_mode_toggle.set_size_request(24, 24);
    set_share_mode_toggle_presentation(&share_mode_toggle, true);
    if let Some(label) = share_heading.first_child() {
        share_heading.insert_child_after(&share_mode_toggle, Some(&label));
    }
    let share_list = section_list();
    connect_filter_list(&share_list, on_filter.clone(), filter_syncing.clone());
    let share_scroll = gtk::ScrolledWindow::new();
    share_scroll.set_policy(gtk::PolicyType::Never, gtk::PolicyType::Automatic);
    share_scroll.set_hexpand(true);
    share_scroll.set_vexpand(true);
    share_scroll.set_child(Some(&share_list));
    let share_revealer = gtk::Revealer::new();
    share_revealer.set_transition_type(gtk::RevealerTransitionType::SlideDown);
    share_revealer.set_reveal_child(true);
    share_revealer.set_hexpand(true);
    share_revealer.set_vexpand(true);
    share_revealer.set_child(Some(&share_scroll));
    let shares_expanded = Rc::new(Cell::new(true));
    let set_shares_expanded: Rc<dyn Fn(bool)> = {
        let revealer = share_revealer.clone();
        let indicator = share_indicator.clone();
        let expanded = shares_expanded.clone();
        Rc::new(move |now| {
            expanded.set(now);
            revealer.set_reveal_child(now);
            indicator.set_icon_name(if now {
                "pan-down-symbolic"
            } else {
                "pan-end-symbolic"
            });
        })
    };
    {
        let set_expanded = set_shares_expanded.clone();
        let expanded = shares_expanded.clone();
        share_indicator.connect_clicked(move |_| {
            set_expanded(!expanded.get());
        });
    }
    // Right-click the Network Shares heading: Reveal All when collapsed,
    // Collapse All when expanded.
    {
        let set_expanded = set_shares_expanded.clone();
        attach_section_context_menu(
            &share_heading,
            Rc::new({
                let expanded = shares_expanded.clone();
                move || !expanded.get()
            }),
            Rc::new({
                let expanded = shares_expanded.clone();
                move || expanded.get()
            }),
            Rc::new({
                let set_expanded = set_expanded.clone();
                move || set_expanded(true)
            }),
            Rc::new(move || set_expanded(false)),
        );
    }
    {
        let toggle = share_mode_toggle.clone();
        let state = state.clone();
        let sidebar = outer.downgrade();
        let list = share_list.clone();
        let on_unavailable = on_unavailable.clone();
        share_mode_toggle.connect_clicked(move |_| {
            let tree_mode = {
                let mut state = state.borrow_mut();
                state.network_tree_mode = !state.network_tree_mode;
                state.network_tree_mode
            };
            set_share_mode_toggle_presentation(&toggle, tree_mode);
            let Some(sidebar) = sidebar.upgrade() else {
                return;
            };
            let folders = unsafe {
                list.data::<Vec<Folder>>("picasa-folder-cache")
                    .map(|folders| folders.as_ref().clone())
                    .unwrap_or_default()
            };
            refresh_network_shares(&sidebar, &folders, &state, &on_unavailable);
        });
    }
    // Native drag handle between Folders and Network Shares, matching the
    // Albums split: the user can resize both sections with GtkPaned's native
    // divider. The share heading stays in the end pane, so even with the
    // share rows collapsed the handle cannot drag over or hide it.
    let share_section = gtk::Box::new(gtk::Orientation::Vertical, 0);
    share_section.set_hexpand(true);
    share_section.set_vexpand(true);
    share_section.append(&share_heading);
    share_section.append(&share_revealer);
    let folder_share_paned = gtk::Paned::new(gtk::Orientation::Vertical);
    folder_share_paned.add_css_class("sidebar-section-paned");
    folder_share_paned.set_hexpand(true);
    folder_share_paned.set_vexpand(true);
    // Match the Albums split behaviour: the upper pane keeps its size when the
    // window changes and the lower pane absorbs the difference.
    folder_share_paned.set_resize_start_child(false);
    folder_share_paned.set_resize_end_child(true);
    folder_share_paned.set_shrink_start_child(true);
    folder_share_paned.set_shrink_end_child(false);
    folder_share_paned.set_start_child(Some(&folder_revealer));
    folder_share_paned.set_end_child(Some(&share_section));
    folder_section.append(&folder_share_paned);
    // Match Albums: remember the user's last native divider position so
    // collapsing Folders does not throw away their preferred split. 260 is
    // only a pre-layout fallback; once GTK allocates the paned (including the
    // startup placement below) the real position is remembered here.
    let saved_folder_pane_position = Rc::new(Cell::new(260));
    let folder_pane_animating = Rc::new(Cell::new(false));
    let folder_pane_animation_generation = Rc::new(Cell::new(0_u64));
    {
        let state = state.clone();
        let saved_position = saved_folder_pane_position.clone();
        let animating = folder_pane_animating.clone();
        folder_share_paned.connect_position_notify(move |paned| {
            let position = paned.position();
            // Only treat native user dragging as a new saved position. During
            // our collapse/expand animation the pane position changes every
            // frame and must not overwrite the user's preferred split.
            if state.borrow().folders_expanded
                && !animating.get()
                && paned.start_child().is_some()
                && position > 0
            {
                saved_position.set(position);
            }
        });
    }
    folder_revealer.set_transition_duration(ALBUM_PANE_ANIMATION_MS);

    let section_paned = gtk::Paned::new(gtk::Orientation::Vertical);
    section_paned.add_css_class("sidebar-section-paned");
    section_paned.set_hexpand(true);
    section_paned.set_vexpand(true);
    // Preserve the user's Album height when the window itself grows/shrinks;
    // the Folders pane absorbs ordinary window-size changes. The user can still
    // resize both sections directly with GtkPaned's native handle.
    section_paned.set_resize_start_child(false);
    section_paned.set_resize_end_child(true);
    section_paned.set_shrink_start_child(true);
    section_paned.set_shrink_end_child(false);
    section_paned.set_start_child(Some(&album_revealer));
    section_paned.set_end_child(Some(&folder_section));
    root.append(&section_paned);

    // Remember the user's last native divider position so collapsing Albums
    // does not throw away their preferred split. 260 is only a pre-layout
    // fallback; once GTK allocates the paned we remember its real position.
    let saved_album_pane_position = Rc::new(Cell::new(260));
    let album_pane_animating = Rc::new(Cell::new(false));
    let album_pane_animation_generation = Rc::new(Cell::new(0_u64));
    {
        let state = state.clone();
        let saved_position = saved_album_pane_position.clone();
        let animating = album_pane_animating.clone();
        section_paned.connect_position_notify(move |paned| {
            let position = paned.position();
            // Only treat native user dragging as a new saved position. During
            // our collapse/expand animation the pane position changes every
            // frame and must not overwrite the user's preferred split.
            if state.borrow().albums_expanded
                && !animating.get()
                && paned.start_child().is_some()
                && position > 0
            {
                saved_position.set(position);
            }
        });
    }

    // Keep GtkPaned as the only resize mechanism. For section collapse/expand,
    // animate the native pane position over the same duration as GtkRevealer,
    // then detach the Albums pane only after collapse completes. This keeps the
    // native divider future-proof while giving Albums the same smooth motion as
    // the other sidebar sections.
    album_revealer.set_transition_duration(ALBUM_PANE_ANIMATION_MS);

    let set_albums_expanded: Rc<dyn Fn(bool)> = {
        let state = state.clone();
        let paned = section_paned.clone();
        let revealer = album_revealer.clone();
        let indicator = album_indicator.clone();
        let saved_position = saved_album_pane_position.clone();
        let animating = album_pane_animating.clone();
        let animation_generation = album_pane_animation_generation.clone();
        Rc::new(move |expanded| {
            if state.borrow().albums_expanded == expanded {
                return;
            }

            if !expanded && !animating.get() {
                let position = paned.position();
                if position > 0 {
                    saved_position.set(position);
                }
            }

            state.borrow_mut().albums_expanded = expanded;
            indicator.set_icon_name(if expanded {
                "pan-down-symbolic"
            } else {
                "pan-end-symbolic"
            });
            indicator.set_tooltip_text(Some(if expanded { "Collapse" } else { "Expand" }));

            let generation = animation_generation.get().wrapping_add(1);
            animation_generation.set(generation);
            animating.set(true);

            if expanded {
                // Reattach hidden at zero height, then reveal and grow the
                // native pane. If a collapse was interrupted, continue from
                // the current position instead of jumping back to zero.
                let was_detached = paned.start_child().is_none();
                if was_detached {
                    revealer.set_reveal_child(false);
                    paned.set_start_child(Some(&revealer));
                    paned.set_position(0);
                }

                let from = paned.position().max(0);
                revealer.set_reveal_child(true);
                let target = saved_position.get().max(0);
                animate_sidebar_pane_position(
                    &paned,
                    from,
                    target,
                    animation_generation.clone(),
                    generation,
                    animating.clone(),
                    None,
                );
            } else {
                let from = paned.position().max(0);
                revealer.set_reveal_child(false);

                let paned_for_finish = paned.clone();
                let revealer_for_finish = revealer.clone();
                let state_for_finish = state.clone();
                let finish: Rc<dyn Fn()> = Rc::new(move || {
                    if !state_for_finish.borrow().albums_expanded {
                        paned_for_finish.set_start_child(None::<&gtk::Widget>);
                        revealer_for_finish.set_reveal_child(false);
                    }
                });

                animate_sidebar_pane_position(
                    &paned,
                    from,
                    0,
                    animation_generation.clone(),
                    generation,
                    animating.clone(),
                    Some(finish),
                );
            }
        })
    };

    {
        let state = state.clone();
        let set_expanded = set_albums_expanded.clone();
        album_indicator.connect_clicked(move |_| {
            let expanded = !state.borrow().albums_expanded;
            set_expanded(expanded);
        });
    }

    // Double-click anywhere on the Albums heading to collapse/expand.
    {
        let state = state.clone();
        let set_expanded = set_albums_expanded.clone();
        let double_click = gtk::GestureClick::new();
        double_click.set_button(1);
        double_click.set_propagation_phase(gtk::PropagationPhase::Capture);
        double_click.connect_pressed(move |gesture, n_press, _, _| {
            if n_press == 2 {
                let expanded = !state.borrow().albums_expanded;
                set_expanded(expanded);
                gesture.set_state(gtk::EventSequenceState::Claimed);
            }
        });
        album_heading.add_controller(double_click);
    }

    // Right-click the Albums heading: Reveal All when collapsed, Collapse All
    // when expanded. Albums has no nested branches, so the section is the
    // whole scope. Reveal All ignores the divider position: the pane grows to
    // fit every album row instead of returning to the saved bar position.
    {
        let state_for_reveal = state.clone();
        let state_for_collapse = state.clone();
        let set_expanded = set_albums_expanded.clone();
        let album_list_for_reveal = album_list.clone();
        let saved_album_position_for_reveal = saved_album_pane_position.clone();
        attach_section_context_menu(
            &album_heading,
            Rc::new(move || !state_for_reveal.borrow().albums_expanded),
            Rc::new(move || state_for_collapse.borrow().albums_expanded),
            Rc::new({
                let set_expanded = set_expanded.clone();
                move || {
                    // Measure the full album list (works while detached), aim
                    // the pane there, then let the expand animation target it.
                    let desired = list_natural_height_for_rows(&album_list_for_reveal, usize::MAX);
                    if desired > 0 {
                        saved_album_position_for_reveal.set(desired);
                    }
                    set_expanded(true);
                }
            }),
            Rc::new(move || set_expanded(false)),
        );
    }

    let set_folders_expanded: Rc<dyn Fn(bool)> = {
        let state = state.clone();
        let paned = folder_share_paned.clone();
        let revealer = folder_revealer.clone();
        let indicator = folder_indicator.clone();
        let saved_position = saved_folder_pane_position.clone();
        let animating = folder_pane_animating.clone();
        let animation_generation = folder_pane_animation_generation.clone();
        Rc::new(move |expanded| {
            if state.borrow().folders_expanded == expanded {
                return;
            }

            if !expanded && !animating.get() {
                let position = paned.position();
                if position > 0 {
                    saved_position.set(position);
                }
            }

            state.borrow_mut().folders_expanded = expanded;
            indicator.set_icon_name(if expanded {
                "pan-down-symbolic"
            } else {
                "pan-end-symbolic"
            });
            indicator.set_tooltip_text(Some(if expanded { "Collapse" } else { "Expand" }));

            let generation = animation_generation.get().wrapping_add(1);
            animation_generation.set(generation);
            animating.set(true);

            if expanded {
                // Reattach hidden at zero height, then reveal and grow the
                // native pane. If a collapse was interrupted, continue from
                // the current position instead of jumping back to zero.
                let was_detached = paned.start_child().is_none();
                if was_detached {
                    revealer.set_reveal_child(false);
                    paned.set_start_child(Some(&revealer));
                    paned.set_position(0);
                }

                let from = paned.position().max(0);
                revealer.set_reveal_child(true);
                let target = saved_position.get().max(0);
                animate_sidebar_pane_position(
                    &paned,
                    from,
                    target,
                    animation_generation.clone(),
                    generation,
                    animating.clone(),
                    None,
                );
            } else {
                let from = paned.position().max(0);
                revealer.set_reveal_child(false);

                let paned_for_finish = paned.clone();
                let revealer_for_finish = revealer.clone();
                let state_for_finish = state.clone();
                let finish: Rc<dyn Fn()> = Rc::new(move || {
                    if !state_for_finish.borrow().folders_expanded {
                        // Detach the start pane so the divider auto-hides,
                        // exactly like the collapsed Albums pane.
                        paned_for_finish.set_start_child(None::<&gtk::Widget>);
                        revealer_for_finish.set_reveal_child(false);
                    }
                });

                animate_sidebar_pane_position(
                    &paned,
                    from,
                    0,
                    animation_generation.clone(),
                    generation,
                    animating.clone(),
                    Some(finish),
                );
            }
        })
    };

    {
        let state = state.clone();
        let set_expanded = set_folders_expanded.clone();
        folder_indicator.connect_clicked(move |_| {
            let expanded = !state.borrow().folders_expanded;
            set_expanded(expanded);
        });
    }

    // Double-click the Folders heading to collapse/expand the whole tree.
    {
        let state = state.clone();
        let set_expanded = set_folders_expanded.clone();
        let double_click = gtk::GestureClick::new();
        double_click.set_button(1);
        double_click.set_propagation_phase(gtk::PropagationPhase::Capture);
        double_click.connect_pressed(move |gesture, n_press, _, _| {
            if n_press == 2 {
                let expanded = !state.borrow().folders_expanded;
                set_expanded(expanded);
                gesture.set_state(gtk::EventSequenceState::Claimed);
            }
        });
        folder_heading.add_controller(double_click);
    }

    // Right-click the Folders heading: Reveal All expands the section and
    // every nested branch (so all contents are visible without fighting the
    // divider), Collapse All collapses all nested branches. The section itself
    // stays expanded for Collapse All, matching "collapses all nested items".
    {
        let state_for_reveal = state.clone();
        let state_for_collapse = state.clone();
        let state_for_reveal_action = state.clone();
        let state_for_collapse_action = state.clone();
        let list_for_action = folder_list.clone();
        let list_for_reveal_action = folder_list.clone();
        let list_for_visibility = folder_list.clone();
        let list_for_collapse_visibility = folder_list.clone();
        let folder_heading_for_reveal = folder_heading.clone();
        let folder_share_paned_for_reveal = folder_share_paned.clone();
        let saved_folder_pane_position_for_reveal = saved_folder_pane_position.clone();
        let set_expanded = set_folders_expanded.clone();
        let any_collapsed_nested = move |state: &Rc<RefCell<SidebarState>>, list: &gtk::ListBox| {
            let folders = unsafe {
                list.data::<Vec<Folder>>("picasa-folder-cache")
                    .map(|data| data.as_ref().clone())
                    .unwrap_or_default()
            };
            let state = state.borrow();
            folder_ids_with_children(&folders)
                .iter()
                .any(|id| !state.expanded_folders.contains(id))
        };
        let any_expanded_nested = move |state: &Rc<RefCell<SidebarState>>, list: &gtk::ListBox| {
            let folders = unsafe {
                list.data::<Vec<Folder>>("picasa-folder-cache")
                    .map(|data| data.as_ref().clone())
                    .unwrap_or_default()
            };
            let state = state.borrow();
            folder_ids_with_children(&folders)
                .iter()
                .any(|id| state.expanded_folders.contains(id))
        };
        attach_section_context_menu(
            &folder_heading,
            Rc::new(move || {
                let state = state_for_reveal.borrow();
                !state.folders_expanded
                    || any_collapsed_nested(&state_for_reveal, &list_for_visibility)
            }),
            Rc::new(move || {
                let state = state_for_collapse.borrow();
                state.folders_expanded
                    && any_expanded_nested(&state_for_collapse, &list_for_collapse_visibility)
            }),
            Rc::new(move || {
                set_folders_expanded(true);
                {
                    let mut state = state_for_reveal_action.borrow_mut();
                    let folders = unsafe {
                        list_for_reveal_action
                            .data::<Vec<Folder>>("picasa-folder-cache")
                            .map(|data| data.as_ref().clone())
                            .unwrap_or_default()
                    };
                    for id in folder_ids_with_children(&folders) {
                        state.expanded_folders.insert(id);
                    }
                }
                rebuild_folder_list_from_rows(&list_for_reveal_action, &state_for_reveal_action);
                // Reveal All ignores the divider position: grow the pane so
                // every revealed row is visible instead of clipped under the
                // saved (possibly dragged-up) bar position.
                let desired = list_natural_height_for_rows(&list_for_reveal_action, usize::MAX)
                    + folder_heading_for_reveal.height();
                if desired > 0 {
                    saved_folder_pane_position_for_reveal.set(desired);
                    folder_share_paned_for_reveal.set_position(desired);
                }
            }),
            Rc::new(move || {
                state_for_collapse_action
                    .borrow_mut()
                    .expanded_folders
                    .clear();
                rebuild_folder_list_from_rows(&list_for_action, &state_for_collapse_action);
            }),
        );
    }

    {
        let list = folder_list.clone();
        let state = state.clone();
        let toggle = folder_mode_toggle.clone();
        let on_folder_display_mode_changed = on_folder_display_mode_changed.clone();
        folder_mode_toggle.connect_clicked(move |_| {
            let new_mode = {
                let mut state = state.borrow_mut();
                state.folder_display_mode = match state.folder_display_mode {
                    FolderDisplayMode::Tree => FolderDisplayMode::ImportedOnly,
                    FolderDisplayMode::ImportedOnly => FolderDisplayMode::Tree,
                };
                state.folder_display_mode
            };
            set_folder_mode_toggle_presentation(&toggle, new_mode);
            rebuild_folder_list_from_rows(&list, &state);
            on_folder_display_mode_changed(new_mode);
        });
    }

    // Folder rows install their context menu while they are created, so these
    // callbacks must be available on the ListBox before populate_folders().
    unsafe {
        folder_list.set_data(FOLDER_REFRESH_KEY, on_refresh_folder.clone());
        folder_list.set_data(FOLDER_STATISTICS_KEY, on_folder_statistics.clone());
        folder_list.set_data(FOLDER_REMOVE_KEY, on_remove_folder.clone());
        folder_list.set_data(FOLDER_FAVORITE_KEY, on_folder_favorite.clone());
        folder_list.set_data(FOLDER_WATCH_KEY, on_folder_watch.clone());
        share_list.set_data(FOLDER_REFRESH_KEY, on_refresh_folder);
        share_list.set_data(FOLDER_STATISTICS_KEY, on_folder_statistics);
        share_list.set_data(FOLDER_REMOVE_KEY, on_remove_folder);
        share_list.set_data(FOLDER_FAVORITE_KEY, on_folder_favorite);
        share_list.set_data(FOLDER_WATCH_KEY, on_folder_watch);
    }

    populate_albums(&album_list, albums, &on_delete_album);
    populate_folders(&folder_list, folders, &state, &on_unavailable);
    // The first refresh must be able to resolve the share list just like all
    // later refreshes. Register it before populating saved network roots.
    unsafe {
        outer.set_data(SHARE_LIST_KEY, share_list.clone());
    }
    refresh_network_shares(&outer, folders, &state, &on_unavailable);

    outer.set_child(Some(&root));

    // On first presentation, give Albums enough room for five rows when five
    // are available. Measure the actual row widgets instead of assuming a
    // fixed pixel height, so font/theme/DPI changes keep the startup split
    // correct. A short album list still uses only its natural height.
    {
        let paned = section_paned.clone();
        let album_list = album_list.clone();
        let saved_position = saved_album_pane_position.clone();
        let applied = Rc::new(Cell::new(false));
        let applied_for_map = applied.clone();
        section_paned.connect_map(move |_| {
            if applied_for_map.replace(true) {
                return;
            }

            let paned = paned.clone();
            let album_list = album_list.clone();
            let saved_position = saved_position.clone();
            glib::idle_add_local_once(move || {
                let desired = list_natural_height_for_rows(&album_list, STARTUP_VISIBLE_ALBUM_ROWS);
                if desired <= 0 {
                    return;
                }

                let max_position = paned.max_position();
                let target = if max_position > 0 {
                    desired.min(max_position)
                } else {
                    desired
                };
                if target > 0 {
                    saved_position.set(target);
                    paned.set_position(target);
                }
            });
        });
    }

    // On first presentation, place the Folders / Network Shares divider right
    // below the Folders rows (Folders natural height). Without this the paned
    // can push the divider to the bottom edge, hiding the separator line and
    // making the Folders section look fixed while only Albums is resizable.
    {
        let paned = folder_share_paned.clone();
        let folder_list = folder_list.clone();
        let folder_heading_for_map = folder_heading.clone();
        let applied = Rc::new(Cell::new(false));
        let applied_for_map = applied.clone();
        folder_share_paned.connect_map(move |_| {
            if applied_for_map.replace(true) {
                return;
            }

            let paned = paned.clone();
            let folder_list = folder_list.clone();
            let folder_heading = folder_heading_for_map.clone();
            glib::idle_add_local_once(move || {
                // Measure the actual row widgets; a GtkScrolledWindow reports
                // a near-zero natural height unless propagate-natural-height
                // is enabled, so the revealers cannot be measured directly.
                let desired = list_natural_height_for_rows(&folder_list, usize::MAX)
                    + folder_heading.height();
                if desired <= 0 {
                    return;
                }

                let max_position = paned.max_position();
                let target = if max_position > 0 {
                    desired.min(max_position)
                } else {
                    desired
                };
                if target > 0 {
                    paned.set_position(target);
                }
            });
        });
    }

    // Store stable widget/state handles on the existing GtkScrolledWindow so
    // refresh() and append_folder() can update only the relevant sections
    // without changing any caller-facing API.
    unsafe {
        outer.set_data(STATE_KEY, state);
        outer.set_data(VISIBILITY_KEY, visibility);
        outer.set_data(LIBRARY_LIST_KEY, library_list);
        outer.set_data(LIBRARY_HEADING_KEY, library_heading);
        outer.set_data(LIBRARY_REVEALER_KEY, library_revealer);
        outer.set_data(LIBRARY_INDICATOR_KEY, library_indicator);
        outer.set_data(ALBUM_LIST_KEY, album_list);
        outer.set_data(ALBUM_HEADING_KEY, album_heading);
        outer.set_data(ALBUM_REVEALER_KEY, album_revealer);
        outer.set_data(ALBUM_INDICATOR_KEY, album_indicator);
        outer.set_data(FOLDER_LIST_KEY, folder_list);
        outer.set_data(FOLDER_HEADING_KEY, folder_heading);
        outer.set_data(FOLDER_SCROLL_KEY, folder_scroll);
        outer.set_data(FOLDER_REVEALER_KEY, folder_revealer);
        outer.set_data(FOLDER_INDICATOR_KEY, folder_indicator);
        outer.set_data(FOLDER_MODE_TOGGLE_KEY, folder_mode_toggle);
        outer.set_data(FOLDER_MODE_CHANGED_KEY, on_folder_display_mode_changed);
        outer.set_data(FOLDER_SHARE_PANED_KEY, folder_share_paned);
        outer.set_data(FOLDER_PANE_SAVED_KEY, saved_folder_pane_position);
        outer.set_data(SECTION_PANED_KEY, section_paned);
        outer.set_data(FOLDER_SECTION_KEY, folder_section);
        outer.set_data(SHARE_SECTION_KEY, share_section);
        outer.set_data(SHARE_MODE_TOGGLE_KEY, share_mode_toggle);
        outer.set_data(FILTER_SYNCING_KEY, filter_syncing);
    }

    apply_visibility(&outer, visibility);

    let keyboard = gtk::EventControllerKey::new();
    keyboard.set_propagation_phase(gtk::PropagationPhase::Capture);
    let sidebar_for_keyboard = outer.clone();
    keyboard.connect_key_pressed(move |_, key, _, modifiers| {
        handle_keyboard_navigation(&sidebar_for_keyboard, key, modifiers)
    });
    outer.add_controller(keyboard);

    outer
}

/// Set the widget that receives focus when Tab leaves the sidebar.
/// The resolver is called on each Tab so Folder mode can target `folder_root`
/// instead of the hidden GridView. Also installs the Tab handler that returns
/// focus from the grid into the sidebar — attach it to every grid root.
pub fn set_keyboard_grid_target(
    scrolled: &gtk::ScrolledWindow,
    target: Rc<dyn Fn() -> gtk::Widget>,
    grid_roots: &[gtk::Widget],
) {
    unsafe {
        scrolled.set_data(KEYBOARD_GRID_TARGET_KEY, target);
    }

    for grid in grid_roots {
        let sidebar_for_grid = scrolled.clone();
        let grid_keyboard = gtk::EventControllerKey::new();
        grid_keyboard.set_propagation_phase(gtk::PropagationPhase::Capture);
        grid_keyboard.connect_key_pressed(move |_, key, _, modifiers| {
            let shift_tab = key == gtk::gdk::Key::ISO_Left_Tab
                || (key == gtk::gdk::Key::Tab
                    && modifiers.contains(gtk::gdk::ModifierType::SHIFT_MASK));
            if key != gtk::gdk::Key::Tab && !shift_tab {
                return glib::Propagation::Proceed;
            }

            let sections = navigation_sections(&sidebar_for_grid);
            if sections.is_empty() {
                return glib::Propagation::Proceed;
            }
            let index = if shift_tab { sections.len() - 1 } else { 0 };
            if focus_navigation_section(&sections, index, shift_tab) {
                glib::Propagation::Stop
            } else {
                glib::Propagation::Proceed
            }
        });
        grid.add_controller(grid_keyboard);
    }
}

fn handle_keyboard_navigation(
    scrolled: &gtk::ScrolledWindow,
    key: gtk::gdk::Key,
    modifiers: gtk::gdk::ModifierType,
) -> glib::Propagation {
    let sections = navigation_sections(scrolled);
    let focused = focused_navigation_row(scrolled);
    let selected = selected_navigation_row(&sections);
    let current_row = focused.or(selected);
    let current_section = current_row.as_ref().and_then(|row| {
        sections
            .iter()
            .position(|(_, rows)| rows.iter().any(|candidate| candidate == row))
    });

    let shift_tab = key == gtk::gdk::Key::ISO_Left_Tab
        || (key == gtk::gdk::Key::Tab
            && modifiers.contains(gtk::gdk::ModifierType::SHIFT_MASK));
    if key == gtk::gdk::Key::Tab || shift_tab {
        if sections.is_empty() {
            return glib::Propagation::Proceed;
        }

        let next_section = if shift_tab {
            current_section.and_then(|index| index.checked_sub(1))
        } else {
            current_section
                .map(|index| index + 1)
                .filter(|index| *index < sections.len())
        };

        if let Some(index) = next_section {
            if focus_navigation_section(&sections, index, shift_tab) {
                return glib::Propagation::Stop;
            }
        }

        // The grid is the fifth keyboard section. Tab from the last sidebar
        // section (or Shift+Tab from the first) crosses to it without changing
        // the active Library/Album/Folder/Share selection.
        let target = unsafe {
            scrolled
                .data::<Rc<dyn Fn() -> gtk::Widget>>(KEYBOARD_GRID_TARGET_KEY)
                .map(|target| target.as_ref().clone())
        };
        if let Some(resolve) = target {
            let widget = resolve();
            if widget.is_visible() {
                widget.grab_focus();
                return glib::Propagation::Stop;
            }
        }
        return glib::Propagation::Proceed;
    }

    let all_rows = sections
        .iter()
        .flat_map(|(_, rows)| rows.iter().cloned())
        .collect::<Vec<_>>();
    if all_rows.is_empty() {
        return glib::Propagation::Proceed;
    }

    match key {
        gtk::gdk::Key::Up | gtk::gdk::Key::Down => {
            let current = current_row
                .as_ref()
                .and_then(|row| all_rows.iter().position(|candidate| candidate == row));
            let next = match (current, key == gtk::gdk::Key::Down) {
                (Some(index), true) => (index + 1).min(all_rows.len() - 1),
                (Some(index), false) => index.saturating_sub(1),
                (None, true) => 0,
                (None, false) => all_rows.len() - 1,
            };
            select_navigation_row(&sections, &all_rows[next]);
            glib::Propagation::Stop
        }
        gtk::gdk::Key::Left | gtk::gdk::Key::Right => {
            let Some((list, row)) = focused_or_selected_folder_navigation_row(scrolled) else {
                return glib::Propagation::Proceed;
            };
            let rows = folder_rows(&list);
            let folder = unsafe {
                row.data::<Folder>("picasa-folder-record")
                    .map(|folder| folder.as_ref().clone())
            };
            let Some(folder) = folder else {
                return glib::Propagation::Proceed;
            };
            let has_children = unsafe {
                row.data::<bool>("picasa-folder-has-children")
                    .is_some_and(|value| *value.as_ref())
            };
            let state = sidebar_state(scrolled);
            let Some(state) = state else {
                return glib::Propagation::Proceed;
            };
            let expanded = state.borrow().expanded_folders.contains(&folder.id);

            if key == gtk::gdk::Key::Right {
                if has_children && !expanded {
                    state.borrow_mut().expanded_folders.insert(folder.id);
                    rebuild_folder_list_from_rows(&list, &state);
                    set_active_filter(scrolled, SidebarFilter::Folder(folder.id));
                } else if has_children {
                    let visible_rows = folder_rows(&list);
                    if let Some(child) = visible_rows
                        .iter()
                        .skip_while(|candidate| *candidate != &row)
                        .nth(1)
                    {
                        list.select_row(Some(child));
                        child.grab_focus();
                    }
                }
            } else if has_children && expanded {
                state.borrow_mut().expanded_folders.remove(&folder.id);
                rebuild_folder_list_from_rows(&list, &state);
                set_active_filter(scrolled, SidebarFilter::Folder(folder.id));
            } else if let Some(parent_id) = folder.parent_id {
                if let Some(parent) = rows.iter().find(|candidate| unsafe {
                    candidate
                        .data::<Folder>("picasa-folder-record")
                        .is_some_and(|parent| parent.as_ref().id == parent_id)
                }) {
                    list.select_row(Some(parent));
                    parent.grab_focus();
                }
            }
            glib::Propagation::Stop
        }
        _ => glib::Propagation::Proceed,
    }
}

fn folder_rows(list: &gtk::ListBox) -> Vec<gtk::ListBoxRow> {
    let mut rows = Vec::new();
    let mut child = list.first_child();
    while let Some(widget) = child {
        let next = widget.next_sibling();
        if let Ok(row) = widget.downcast::<gtk::ListBoxRow>() {
            if unsafe { row.data::<Folder>("picasa-folder-record") }.is_some() {
                rows.push(row);
            }
        }
        child = next;
    }
    rows
}

fn navigation_sections(
    scrolled: &gtk::ScrolledWindow,
) -> Vec<(gtk::ListBox, Vec<gtk::ListBoxRow>)> {
    [
        LIBRARY_LIST_KEY,
        ALBUM_LIST_KEY,
        FOLDER_LIST_KEY,
        SHARE_LIST_KEY,
    ]
    .into_iter()
    .filter_map(|key| {
        let list = stored_widget::<gtk::ListBox>(scrolled, key)?;
        let mut rows = Vec::new();
        let mut child = list.first_child();
        while let Some(widget) = child {
            let next = widget.next_sibling();
            if let Ok(row) = widget.downcast::<gtk::ListBoxRow>() {
                let selectable = unsafe { row.data::<SidebarFilter>("picasa-filter") }.is_some();
                if selectable {
                    rows.push(row);
                }
            }
            child = next;
        }
        (!rows.is_empty()).then_some((list, rows))
    })
    .collect()
}

fn selected_navigation_row(
    sections: &[(gtk::ListBox, Vec<gtk::ListBoxRow>)],
) -> Option<gtk::ListBoxRow> {
    sections.iter().find_map(|(list, _)| list.selected_row())
}

fn focused_navigation_row(scrolled: &gtk::ScrolledWindow) -> Option<gtk::ListBoxRow> {
    let root = scrolled.root()?;
    let mut focus = root.focus();
    while let Some(widget) = focus {
        if let Ok(row) = widget.clone().downcast::<gtk::ListBoxRow>() {
            return Some(row);
        }
        focus = widget.parent();
    }
    None
}

fn focused_or_selected_folder_navigation_row(
    scrolled: &gtk::ScrolledWindow,
) -> Option<(gtk::ListBox, gtk::ListBoxRow)> {
    let list = stored_widget::<gtk::ListBox>(scrolled, FOLDER_LIST_KEY)?;
    if let Some(row) = focused_navigation_row(scrolled) {
        if folder_rows(&list).iter().any(|candidate| candidate == &row) {
            return Some((list, row));
        }
    }
    Some((list.clone(), list.selected_row()?))
}

fn focus_navigation_section(
    sections: &[(gtk::ListBox, Vec<gtk::ListBoxRow>)],
    index: usize,
    reverse: bool,
) -> bool {
    let Some((list, rows)) = sections.get(index) else {
        return false;
    };
    let selected = list
        .selected_row()
        .filter(|row| rows.iter().any(|candidate| candidate == row));
    let row = selected.or_else(|| {
        if reverse {
            rows.last().cloned()
        } else {
            rows.first().cloned()
        }
    });
    row.is_some_and(|row| row.grab_focus())
}

fn select_navigation_row(sections: &[(gtk::ListBox, Vec<gtk::ListBoxRow>)], row: &gtk::ListBoxRow) {
    for (list, rows) in sections {
        if rows.iter().any(|candidate| candidate == row) {
            list.select_row(Some(row));
            row.grab_focus();
            break;
        }
    }
}


pub fn refresh(
    scrolled: &gtk::ScrolledWindow,
    folders: &[Folder],
    albums: &[Album],
    counts: SidebarCounts,
    on_create_album: Rc<dyn Fn()>,
    on_import_folder: Rc<dyn Fn()>,
    on_delete_album: Rc<dyn Fn(i64)>,
    on_unavailable: Rc<dyn Fn()>,
) {
    // The callback parameters stay in the signature for full compatibility
    // with the existing window submodules. Heading + buttons were wired once
    // in build(), so refresh only replaces dynamic rows.
    let _ = (&on_create_album, &on_import_folder);

    let Some(state) = sidebar_state(scrolled) else {
        return;
    };
    let Some(library_list) = stored_widget::<gtk::ListBox>(scrolled, LIBRARY_LIST_KEY) else {
        return;
    };
    let Some(album_list) = stored_widget::<gtk::ListBox>(scrolled, ALBUM_LIST_KEY) else {
        return;
    };
    let Some(folder_list) = stored_widget::<gtk::ListBox>(scrolled, FOLDER_LIST_KEY) else {
        return;
    };
    let folder_scroll_value = folder_scroll_value(scrolled);

    clear_list(&library_list);
    populate_library(&library_list, counts, &on_unavailable);

    clear_list(&album_list);
    populate_albums(&album_list, albums, &on_delete_album);

    clear_list(&folder_list);
    populate_folders(&folder_list, folders, &state, &on_unavailable);
    refresh_network_shares(scrolled, folders, &state, &on_unavailable);
    apply_visibility(scrolled, sidebar_visibility(scrolled));

    if let Some(revealer) = stored_widget::<gtk::Revealer>(scrolled, LIBRARY_REVEALER_KEY) {
        revealer.set_reveal_child(state.borrow().library_expanded);
    }
    if let Some(indicator) = stored_widget::<gtk::Button>(scrolled, LIBRARY_INDICATOR_KEY) {
        indicator.set_icon_name(if state.borrow().library_expanded {
            "pan-down-symbolic"
        } else {
            "pan-end-symbolic"
        });
    }
    if let Some(revealer) = stored_widget::<gtk::Revealer>(scrolled, ALBUM_REVEALER_KEY) {
        revealer.set_reveal_child(state.borrow().albums_expanded);
    }
    if let Some(indicator) = stored_widget::<gtk::Button>(scrolled, ALBUM_INDICATOR_KEY) {
        indicator.set_icon_name(if state.borrow().albums_expanded {
            "pan-down-symbolic"
        } else {
            "pan-end-symbolic"
        });
    }
    if let Some(revealer) = stored_widget::<gtk::Revealer>(scrolled, FOLDER_REVEALER_KEY) {
        // Mirror the Albums refresh: assert reveal state only. The pane
        // position/vexpand is owned by the collapse animation and the user's
        // divider drags; forcing vexpand here would break re-expansion after
        // a collapsed pane was detached.
        let expanded = state.borrow().folders_expanded;
        revealer.set_reveal_child(expanded);
    }
    if let Some(indicator) = stored_widget::<gtk::Button>(scrolled, FOLDER_INDICATOR_KEY) {
        indicator.set_icon_name(if state.borrow().folders_expanded {
            "pan-down-symbolic"
        } else {
            "pan-end-symbolic"
        });
    }

    if let Some(filter) = current_filter(scrolled) {
        set_active_filter(scrolled, filter);
    }
    restore_folder_scroll(scrolled, folder_scroll_value);
    let scrolled_for_location = scrolled.clone();
    glib::idle_add_local_once(move || apply_scroll_location(&scrolled_for_location));
}

pub fn refresh_library_counts(
    scrolled: &gtk::ScrolledWindow,
    counts: SidebarCounts,
    on_unavailable: &Rc<dyn Fn()>,
) {
    let Some(library_list) = stored_widget::<gtk::ListBox>(scrolled, LIBRARY_LIST_KEY) else {
        return;
    };

    clear_list(&library_list);
    populate_library(&library_list, counts, on_unavailable);
    apply_library_visibility(scrolled, sidebar_visibility(scrolled));

    if let Some(filter) = current_filter(scrolled) {
        set_active_filter(scrolled, filter);
    }
}

/// Update the three library counters without replacing sidebar rows. Scan
/// progress calls this frequently, so preserving row identity avoids repeated
/// layout, selection changes, and signal reconnection on the GTK thread.
pub fn update_library_counts(scrolled: &gtk::ScrolledWindow, counts: SidebarCounts) {
    let Some(list) = stored_widget::<gtk::ListBox>(scrolled, LIBRARY_LIST_KEY) else {
        return;
    };
    for (filter, count) in [
        (SidebarFilter::All, counts.photos),
        (SidebarFilter::Favorites, counts.favorites),
        (SidebarFilter::RecentlyAdded, counts.recently_added),
    ] {
        let Some(row) = row_for_filter(&list, filter) else {
            continue;
        };
        if let Some(label) = unsafe { row.data::<gtk::Label>(FILTER_COUNT_LABEL_KEY) } {
            unsafe { label.as_ref() }.set_text(&format_count(count));
        }
    }
}

/// Refresh only album names after an album edit. Avoid rebuilding the folder
/// tree, which may be receiving progressive scan updates at the same time.
pub fn refresh_album_rows(
    scrolled: &gtk::ScrolledWindow,
    albums: &[Album],
    on_delete_album: &Rc<dyn Fn(i64)>,
) {
    let Some(album_list) = stored_widget::<gtk::ListBox>(scrolled, ALBUM_LIST_KEY) else {
        return;
    };
    let scroll = scrolled.vadjustment();
    let scroll_value = scroll.value();
    clear_list(&album_list);
    populate_albums(&album_list, albums, on_delete_album);
    if let Some(filter) = current_filter(scrolled) {
        set_active_filter(scrolled, filter);
    }
    glib::idle_add_local_once(move || {
        let upper = (scroll.upper() - scroll.page_size()).max(scroll.lower());
        scroll.set_value(scroll_value.clamp(scroll.lower(), upper));
    });
}

/// Rebuild only the folder rows from fresh folder data while preserving the
/// scroll position.
pub fn refresh_folder_rows(
    scrolled: &gtk::ScrolledWindow,
    folders: &[Folder],
    on_unavailable: &Rc<dyn Fn()>,
) {
    let Some(state) = sidebar_state(scrolled) else {
        return;
    };
    let Some(folder_list) = stored_widget::<gtk::ListBox>(scrolled, FOLDER_LIST_KEY) else {
        return;
    };
    let folder_scroll_value = folder_scroll_value(scrolled);
    clear_list(&folder_list);
    populate_folders(&folder_list, folders, &state, on_unavailable);
    refresh_network_shares(scrolled, folders, &state, on_unavailable);
    restore_folder_scroll(scrolled, folder_scroll_value);
}

/// Add the folder row immediately when an import starts. The normal refresh
/// remains responsible for counts and ordering once the import completes.
pub fn append_folder(
    scrolled: &gtk::ScrolledWindow,
    folder: &Folder,
    on_unavailable: Rc<dyn Fn()>,
) {
    let Some(state) = sidebar_state(scrolled) else {
        return;
    };
    let Some(list) = stored_widget::<gtk::ListBox>(scrolled, FOLDER_LIST_KEY) else {
        return;
    };

    // Avoid duplicates while a scan emits FolderStarted events.
    let mut row = list.first_child();
    while let Some(current) = row {
        if let Ok(existing) = current.clone().downcast::<gtk::ListBoxRow>() {
            if let Some(value) = unsafe { existing.data::<SidebarFilter>("picasa-filter") } {
                if unsafe { *value.as_ref() } == SidebarFilter::Folder(folder.id) {
                    return;
                }
            }
        }
        row = current.next_sibling();
    }

    // During progressive import we may not yet have all parent rows. Add the
    // new row as a top-level entry; the next normal refresh rebuilds the exact
    // path hierarchy.
    append_folder_row(&list, folder, 0, false, &state, &on_unavailable);
}

/// Visually track the folder represented by the leading visible photo in the grid.
///
/// This is deliberately separate from ListBox selection: the selected sidebar
/// row continues to describe the active filter (All, Favourites, Album, etc.),
/// while this marker answers "where is the photo I am looking at?".  Because it
/// never selects the row, it cannot trigger the sidebar navigation callback.
pub fn set_scroll_location(scrolled: &gtk::ScrolledWindow, folder_id: Option<i64>) {
    let folder_id = folder_id.filter(|id| *id > 0).unwrap_or_default();
    let previous = unsafe {
        scrolled
            .data::<i64>(SCROLL_LOCATION_FOLDER_KEY)
            .map(|value| *value.as_ref())
            .unwrap_or_default()
    };
    if previous == folder_id {
        return;
    }

    unsafe {
        scrolled.set_data(SCROLL_LOCATION_FOLDER_KEY, folder_id);
    }
    // Coalesce the scroll-follow update into a single idle pass. Rebuilding the
    // sidebar tree when a folder's ancestors expand measured 42-77 ms per folder
    // change, which stalled the scroll frame.
    if SCROLL_LOCATION_SCHEDULED.with(|scheduled| scheduled.replace(true)) {
        return;
    }
    let scrolled = scrolled.clone();
    glib::idle_add_local_once(move || {
        SCROLL_LOCATION_SCHEDULED.with(|scheduled| scheduled.set(false));
        apply_scroll_location(&scrolled);
    });
}

fn apply_scroll_location(scrolled: &gtk::ScrolledWindow) {
    let Some(list) = stored_widget::<gtk::ListBox>(scrolled, FOLDER_LIST_KEY) else {
        return;
    };

    clear_scroll_location_rows(&list);

    let folder_id = unsafe {
        scrolled
            .data::<i64>(SCROLL_LOCATION_FOLDER_KEY)
            .map(|value| *value.as_ref())
            .unwrap_or_default()
    };
    if folder_id <= 0 {
        return;
    }

    let folders = unsafe {
        list.data::<Vec<Folder>>("picasa-folder-cache")
            .map(|data| data.as_ref().clone())
            .unwrap_or_default()
    };
    if folders.is_empty() {
        return;
    }

    let Some(state) = sidebar_state(scrolled) else {
        return;
    };
    let mode = state.borrow().folder_display_mode;
    let display_id = match mode {
        FolderDisplayMode::Tree => {
            // Passive scroll-follow must never expand/rebuild the sidebar. If
            // the exact child row is hidden under a collapsed ancestor, mark
            // the nearest ancestor that is already rendered instead.
            if row_for_filter(&list, SidebarFilter::Folder(folder_id)).is_some() {
                Some(folder_id)
            } else {
                folder_ancestor_ids(&folders, folder_id)
                    .into_iter()
                    .find(|ancestor_id| {
                        row_for_filter(&list, SidebarFilter::Folder(*ancestor_id)).is_some()
                    })
            }
        }
        FolderDisplayMode::ImportedOnly => {
            Some(imported_root_for_folder(&folders, folder_id).unwrap_or(folder_id))
        }
    };

    let Some(display_id) = display_id else {
        return;
    };
    let Some(row) = row_for_filter(&list, SidebarFilter::Folder(display_id)) else {
        return;
    };
    row.add_css_class("sidebar-scroll-location");
    scroll_folder_row_into_view(scrolled, &row);
}

fn clear_scroll_location_rows(list: &gtk::ListBox) {
    let mut child = list.first_child();
    while let Some(widget) = child {
        let next = widget.next_sibling();
        if let Ok(row) = widget.downcast::<gtk::ListBoxRow>() {
            row.remove_css_class("sidebar-scroll-location");
        }
        child = next;
    }
}

fn row_for_filter(list: &gtk::ListBox, filter: SidebarFilter) -> Option<gtk::ListBoxRow> {
    let mut child = list.first_child();
    while let Some(widget) = child {
        let next = widget.next_sibling();
        if let Ok(row) = widget.downcast::<gtk::ListBoxRow>() {
            let matches = unsafe {
                row.data::<SidebarFilter>("picasa-filter")
                    .is_some_and(|value| *value.as_ref() == filter)
            };
            if matches {
                return Some(row);
            }
        }
        child = next;
    }
    None
}

fn imported_root_for_folder(folders: &[Folder], folder_id: i64) -> Option<i64> {
    let by_id: HashMap<i64, &Folder> = folders.iter().map(|folder| (folder.id, folder)).collect();
    let mut current = Some(folder_id);
    let mut visited = HashSet::new();
    while let Some(id) = current {
        if !visited.insert(id) {
            break;
        }
        let folder = by_id.get(&id)?;
        if folder.imported_root {
            return Some(folder.id);
        }
        current = folder.parent_id;
    }
    None
}

fn folder_ancestor_ids(folders: &[Folder], folder_id: i64) -> Vec<i64> {
    let by_id: HashMap<i64, &Folder> = folders.iter().map(|folder| (folder.id, folder)).collect();
    let mut result = Vec::new();
    let mut current = by_id.get(&folder_id).and_then(|folder| folder.parent_id);
    let mut visited = HashSet::new();
    while let Some(id) = current {
        if !visited.insert(id) {
            break;
        }
        result.push(id);
        current = by_id.get(&id).and_then(|folder| folder.parent_id);
    }
    result
}

fn scroll_folder_row_into_view(scrolled: &gtk::ScrolledWindow, row: &gtk::ListBoxRow) {
    let Some(folder_scroll) = stored_widget::<gtk::ScrolledWindow>(scrolled, FOLDER_SCROLL_KEY)
    else {
        return;
    };
    let row = row.clone();
    glib::idle_add_local_once(move || {
        // Bounds relative to the scroller (the folder list now sits below the
        // album section in the shared scroller, so allocation y is not enough).
        let Some(bounds) = row.compute_bounds(&folder_scroll) else {
            return;
        };
        let adjustment = folder_scroll.vadjustment();
        let page = adjustment.page_size();
        let row_top = bounds.y() as f64;
        let row_bottom = row_top + bounds.height() as f64;

        let target = if row_top < 0.0 {
            Some(adjustment.value() + row_top)
        } else if row_bottom > page {
            Some(adjustment.value() + row_bottom - page)
        } else {
            None
        };

        if let Some(target) = target {
            let upper = (adjustment.upper() - page).max(adjustment.lower());
            adjustment.set_value(target.clamp(adjustment.lower(), upper));
        }
    });
}

/// Folder rows currently presented to the user, in sidebar order.
///
/// Tree mode returns only the rows that are presently visible in the expanded
/// tree. Imported-only mode naturally returns just the explicitly imported
/// roots because those are the only rows built for that mode.
pub fn visible_folder_ids(scrolled: &gtk::ScrolledWindow) -> Vec<i64> {
    let Some(list) = stored_widget::<gtk::ListBox>(scrolled, FOLDER_LIST_KEY) else {
        return Vec::new();
    };

    let mut ids = Vec::new();
    let mut child = list.first_child();
    while let Some(widget) = child {
        let next = widget.next_sibling();
        if let Ok(row) = widget.downcast::<gtk::ListBoxRow>() {
            let filter = unsafe {
                row.data::<SidebarFilter>("picasa-filter")
                    .map(|filter| *filter.as_ref())
            };
            if let Some(SidebarFilter::Folder(folder_id)) = filter {
                ids.push(folder_id);
            }
        }
        child = next;
    }
    ids
}

pub fn set_folder_display_mode(scrolled: &gtk::ScrolledWindow, mode: FolderDisplayMode) -> bool {
    let Some(state) = sidebar_state(scrolled) else {
        return false;
    };
    if state.borrow().folder_display_mode == mode {
        return false;
    }

    state.borrow_mut().folder_display_mode = mode;
    if let Some(toggle) = stored_widget::<gtk::Button>(scrolled, FOLDER_MODE_TOGGLE_KEY) {
        set_folder_mode_toggle_presentation(&toggle, mode);
    }
    if let Some(list) = stored_widget::<gtk::ListBox>(scrolled, FOLDER_LIST_KEY) {
        rebuild_folder_list_from_rows(&list, &state);
    }
    let callback = unsafe {
        scrolled
            .data::<Rc<dyn Fn(FolderDisplayMode)>>(FOLDER_MODE_CHANGED_KEY)
            .map(|callback| callback.as_ref().clone())
    };
    if let Some(callback) = callback {
        callback(mode);
    }
    true
}

pub fn set_active_filter(scrolled: &gtk::ScrolledWindow, filter: SidebarFilter) {
    unsafe {
        scrolled.set_data(CURRENT_FILTER_KEY, filter);
    }

    // The old scroll-location marker is separate from ListBox selection. Once
    // a real destination becomes active it must be cleared even for Folder
    // destinations, otherwise GTK can show two highlighted folder rows: the
    // newly selected row plus the stale scroll-location marker.
    set_scroll_location(scrolled, None);

    let syncing = unsafe {
        scrolled
            .data::<Rc<Cell<bool>>>(FILTER_SYNCING_KEY)
            .map(|data| data.as_ref().clone())
    };
    let Some(syncing) = syncing else {
        return;
    };

    let folder_scroll_value = matches!(filter, SidebarFilter::Folder(_))
        .then(|| folder_scroll_value(scrolled))
        .flatten();

    syncing.set(true);
    if let Some(library_list) = stored_widget::<gtk::ListBox>(scrolled, LIBRARY_LIST_KEY) {
        library_list.unselect_all();
    }
    if let Some(album_list) = stored_widget::<gtk::ListBox>(scrolled, ALBUM_LIST_KEY) {
        album_list.unselect_all();
    }
    if let Some(folder_list) = stored_widget::<gtk::ListBox>(scrolled, FOLDER_LIST_KEY) {
        folder_list.unselect_all();
    }
    if let Some(share_list) = stored_widget::<gtk::ListBox>(scrolled, SHARE_LIST_KEY) {
        share_list.unselect_all();
    }

    match filter {
        SidebarFilter::All
        | SidebarFilter::Favorites
        | SidebarFilter::RecentlyAdded
        | SidebarFilter::History => {
            select_matching_row(scrolled, LIBRARY_LIST_KEY, filter);
        }
        SidebarFilter::Library | SidebarFilter::Albums => {}
        SidebarFilter::Album(_) => {
            select_matching_row(scrolled, ALBUM_LIST_KEY, filter);
        }
        SidebarFilter::Folder(_) => {
            select_matching_row(scrolled, FOLDER_LIST_KEY, filter);
            // The same Folder filter may be presented by a share row when the
            // target is a registered network share root.
            select_matching_row(scrolled, SHARE_LIST_KEY, filter);
        }
    }
    syncing.set(false);
    restore_folder_scroll(scrolled, folder_scroll_value);
}

fn folder_scroll_value(scrolled: &gtk::ScrolledWindow) -> Option<f64> {
    stored_widget::<gtk::ScrolledWindow>(scrolled, FOLDER_SCROLL_KEY)
        .map(|folder_scroll| folder_scroll.vadjustment().value())
}

fn restore_folder_scroll(scrolled: &gtk::ScrolledWindow, value: Option<f64>) {
    let Some(value) = value else {
        return;
    };
    let scrolled = scrolled.clone();
    glib::idle_add_local_once(move || {
        let Some(folder_scroll) =
            stored_widget::<gtk::ScrolledWindow>(&scrolled, FOLDER_SCROLL_KEY)
        else {
            return;
        };
        let adjustment = folder_scroll.vadjustment();
        let max_value = (adjustment.upper() - adjustment.page_size()).max(adjustment.lower());
        adjustment.set_value(value.clamp(adjustment.lower(), max_value));
    });
}

/// Reveal and scroll to an imported folder selected from search suggestions.
pub fn scroll_to_folder(scrolled: &gtk::ScrolledWindow, folder_id: i64) {
    let Some(state) = sidebar_state(scrolled) else {
        return;
    };
    let Some(list) = stored_widget::<gtk::ListBox>(scrolled, FOLDER_LIST_KEY) else {
        return;
    };

    // A navigation request should reveal the exact folder row, not only an
    // imported parent/root. Force Tree mode for Open in Folder/search reveals
    // so the full ancestor path exists in the sidebar, then continue scrolling
    // after the rebuilt rows have been allocated.
    if set_folder_display_mode(scrolled, FolderDisplayMode::Tree) {
        let scrolled = scrolled.clone();
        glib::timeout_add_local_once(std::time::Duration::from_millis(100), move || {
            scroll_to_folder(&scrolled, folder_id);
        });
        return;
    }

    // A navigation request must make the target row visible even when the
    // user previously collapsed the entire Folders section.
    state.borrow_mut().folders_expanded = true;
    // Reattach the pane first if the section was collapsed: the collapse
    // animation detaches the start child so the divider auto-hides, exactly
    // like the Albums pane.
    if let Some(paned) = stored_widget::<gtk::Paned>(scrolled, FOLDER_SHARE_PANED_KEY) {
        if paned.start_child().is_none() {
            if let Some(revealer) = stored_widget::<gtk::Revealer>(scrolled, FOLDER_REVEALER_KEY) {
                revealer.set_reveal_child(false);
                paned.set_start_child(Some(&revealer));
                paned.set_position(0);
            }
        }
        if let Some(saved) = unsafe {
            paned
                .data::<Rc<Cell<i32>>>(FOLDER_PANE_SAVED_KEY)
                .map(|s| s.as_ref().clone())
        } {
            let target = saved.get().max(0);
            if target > 0 {
                paned.set_position(target);
            }
        }
    }
    if let Some(revealer) = stored_widget::<gtk::Revealer>(scrolled, FOLDER_REVEALER_KEY) {
        revealer.set_reveal_child(true);
    }
    if let Some(indicator) = stored_widget::<gtk::Button>(scrolled, FOLDER_INDICATOR_KEY) {
        indicator.set_icon_name("pan-down-symbolic");
    }

    // Search results can target a row below a collapsed ancestor. Expand the
    // path using the same cached folder data used for the normal tree.
    let folders = unsafe {
        list.data::<Vec<Folder>>("picasa-folder-cache")
            .map(|folders| folders.as_ref().clone())
            .unwrap_or_default()
    };
    let by_id: HashMap<i64, &Folder> = folders.iter().map(|folder| (folder.id, folder)).collect();
    let tree_mode = state.borrow().folder_display_mode == FolderDisplayMode::Tree;
    let mut parent = tree_mode
        .then(|| by_id.get(&folder_id).and_then(|folder| folder.parent_id))
        .flatten();
    let mut expanded = false;
    while let Some(parent_id) = parent {
        expanded |= state.borrow_mut().expanded_folders.insert(parent_id);
        parent = by_id.get(&parent_id).and_then(|folder| folder.parent_id);
    }
    let folder_scroll_value = folder_scroll_value(scrolled);
    if expanded {
        rebuild_folder_list_from_rows(&list, &state);

        // Rebuilding the tree schedules restoration of the previous scroll
        // position and GTK has not allocated the new rows yet. Retry after
        // both have had a main-loop turn so the target can be placed at the
        // top reliably.
        let scrolled = scrolled.clone();
        glib::timeout_add_local_once(std::time::Duration::from_millis(100), move || {
            scroll_to_folder(&scrolled, folder_id);
        });
        return;
    }

    let mut child = list.first_child();
    while let Some(widget) = child {
        let next = widget.next_sibling();
        if let Ok(row) = widget.downcast::<gtk::ListBoxRow>() {
            let matches = unsafe {
                row.data::<SidebarFilter>("picasa-filter")
                    .is_some_and(|filter| *filter.as_ref() == SidebarFilter::Folder(folder_id))
            };
            if matches {
                // Select directly so this reveal does not schedule another
                // restoration of the old scroll position. The ListBox
                // selection signal normally invokes the navigation callback,
                // so suppress that callback for this programmatic selection.
                let syncing = unsafe {
                    scrolled
                        .data::<Rc<Cell<bool>>>(FILTER_SYNCING_KEY)
                        .map(|data| data.as_ref().clone())
                };
                if let Some(syncing) = &syncing {
                    syncing.set(true);
                }
                select_matching_row(scrolled, FOLDER_LIST_KEY, SidebarFilter::Folder(folder_id));
                row.grab_focus();
                if let Some(syncing) = syncing {
                    syncing.set(false);
                }
                if let Some(folder_scroll) =
                    stored_widget::<gtk::ScrolledWindow>(scrolled, FOLDER_SCROLL_KEY)
                {
                    let adjustment = folder_scroll.vadjustment();
                    // Row position in the scrolled content: the folder list now
                    // sits below the album section in the shared scroller, so
                    // its own allocation y is not the scroll offset.
                    let top = row
                        .compute_bounds(&folder_scroll)
                        .map(|bounds| adjustment.value() + f64::from(bounds.y()))
                        .unwrap_or_else(|| f64::from(row.allocation().y()));
                    // Keep the selected folder at the top of the folder pane
                    // so repeated navigation has a consistent destination.
                    adjustment.set_value(top.clamp(
                        adjustment.lower(),
                        (adjustment.upper() - adjustment.page_size()).max(adjustment.lower()),
                    ));
                }
                return;
            }
        }
        child = next;
    }
    restore_folder_scroll(scrolled, folder_scroll_value);
}

fn current_filter(scrolled: &gtk::ScrolledWindow) -> Option<SidebarFilter> {
    unsafe {
        scrolled
            .data::<SidebarFilter>(CURRENT_FILTER_KEY)
            .map(|filter| *filter.as_ref())
    }
}

fn sidebar_state(scrolled: &gtk::ScrolledWindow) -> Option<Rc<RefCell<SidebarState>>> {
    unsafe {
        scrolled
            .data::<Rc<RefCell<SidebarState>>>(STATE_KEY)
            .map(|state| state.as_ref().clone())
    }
}

fn sidebar_visibility(scrolled: &gtk::ScrolledWindow) -> SidebarVisibility {
    unsafe {
        scrolled
            .data::<SidebarVisibility>(VISIBILITY_KEY)
            .map(|visibility| *visibility.as_ref())
            .unwrap_or_default()
    }
}

/// Mark whether the sidebar is explicitly pinned open.
///
/// Pinned means mouse-leave must not auto-hide it.
pub fn set_pinned(scrolled: &gtk::ScrolledWindow, pinned: bool) {
    let Some(state) = sidebar_state(scrolled) else {
        return;
    };

    let state = state.borrow();
    state.pinned.set(pinned);

    if pinned {
        state.hover_open.set(false);
    }
}

/// Returns true when the sidebar was explicitly pinned open.
pub fn is_pinned(scrolled: &gtk::ScrolledWindow) -> bool {
    sidebar_state(scrolled)
        .map(|state| state.borrow().pinned.get())
        .unwrap_or(true)
}

/// Record that the sidebar was opened temporarily by the left-edge hover.
///
/// The reveal decision (pinned vs collapsed peek) lives in the layout; this
/// flag is the raw "opened by hover, auto-close on leave" state.
pub fn set_hover_open(scrolled: &gtk::ScrolledWindow, hover_open: bool) {
    let Some(state) = sidebar_state(scrolled) else {
        return;
    };

    let state = state.borrow();
    state.hover_open.set(hover_open);
}

/// Returns true only when the sidebar is currently open because of hover.
///
/// True even for a pinned sidebar that was only peeked open by the edge
/// hover while the split view is collapsed (the breakpoint hides it anyway).
pub fn is_hover_open(scrolled: &gtk::ScrolledWindow) -> bool {
    sidebar_state(scrolled)
        .map(|state| state.borrow().hover_open.get())
        .unwrap_or(false)
}

/// Clear temporary hover-open state after the sidebar auto-hides.
pub fn clear_hover_open(scrolled: &gtk::ScrolledWindow) {
    let Some(state) = sidebar_state(scrolled) else {
        return;
    };
    state.borrow().hover_open.set(false);
}

fn stored_widget<T>(scrolled: &gtk::ScrolledWindow, key: &str) -> Option<T>
where
    T: IsA<gtk::Widget> + Clone + 'static,
{
    unsafe {
        scrolled
            .data::<T>(key)
            .map(|widget| widget.as_ref().clone())
    }
}

fn select_matching_row(scrolled: &gtk::ScrolledWindow, list_key: &str, filter: SidebarFilter) {
    let Some(list) = stored_widget::<gtk::ListBox>(scrolled, list_key) else {
        return;
    };

    let mut child = list.first_child();
    while let Some(widget) = child {
        if let Ok(row) = widget.clone().downcast::<gtk::ListBoxRow>() {
            let matches = unsafe {
                row.data::<SidebarFilter>("picasa-filter")
                    .map(|value| *value.as_ref() == filter)
                    .unwrap_or(false)
            };
            if matches {
                list.select_row(Some(&row));
                return;
            }
        }
        child = widget.next_sibling();
    }
}

fn section_list() -> gtk::ListBox {
    let list = gtk::ListBox::new();
    list.set_selection_mode(gtk::SelectionMode::Single);
    list.set_hexpand(true);
    list.add_css_class("navigation-sidebar");
    list
}

fn connect_filter_list(
    list: &gtk::ListBox,
    on_filter: Rc<dyn Fn(SidebarFilter)>,
    syncing: Rc<Cell<bool>>,
) {
    list.connect_row_selected(move |_, row| {
        if syncing.get() {
            return;
        }
        let Some(row) = row else { return };
        if let Some(value) = unsafe { row.data::<SidebarFilter>("picasa-filter") } {
            on_filter(unsafe { *value.as_ref() });
        }
    });
}

fn clear_list(list: &gtk::ListBox) {
    while let Some(child) = list.first_child() {
        list.remove(&child);
    }
}

pub fn apply_visibility(scrolled: &gtk::ScrolledWindow, visibility: SidebarVisibility) {
    unsafe {
        scrolled.set_data(VISIBILITY_KEY, visibility);
    }

    if let Some(heading) = stored_widget::<gtk::Box>(scrolled, LIBRARY_HEADING_KEY) {
        heading.set_visible(visibility.library);
    }
    if let Some(revealer) = stored_widget::<gtk::Revealer>(scrolled, LIBRARY_REVEALER_KEY) {
        revealer.set_visible(visibility.library);
    }
    if let Some(heading) = stored_widget::<gtk::Box>(scrolled, ALBUM_HEADING_KEY) {
        heading.set_visible(visibility.albums);
    }
    if let Some(revealer) = stored_widget::<gtk::Revealer>(scrolled, ALBUM_REVEALER_KEY) {
        revealer.set_visible(visibility.albums);
    }
    if let Some(heading) = stored_widget::<gtk::Box>(scrolled, FOLDER_HEADING_KEY) {
        heading.set_visible(visibility.folders);
    }
    if let Some(revealer) = stored_widget::<gtk::Revealer>(scrolled, FOLDER_REVEALER_KEY) {
        revealer.set_visible(visibility.folders);
    }
    if let Some(section) = stored_widget::<gtk::Box>(scrolled, SHARE_SECTION_KEY) {
        section.set_visible(visibility.network_shares);
    }
    if let Some(section) = stored_widget::<gtk::Box>(scrolled, FOLDER_SECTION_KEY) {
        section.set_visible(visibility.folders || visibility.network_shares);
    }
    if let Some(paned) = stored_widget::<gtk::Paned>(scrolled, SECTION_PANED_KEY) {
        paned.set_visible(visibility.albums || visibility.folders || visibility.network_shares);
    }

    apply_library_visibility(scrolled, visibility);
}

fn apply_library_visibility(scrolled: &gtk::ScrolledWindow, visibility: SidebarVisibility) {
    let Some(list) = stored_widget::<gtk::ListBox>(scrolled, LIBRARY_LIST_KEY) else {
        return;
    };
    let mut child = list.first_child();
    while let Some(widget) = child {
        child = widget.next_sibling();
        let Ok(row) = widget.downcast::<gtk::ListBoxRow>() else {
            continue;
        };
        let Some(filter) = (unsafe { row.data::<SidebarFilter>("picasa-filter") }) else {
            continue;
        };
        let visible = match unsafe { *filter.as_ref() } {
            SidebarFilter::All => visibility.all_photos,
            SidebarFilter::Favorites => visibility.favourites,
            SidebarFilter::RecentlyAdded => visibility.recently_added,
            _ => true,
        };
        row.set_visible(visible);
    }
}

fn populate_library(list: &gtk::ListBox, counts: SidebarCounts, on_unavailable: &Rc<dyn Fn()>) {
    append_filter(
        list,
        "image-x-generic-symbolic",
        "All Photos",
        None,
        Some(counts.photos),
        SidebarFilter::All,
        false,
        on_unavailable,
    );
    append_filter(
        list,
        "emote-love-symbolic",
        "Favourites",
        None,
        Some(counts.favorites),
        SidebarFilter::Favorites,
        false,
        on_unavailable,
    );
    append_filter(
        list,
        "appointment-soon-symbolic",
        "Recently Added",
        None,
        Some(counts.recently_added),
        SidebarFilter::RecentlyAdded,
        false,
        on_unavailable,
    );
    append_filter(
        list,
        "document-open-recent-symbolic",
        "History",
        None,
        None,
        SidebarFilter::History,
        false,
        on_unavailable,
    );
}

fn list_natural_height_for_rows(list: &gtk::ListBox, max_rows: usize) -> i32 {
    if max_rows == 0 {
        return 0;
    }

    let mut height = 0;
    let mut rows = 0;
    let mut child = list.first_child();
    while let Some(widget) = child {
        let next = widget.next_sibling();
        if let Ok(row) = widget.downcast::<gtk::ListBoxRow>() {
            let (_, natural, _, _) = row.measure(gtk::Orientation::Vertical, -1);
            height += natural.max(0);
            rows += 1;
            if rows >= max_rows {
                break;
            }
        }
        child = next;
    }
    height
}

fn populate_albums(list: &gtk::ListBox, albums: &[Album], on_delete_album: &Rc<dyn Fn(i64)>) {
    for album in albums {
        append_album_filter(list, album, on_delete_album);
    }
}

fn album_icon_name() -> &'static str {
    if let Some(display) = gtk::gdk::Display::default() {
        let icon_theme = gtk::IconTheme::for_display(&display);
        if icon_theme.has_icon("folder-pictures-symbolic") {
            return "folder-pictures-symbolic";
        }
    }
    "image-x-generic-symbolic"
}

fn populate_folders(
    list: &gtk::ListBox,
    folders: &[Folder],
    state: &Rc<RefCell<SidebarState>>,
    on_unavailable: &Rc<dyn Fn()>,
) {
    // Filter for every rebuild path, not just refresh_folder_rows(): startup,
    // change-of-view and scan events all pass through this function. Network
    // share roots belong to the Network Shares section, never to Folders.
    let local_folders: Vec<Folder> = folders
        .iter()
        .filter(|folder| !crate::db::is_remote_path(&folder.path))
        .cloned()
        .collect();
    let folders = local_folders.as_slice();
    unsafe {
        list.set_data("picasa-folder-cache", folders.to_vec());
        list.set_data("picasa-folder-unavailable-callback", on_unavailable.clone());
    }

    if folders.is_empty() {
        return;
    }

    if state.borrow().folder_display_mode == FolderDisplayMode::ImportedOnly {
        let mut imported = folders
            .iter()
            .filter(|folder| folder.imported_root)
            .collect::<Vec<_>>();
        imported.sort_by(|left, right| {
            left.name
                .to_lowercase()
                .cmp(&right.name.to_lowercase())
                .then_with(|| left.path.to_lowercase().cmp(&right.path.to_lowercase()))
        });
        for folder in imported {
            // Flat/Picasa-style mode deliberately shows only the folder the
            // user explicitly imported. The row title is the basename (for
            // example "Pictures"), while the full path remains a tooltip.
            append_folder_row(list, folder, 0, false, state, on_unavailable);
        }
        return;
    }

    let visible_folders = folders
        .iter()
        .filter(|folder| folder.photo_count > 0)
        .collect::<Vec<_>>();
    let by_id: HashMap<i64, &Folder> = visible_folders
        .iter()
        .map(|folder| (folder.id, *folder))
        .collect();
    let mut children: HashMap<Option<i64>, Vec<i64>> = HashMap::new();
    for folder in visible_folders {
        // imported_root controls scan scope only. It must not flatten an
        // explicitly imported folder out of its visual hierarchy; otherwise
        // synthetic parents such as /mnt/steam cannot collapse their children.
        children
            .entry(folder.parent_id)
            .or_default()
            .push(folder.id);
    }

    for ids in children.values_mut() {
        ids.sort_by(|left, right| {
            let left = by_id.get(left).expect("folder id exists");
            let right = by_id.get(right).expect("folder id exists");
            left.name
                .to_lowercase()
                .cmp(&right.name.to_lowercase())
                .then_with(|| left.path.to_lowercase().cmp(&right.path.to_lowercase()))
        });
    }

    let roots = children.get(&None).cloned().unwrap_or_default();
    for id in roots {
        append_folder_branch(list, id, 0, &by_id, &children, state, on_unavailable);
    }
}

fn append_folder_branch(
    list: &gtk::ListBox,
    folder_id: i64,
    depth: usize,
    by_id: &HashMap<i64, &Folder>,
    children: &HashMap<Option<i64>, Vec<i64>>,
    state: &Rc<RefCell<SidebarState>>,
    on_unavailable: &Rc<dyn Fn()>,
) {
    let Some(folder) = by_id.get(&folder_id).copied() else {
        return;
    };
    let has_children = children
        .get(&Some(folder_id))
        .is_some_and(|items| !items.is_empty());

    append_folder_row(list, folder, depth, has_children, state, on_unavailable);

    if has_children && state.borrow().expanded_folders.contains(&folder_id) {
        if let Some(child_ids) = children.get(&Some(folder_id)) {
            for child_id in child_ids {
                append_folder_branch(
                    list,
                    *child_id,
                    depth + 1,
                    by_id,
                    children,
                    state,
                    on_unavailable,
                );
            }
        }
    }
}

/// Registered network shares (imported smb:// and nfs:// roots) and their
/// indexed descendants. Presented as a tree in their own sidebar section,
/// separate from local folders, and rebuilt by every folder refresh path.
fn refresh_network_shares(
    scrolled: &gtk::ScrolledWindow,
    folders: &[Folder],
    state: &Rc<RefCell<SidebarState>>,
    on_unavailable: &Rc<dyn Fn()>,
) {
    let Some(list) = stored_widget::<gtk::ListBox>(scrolled, SHARE_LIST_KEY) else {
        return;
    };
    clear_list(&list);
    let roots = folders
        .iter()
        .filter(|folder| folder.imported_root && crate::db::is_remote_path(&folder.path))
        .cloned()
        .collect::<Vec<_>>();
    let shares_exist = !roots.is_empty();
    list.set_visible(shares_exist);
    let all_remote_folders = folders
        .iter()
        .filter(|folder| crate::db::is_remote_path(&folder.path))
        .cloned()
        .collect::<Vec<_>>();
    let remote_by_id: HashMap<i64, &Folder> = all_remote_folders
        .iter()
        .map(|folder| (folder.id, folder))
        .collect();
    let mut children: HashMap<i64, Vec<i64>> = HashMap::new();
    for folder in &all_remote_folders {
        if let Some(parent) = folder
            .parent_id
            .filter(|parent| remote_by_id.contains_key(parent))
        {
            children.entry(parent).or_default().push(folder.id);
        }
    }
    let mut included = HashSet::new();
    let mut pending = roots.iter().map(|folder| folder.id).collect::<Vec<_>>();
    while let Some(id) = pending.pop() {
        if !included.insert(id) {
            continue;
        }
        if let Some(descendants) = children.get(&id) {
            pending.extend_from_slice(descendants);
        }
    }
    let remote_folders = all_remote_folders
        .into_iter()
        .filter(|folder| included.contains(&folder.id))
        .collect::<Vec<_>>();
    unsafe {
        list.set_data("picasa-network-share-tree", true);
        list.set_data("picasa-folder-unavailable-callback", on_unavailable.clone());
        list.set_data("picasa-folder-cache", remote_folders.clone());
    }
    if !shares_exist {
        return;
    }
    if state.borrow().network_tree_mode {
        populate_network_folder_tree(&list, &remote_folders, state, on_unavailable);
    } else {
        populate_network_share_roots(&list, &roots, state, on_unavailable);
    }
}

fn populate_network_share_roots(
    list: &gtk::ListBox,
    roots: &[Folder],
    state: &Rc<RefCell<SidebarState>>,
    on_unavailable: &Rc<dyn Fn()>,
) {
    let previous_mode = state.borrow().folder_display_mode;
    state.borrow_mut().folder_display_mode = FolderDisplayMode::ImportedOnly;
    let mut roots = roots.iter().collect::<Vec<_>>();
    roots.sort_by(|left, right| {
        left.name
            .to_lowercase()
            .cmp(&right.name.to_lowercase())
            .then_with(|| left.path.to_lowercase().cmp(&right.path.to_lowercase()))
    });
    for folder in roots {
        append_folder_row(list, folder, 0, false, state, on_unavailable);
    }
    state.borrow_mut().folder_display_mode = previous_mode;
}

fn populate_network_folder_tree(
    list: &gtk::ListBox,
    folders: &[Folder],
    state: &Rc<RefCell<SidebarState>>,
    on_unavailable: &Rc<dyn Fn()>,
) {
    let by_id: HashMap<i64, &Folder> = folders.iter().map(|folder| (folder.id, folder)).collect();
    let mut children: HashMap<Option<i64>, Vec<i64>> = HashMap::new();
    for folder in folders {
        let parent = folder.parent_id.filter(|parent| by_id.contains_key(parent));
        children.entry(parent).or_default().push(folder.id);
    }
    for ids in children.values_mut() {
        ids.sort_by(|left, right| {
            let left = by_id.get(left).expect("folder id exists");
            let right = by_id.get(right).expect("folder id exists");
            left.name
                .to_lowercase()
                .cmp(&right.name.to_lowercase())
                .then_with(|| left.path.to_lowercase().cmp(&right.path.to_lowercase()))
        });
    }
    for id in children.get(&None).cloned().unwrap_or_default() {
        append_folder_branch(list, id, 0, &by_id, &children, state, on_unavailable);
    }
}

fn append_folder_row(
    list: &gtk::ListBox,
    folder: &Folder,
    depth: usize,
    has_children: bool,
    state: &Rc<RefCell<SidebarState>>,
    on_unavailable: &Rc<dyn Fn()>,
) -> gtk::ListBoxRow {
    let row = gtk::ListBoxRow::new();
    row.set_margin_top(2);
    row.set_margin_bottom(2);

    let content = gtk::Box::new(gtk::Orientation::Horizontal, 4);
    content.set_margin_top(4);
    content.set_margin_bottom(4);
    content.set_margin_start(4);
    content.set_margin_end(8);

    // Tree mode reserves a fixed chevron slot so folder icons and names align
    // at every depth. Imported-only mode is flat (no subfolders), so skip it
    // and left-align the folder icons with the Library rows.
    let reserve_disclosure =
        has_children || state.borrow().folder_display_mode == FolderDisplayMode::Tree;
    if reserve_disclosure {
        let disclosure_slot = gtk::Box::new(gtk::Orientation::Horizontal, 0);
        disclosure_slot.set_size_request(12, 18);
        disclosure_slot.set_width_request(12);
        if has_children {
            let expanded = state.borrow().expanded_folders.contains(&folder.id);
            let disclosure = gtk::Image::from_icon_name(if expanded {
                "pan-down-symbolic"
            } else {
                "pan-end-symbolic"
            });
            disclosure.add_css_class("folder-disclosure");
            disclosure.set_pixel_size(10);
            disclosure.set_halign(gtk::Align::Center);
            disclosure.set_valign(gtk::Align::Center);
            disclosure_slot.set_tooltip_text(Some(if expanded {
                "Collapse folder"
            } else {
                "Show subfolders"
            }));

            let folder_id = folder.id;
            let list_for_toggle = list.clone();
            let state_for_toggle = state.clone();
            let toggle = gtk::GestureClick::new();
            toggle.connect_pressed(move |gesture, _, _, _| {
                {
                    let mut state = state_for_toggle.borrow_mut();
                    if !state.expanded_folders.remove(&folder_id) {
                        state.expanded_folders.insert(folder_id);
                    }
                }
                // Rebuilding just the folder section requires the complete folder
                // data, which refresh() owns. Mark the row's requested state now;
                // GTK will show the updated tree on the next sidebar refresh.
                // To make expansion immediate, store a synthetic toggle marker and
                // let rebuild_folder_list_from_rows() reconstruct from row data.
                rebuild_folder_list_from_rows(&list_for_toggle, &state_for_toggle);
                gesture.set_state(gtk::EventSequenceState::Claimed);
            });
            disclosure_slot.add_controller(toggle);
            disclosure_slot.append(&disclosure);
        }
        content.append(&disclosure_slot);
    }

    let icon_overlay = gtk::Overlay::new();
    icon_overlay.set_size_request(18, 18);
    icon_overlay.set_halign(gtk::Align::Center);
    icon_overlay.set_valign(gtk::Align::Center);
    icon_overlay.set_hexpand(false);
    let icon = gtk::Image::from_icon_name("folder-symbolic");
    icon.set_pixel_size(18);
    icon_overlay.set_child(Some(&icon));

    if folder.watched {
        // A small eye emblem makes watched folders visible at a glance while
        // preserving the normal folder icon and row alignment.
        let watch_badge = gtk::Image::from_icon_name("view-reveal-symbolic");
        watch_badge.set_pixel_size(10);
        watch_badge.set_halign(gtk::Align::End);
        watch_badge.set_valign(gtk::Align::End);
        watch_badge.set_tooltip_text(Some("Watched folder"));
        icon_overlay.add_overlay(&watch_badge);
        icon_overlay.set_tooltip_text(Some("Watched folder"));
    }

    content.append(&icon_overlay);

    let labels = gtk::Box::new(gtk::Orientation::Vertical, 1);
    labels.set_hexpand(true);
    let title_label = gtk::Label::new(Some(&folder.name));
    title_label.set_xalign(0.0);
    title_label.set_ellipsize(gtk::pango::EllipsizeMode::End);
    labels.append(&title_label);
    content.append(&labels);

    let trailing = gtk::Box::new(gtk::Orientation::Horizontal, 6);
    let count_label = gtk::Label::new(Some(&format_count(folder.photo_count)));
    count_label.set_width_request(36);
    count_label.set_xalign(1.0);
    count_label.set_valign(gtk::Align::Center);
    count_label.add_css_class("dim-label");
    count_label.add_css_class("sidebar-count");
    count_label.add_css_class("folder-count");
    trailing.append(&count_label);

    if !folder.available {
        let warning = gtk::Button::with_label("!");
        warning.add_css_class("sidebar-offline-badge");
        warning.set_halign(gtk::Align::Center);
        warning.set_valign(gtk::Align::Center);
        warning.set_width_request(16);
        warning.set_height_request(16);
        warning.set_tooltip_text(Some("Source folder unavailable"));
        let on_unavailable = on_unavailable.clone();
        warning.connect_clicked(move |_| (on_unavailable)());
        trailing.append(&warning);
    }
    content.append(&trailing);

    row.set_child(Some(&content));
    if has_children {
        let folder_id = folder.id;
        let list_for_double_click = list.clone();
        let state_for_double_click = state.clone();
        let double_click = gtk::GestureClick::new();
        double_click.set_button(1);
        double_click.connect_pressed(move |gesture, n_press, _, _| {
            if n_press == 2 {
                let mut state = state_for_double_click.borrow_mut();
                if !state.expanded_folders.remove(&folder_id) {
                    state.expanded_folders.insert(folder_id);
                }
                drop(state);
                rebuild_folder_list_from_rows(&list_for_double_click, &state_for_double_click);
                gesture.set_state(gtk::EventSequenceState::Claimed);
            }
        });
        row.add_controller(double_click);
    }
    if folder.imported_root {
        row.set_tooltip_text(Some(&folder.path));
    }
    unsafe {
        row.set_data("picasa-filter", SidebarFilter::Folder(folder.id));
        row.set_data("picasa-folder-record", folder.clone());
        row.set_data("picasa-folder-depth", depth);
        row.set_data("picasa-folder-has-children", has_children);
        row.set_data("picasa-folder-unavailable-callback", on_unavailable.clone());
    }
    list.append(&row);
    add_folder_context_menu(&list, &row, folder);
    row
}

fn add_folder_context_menu(list: &gtk::ListBox, row: &gtk::ListBoxRow, folder: &Folder) {
    let refresh = unsafe {
        list.data::<Rc<dyn Fn(String)>>(FOLDER_REFRESH_KEY)
            .map(|callback| callback.as_ref().clone())
    };
    let statistics = unsafe {
        list.data::<Rc<dyn Fn(Folder)>>(FOLDER_STATISTICS_KEY)
            .map(|callback| callback.as_ref().clone())
    };
    let remove = unsafe {
        list.data::<Rc<dyn Fn(Folder)>>(FOLDER_REMOVE_KEY)
            .map(|callback| callback.as_ref().clone())
    };
    let favorite = unsafe {
        list.data::<Rc<dyn Fn(Folder, bool)>>(FOLDER_FAVORITE_KEY)
            .map(|callback| callback.as_ref().clone())
    };
    let watch = unsafe {
        list.data::<Rc<dyn Fn(Folder, bool)>>(FOLDER_WATCH_KEY)
            .map(|callback| callback.as_ref().clone())
    };
    let Some(refresh) = refresh else {
        return;
    };
    let Some(statistics) = statistics else {
        return;
    };
    let Some(remove) = remove else {
        return;
    };
    let Some(favorite) = favorite else {
        return;
    };
    let Some(watch) = watch else {
        return;
    };

    let folder_for_menu = folder.clone();
    let row_for_menu = row.clone();
    let list_for_refresh_gate = list.downgrade();
    let right_click = gtk::GestureClick::new();
    right_click.set_button(3);
    right_click.connect_pressed(move |gesture, _, _, _| {
        let popover = gtk::Popover::new();
        popover.set_has_arrow(true);
        popover.set_parent(&row_for_menu);
        let menu = gtk::Box::new(gtk::Orientation::Vertical, 2);
        menu.set_margin_top(6);
        menu.set_margin_bottom(6);
        menu.set_margin_start(6);
        menu.set_margin_end(6);

        let refresh_item = gtk::Button::with_label("Refresh folder");
        refresh_item.add_css_class("flat");
        refresh_item.set_sensitive(folder_for_menu.imported_root);
        if folder_for_menu.imported_root {
            let gate = list_for_refresh_gate.upgrade().and_then(|list| unsafe {
                list.data::<glib::WeakRef<gtk::Button>>(REFRESH_GATE_KEY)
                    .and_then(|gate| gate.as_ref().upgrade())
            });
            if let Some(gate) = gate {
                gate.bind_property("sensitive", &refresh_item, "sensitive")
                    .sync_create()
                    .build();
            }
        }
        if !folder_for_menu.imported_root {
            refresh_item
                .set_tooltip_text(Some("Only explicitly imported folders can be refreshed"));
        }
        let path = folder_for_menu.path.clone();
        let popover_for_refresh = popover.clone();
        let refresh = refresh.clone();
        refresh_item.connect_clicked(move |_| {
            popover_for_refresh.popdown();
            refresh(path.clone());
        });
        menu.append(&refresh_item);

        let watch_item = gtk::Button::with_label(if folder_for_menu.watched {
            "Stop Watching Folder"
        } else {
            "Watch Folder"
        });
        watch_item.add_css_class("flat");
        let folder = folder_for_menu.clone();
        let watch = watch.clone();
        let watched = !folder_for_menu.watched;
        let popover_for_watch = popover.clone();
        watch_item.connect_clicked(move |_| {
            popover_for_watch.popdown();
            watch(folder.clone(), watched);
        });
        menu.append(&watch_item);

        let statistics_item = gtk::Button::with_label("Folder statistics");
        statistics_item.add_css_class("flat");
        let folder = folder_for_menu.clone();
        let statistics = statistics.clone();
        let popover_for_statistics = popover.clone();
        statistics_item.connect_clicked(move |_| {
            popover_for_statistics.popdown();
            statistics(folder.clone());
        });
        menu.append(&statistics_item);

        let remove_item = gtk::Button::with_label("Remove from Library");
        remove_item.add_css_class("flat");
        remove_item.add_css_class("destructive-action");
        let folder = folder_for_menu.clone();
        let remove = remove.clone();
        let popover_for_remove = popover.clone();
        remove_item.connect_clicked(move |_| {
            popover_for_remove.popdown();
            remove(folder.clone());
        });
        menu.append(&remove_item);

        let add_favorites = gtk::Button::with_label("Add all photos to Favourites");
        add_favorites.add_css_class("flat");
        let folder = folder_for_menu.clone();
        let favorite_for_add = favorite.clone();
        let popover_for_add = popover.clone();
        add_favorites.connect_clicked(move |_| {
            popover_for_add.popdown();
            favorite_for_add(folder.clone(), true);
        });
        menu.append(&add_favorites);

        let remove_favorites = gtk::Button::with_label("Remove all photos from Favourites");
        remove_favorites.add_css_class("flat");
        let folder = folder_for_menu.clone();
        let favorite = favorite.clone();
        let popover_for_remove = popover.clone();
        remove_favorites.connect_clicked(move |_| {
            popover_for_remove.popdown();
            favorite(folder.clone(), false);
        });
        menu.append(&remove_favorites);

        popover.set_child(Some(&menu));
        popover.popup();
        gesture.set_state(gtk::EventSequenceState::Claimed);
    });
    row.add_controller(right_click);
}

// Folder expansion must be immediate, but the public toggle callback does not
// have the original &[Folder]. Every visible row therefore keeps its Folder
// record. We collect the full currently-known set from visible rows plus hidden
// descendants cached on the ListBox itself when populate_folders() runs.
fn rebuild_folder_list_from_rows(list: &gtk::ListBox, state: &Rc<RefCell<SidebarState>>) {
    let is_network_tree = unsafe {
        list.data::<bool>("picasa-network-share-tree")
            .is_some_and(|data| *data.as_ref())
    };
    let folder_scroll = list
        .ancestor(gtk::ScrolledWindow::static_type())
        .and_then(|widget| widget.downcast::<gtk::ScrolledWindow>().ok());
    let outer = folder_scroll.as_ref().and_then(|folder_scroll| {
        folder_scroll
            .ancestor(gtk::ScrolledWindow::static_type())
            .and_then(|widget| widget.downcast::<gtk::ScrolledWindow>().ok())
    });
    let list_scroll_value = folder_scroll
        .as_ref()
        .map(|scroll| scroll.vadjustment().value());
    let folder_scroll_value = (!is_network_tree)
        .then(|| outer.as_ref().and_then(|outer| folder_scroll_value(outer)))
        .flatten();
    let folders = unsafe {
        list.data::<Vec<Folder>>("picasa-folder-cache")
            .map(|data| data.as_ref().clone())
            .unwrap_or_default()
    };
    let callback = unsafe {
        list.data::<Rc<dyn Fn()>>("picasa-folder-unavailable-callback")
            .map(|data| data.as_ref().clone())
            .unwrap_or_else(|| Rc::new(|| {}))
    };
    if folders.is_empty() {
        return;
    }
    clear_list(list);
    if is_network_tree {
        populate_network_folder_tree(list, &folders, state, &callback);
    } else {
        populate_folders(list, &folders, state, &callback);
    }
    if let Some(outer) = outer {
        if let Some(filter) = current_filter(&outer) {
            set_active_filter(&outer, filter);
        }
        if is_network_tree {
            if let (Some(scroll), Some(value)) = (folder_scroll, list_scroll_value) {
                let adjustment = scroll.vadjustment();
                glib::idle_add_local_once(move || {
                    let upper =
                        (adjustment.upper() - adjustment.page_size()).max(adjustment.lower());
                    adjustment.set_value(value.clamp(adjustment.lower(), upper));
                });
            }
        } else {
            restore_folder_scroll(&outer, folder_scroll_value);
        }
        let outer_for_location = outer.clone();
        glib::idle_add_local_once(move || apply_scroll_location(&outer_for_location));
    }
}

fn append_filter(
    list: &gtk::ListBox,
    icon_name: &str,
    title: &str,
    subtitle: Option<&str>,
    count: Option<i64>,
    filter: SidebarFilter,
    offline: bool,
    on_unavailable: &Rc<dyn Fn()>,
) -> gtk::ListBoxRow {
    let row = gtk::ListBoxRow::new();
    row.set_margin_top(2);
    row.set_margin_bottom(2);
    let content = gtk::Box::new(gtk::Orientation::Horizontal, 8);
    content.set_margin_top(6);
    content.set_margin_bottom(6);
    content.set_margin_start(8);
    content.set_margin_end(8);
    let icon = gtk::Image::from_icon_name(icon_name);
    icon.set_pixel_size(18);
    content.append(&icon);
    let labels = gtk::Box::new(gtk::Orientation::Vertical, 1);
    let title_label = gtk::Label::new(Some(title));
    title_label.set_xalign(0.0);
    title_label.set_ellipsize(gtk::pango::EllipsizeMode::End);
    labels.append(&title_label);
    if let Some(subtitle) = subtitle {
        let subtitle_label = gtk::Label::new(Some(subtitle));
        subtitle_label.set_xalign(0.0);
        subtitle_label.set_ellipsize(gtk::pango::EllipsizeMode::Middle);
        subtitle_label.add_css_class("dim-label");
        labels.append(&subtitle_label);
    }
    labels.set_hexpand(true);
    content.append(&labels);

    if let Some(count) = count {
        let count_label = gtk::Label::new(Some(&format_count(count)));
        count_label.set_xalign(1.0);
        count_label.set_valign(gtk::Align::Center);
        count_label.add_css_class("dim-label");
        count_label.add_css_class("sidebar-count");
        content.append(&count_label);
        unsafe {
            row.set_data(FILTER_COUNT_LABEL_KEY, count_label);
        }
    }

    if offline {
        let warning = gtk::Button::with_label("!");
        warning.add_css_class("sidebar-offline-badge");
        warning.set_halign(gtk::Align::Center);
        warning.set_valign(gtk::Align::Center);
        warning.set_width_request(16);
        warning.set_height_request(16);
        warning.set_tooltip_text(Some("Source folder unavailable"));
        let on_unavailable = on_unavailable.clone();
        warning.connect_clicked(move |_| (on_unavailable)());
        content.append(&warning);
    }
    row.set_child(Some(&content));
    unsafe {
        row.set_data("picasa-filter", filter);
    }
    list.append(&row);
    row
}

fn append_album_filter(list: &gtk::ListBox, album: &Album, on_delete: &Rc<dyn Fn(i64)>) {
    let no_unavailable_action: Rc<dyn Fn()> = Rc::new(|| {});
    let row = append_filter(
        list,
        album_icon_name(),
        &album.name,
        None,
        Some(album.photo_count),
        SidebarFilter::Album(album.id),
        false,
        &no_unavailable_action,
    );
    let album_id = album.id;
    let on_delete = on_delete.clone();
    let row_for_menu = row.clone();
    let right_click = gtk::GestureClick::new();
    right_click.set_button(3);
    right_click.connect_pressed(move |gesture, _, _, _| {
        let popover = gtk::Popover::new();
        popover.set_has_arrow(true);
        popover.set_parent(&row_for_menu);
        let delete = gtk::Button::with_label("Delete Album");
        delete.add_css_class("flat");
        delete.add_css_class("destructive-action");
        let on_delete = on_delete.clone();
        let popover_for_delete = popover.clone();
        delete.connect_clicked(move |_| {
            popover_for_delete.popdown();
            on_delete(album_id);
        });
        popover.set_child(Some(&delete));
        popover.popup();
        gesture.set_state(gtk::EventSequenceState::Claimed);
    });
    row.add_controller(right_click);
}

fn set_folder_mode_toggle_presentation(button: &gtk::Button, mode: FolderDisplayMode) {
    match mode {
        FolderDisplayMode::Tree => {
            button.set_icon_name("folder-symbolic");
            button.set_tooltip_text(Some("Show imported folders only"));
        }
        FolderDisplayMode::ImportedOnly => {
            button.set_icon_name("view-list-symbolic");
            button.set_tooltip_text(Some("Show folder tree"));
        }
    }
}

fn set_share_mode_toggle_presentation(button: &gtk::Button, tree_mode: bool) {
    if tree_mode {
        button.set_icon_name("folder-symbolic");
        button.set_tooltip_text(Some("Show imported shares only"));
    } else {
        button.set_icon_name("view-list-symbolic");
        button.set_tooltip_text(Some("Show network folder tree"));
    }
}

fn sidebar_pane_ease(t: f64) -> f64 {
    let t = t.clamp(0.0, 1.0);
    // Smoothstep: zero velocity at both ends, so the pane does not visibly
    // snap when the Revealer starts or when the native handle disappears.
    t * t * (3.0 - 2.0 * t)
}

fn animate_sidebar_pane_position(
    paned: &gtk::Paned,
    from: i32,
    to: i32,
    generation: Rc<Cell<u64>>,
    expected_generation: u64,
    animating: Rc<Cell<bool>>,
    on_complete: Option<Rc<dyn Fn()>>,
) {
    if from == to {
        if generation.get() == expected_generation {
            paned.set_position(to);
            animating.set(false);
            if let Some(callback) = on_complete.as_ref() {
                callback();
            }
        }
        return;
    }

    let started = std::time::Instant::now();
    paned.add_tick_callback(move |paned, _| {
        if generation.get() != expected_generation {
            return glib::ControlFlow::Break;
        }

        let elapsed_ms = started.elapsed().as_secs_f64() * 1000.0;
        let progress = (elapsed_ms / f64::from(ALBUM_PANE_ANIMATION_MS)).clamp(0.0, 1.0);
        let eased = sidebar_pane_ease(progress);
        let position = f64::from(from) + f64::from(to - from) * eased;
        paned.set_position(position.round() as i32);

        if progress >= 1.0 {
            paned.set_position(to);
            animating.set(false);
            if let Some(callback) = on_complete.as_ref() {
                callback();
            }
            glib::ControlFlow::Break
        } else {
            glib::ControlFlow::Continue
        }
    });
}

fn collapsible_heading(
    text: &str,
    action: Option<Rc<dyn Fn()>>,
    action_tooltip: &str,
    expanded: bool,
    title_action: Option<Rc<dyn Fn()>>,
) -> (gtk::Box, gtk::Button) {
    let content = gtk::Box::new(gtk::Orientation::Horizontal, 4);
    content.add_css_class("sidebar-section-heading");
    content.set_hexpand(true);
    content.set_margin_start(8);
    content.set_margin_end(8);
    content.set_margin_top(8);
    content.set_margin_bottom(4);

    let label = gtk::Label::new(Some(text));
    label.set_xalign(0.0);
    label.set_hexpand(true);
    label.add_css_class("sidebar-section-heading-title");
    if let Some(title_action) = title_action {
        let click = gtk::GestureClick::new();
        // Left button only: the section heading itself carries a right-click
        // Reveal All / Collapse All menu, which must not be swallowed here.
        click.set_button(1);
        click.connect_pressed(move |gesture, _, _, _| {
            title_action();
            gesture.set_state(gtk::EventSequenceState::Claimed);
        });
        label.add_controller(click);
    }
    content.append(&label);

    // Keep the disclosure control rightmost. Any section-specific action sits
    // before it, so headings read consistently as: action / + / collapse.
    if let Some(action) = action {
        let add = gtk::Button::from_icon_name("list-add-symbolic");
        add.add_css_class("flat");
        add.set_size_request(24, 24);
        add.set_tooltip_text(Some(action_tooltip));
        add.connect_clicked(move |_| action());
        content.append(&add);
    }

    let indicator = gtk::Button::from_icon_name(if expanded {
        "pan-down-symbolic"
    } else {
        "pan-end-symbolic"
    });
    indicator.add_css_class("flat");
    indicator.set_focusable(false);
    indicator.set_size_request(24, 24);
    indicator.set_tooltip_text(Some(if expanded { "Collapse" } else { "Expand" }));
    content.append(&indicator);

    (content, indicator)
}

/// Right-click context menu on a section heading: Reveal All / Collapse All.
/// Items appear only when they have something to do: Reveal All while the
/// section (or any nested branch) is hidden, Collapse All while anything is
/// expanded. Uses the same Popover + flat-button construction as the folder
/// context menu, so styling matches the rest of the sidebar. Closes on item
/// activation or on any click outside; left-click behaviour is untouched.
fn attach_section_context_menu(
    heading: &gtk::Box,
    show_reveal: Rc<dyn Fn() -> bool>,
    show_collapse: Rc<dyn Fn() -> bool>,
    on_reveal: Rc<dyn Fn()>,
    on_collapse: Rc<dyn Fn()>,
) {
    let heading = heading.clone();
    let heading_for_controller = heading.clone();
    let right_click = gtk::GestureClick::new();
    right_click.set_button(3);
    right_click.connect_pressed(move |gesture, _, x, y| {
        let reveal_visible = show_reveal();
        let collapse_visible = show_collapse();
        if !reveal_visible && !collapse_visible {
            gesture.set_state(gtk::EventSequenceState::Claimed);
            return;
        }

        let popover = gtk::Popover::new();
        popover.set_has_arrow(false);
        // This menu is the right-click companion to the disclosure button's
        // Collapse/Expand tooltip. Keep the same compact tooltip presentation
        // for both Reveal All and Collapse All instead of inheriting a large
        // theme-specific popover surface.
        popover.add_css_class("sidebar-section-tooltip-menu");
        popover.set_parent(&heading);
        // Match GTK's tooltip child spacing. The tooltip-style popover surface
        // owns the padding, so a second set of menu margins would make this
        // visibly larger than the disclosure button's native tooltip.
        let menu = gtk::Box::new(gtk::Orientation::Vertical, 6);

        if reveal_visible {
            let item = gtk::Button::with_label("Reveal All");
            item.add_css_class("flat");
            item.add_css_class("sidebar-section-tooltip-item");
            let popover_for_reveal = popover.clone();
            let reveal = on_reveal.clone();
            item.connect_clicked(move |_| {
                popover_for_reveal.popdown();
                reveal();
            });
            menu.append(&item);
        }

        if collapse_visible {
            let item = gtk::Button::with_label("Collapse All");
            item.add_css_class("flat");
            item.add_css_class("sidebar-section-tooltip-item");
            let popover_for_collapse = popover.clone();
            let collapse = on_collapse.clone();
            item.connect_clicked(move |_| {
                popover_for_collapse.popdown();
                collapse();
            });
            menu.append(&item);
        }

        popover.set_child(Some(&menu));
        popover.set_pointing_to(Some(&gtk::gdk::Rectangle::new(x as i32, y as i32, 1, 1)));
        popover.popup();
        gesture.set_state(gtk::EventSequenceState::Claimed);
    });
    heading_for_controller.add_controller(right_click);
}

/// Folder ids that have at least one child, computed from the cached folder
/// list; these are the nested branches the Reveal/Collapse All actions act on.
fn folder_ids_with_children(folders: &[Folder]) -> Vec<i64> {
    let mut parents: Vec<i64> = folders
        .iter()
        .filter_map(|folder| folder.parent_id)
        .collect();
    parents.sort_unstable();
    parents.dedup();
    parents
}

fn format_count(value: i64) -> String {
    let negative = value < 0;
    let digits = value.unsigned_abs().to_string();
    let mut grouped = String::with_capacity(digits.len() + digits.len() / 3);
    for (index, ch) in digits.chars().enumerate() {
        if index > 0 && (digits.len() - index) % 3 == 0 {
            grouped.push(',');
        }
        grouped.push(ch);
    }
    if negative {
        format!("-{grouped}")
    } else {
        grouped
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    #[ignore = "requires a GTK display; run with --ignored --test-threads=1"]
    fn progressive_count_update_preserves_sidebar_rows() {
        gtk::init().unwrap();
        let no_args: Rc<dyn Fn()> = Rc::new(|| {});
        let list = gtk::ListBox::new();
        populate_library(
            &list,
            SidebarCounts {
                photos: 10,
                favorites: 2,
                recently_added: 10,
            },
            &no_args,
        );
        let all_row = row_for_filter(&list, SidebarFilter::All).unwrap();
        let sidebar = gtk::ScrolledWindow::new();
        unsafe {
            sidebar.set_data(LIBRARY_LIST_KEY, list);
        }

        update_library_counts(
            &sidebar,
            SidebarCounts {
                photos: 12_345,
                favorites: 7,
                recently_added: 100,
            },
        );

        let current_row = {
            let list = stored_widget::<gtk::ListBox>(&sidebar, LIBRARY_LIST_KEY).unwrap();
            row_for_filter(&list, SidebarFilter::All).unwrap()
        };
        assert_eq!(all_row, current_row);
        let count = unsafe {
            current_row
                .data::<gtk::Label>(FILTER_COUNT_LABEL_KEY)
                .unwrap()
        };
        assert_eq!(unsafe { count.as_ref() }.text(), "12,345");
    }

    #[test]
    fn sidebar_visibility_defaults_to_on_and_restores_saved_switches() {
        let connection = rusqlite::Connection::open_in_memory().unwrap();
        connection
            .execute_batch("CREATE TABLE settings (key TEXT PRIMARY KEY, value TEXT NOT NULL)")
            .unwrap();

        assert_eq!(
            SidebarVisibility::from_connection(&connection),
            SidebarVisibility::default()
        );

        crate::db::set_setting(&connection, ALBUMS_VISIBLE_SETTING_KEY, "false").unwrap();
        crate::db::set_setting(&connection, FAVOURITES_VISIBLE_SETTING_KEY, "false").unwrap();
        let visibility = SidebarVisibility::from_connection(&connection);
        assert!(!visibility.albums);
        assert!(!visibility.favourites);
        assert!(visibility.library);
        assert!(visibility.folders);
    }

    #[test]
    #[ignore = "requires a GTK display; run with --ignored --test-threads=1"]
    fn saved_network_shares_populate_at_startup_and_use_the_remaining_height() {
        gtk::init().unwrap();

        let folders = vec![
            Folder {
                id: 1,
                path: "smb://server/photos".to_string(),
                name: "photos".to_string(),
                parent_id: None,
                imported_root: true,
                watched: false,
                photo_count: 4,
                subfolder_count: 1,
                available: true,
            },
            Folder {
                id: 2,
                path: "smb://server/photos/album".to_string(),
                name: "album".to_string(),
                parent_id: Some(1),
                imported_root: false,
                watched: false,
                photo_count: 3,
                subfolder_count: 0,
                available: true,
            },
        ];
        let no_args: Rc<dyn Fn()> = Rc::new(|| {});
        let sidebar = build(
            &folders,
            &[],
            SidebarCounts {
                photos: 4,
                favorites: 0,
                recently_added: 0,
            },
            |_| {},
            no_args.clone(),
            no_args.clone(),
            no_args.clone(),
            Rc::new(|_| {}),
            no_args.clone(),
            Rc::new(|_| {}),
            Rc::new(|_| {}),
            Rc::new(|_| {}),
            Rc::new(|_, _| {}),
            Rc::new(|_, _| {}),
            FolderDisplayMode::Tree,
            Rc::new(|_| {}),
            SidebarVisibility::default(),
        );

        let share_list = stored_widget::<gtk::ListBox>(&sidebar, SHARE_LIST_KEY).unwrap();
        assert_eq!(
            share_list.observe_children().iter::<glib::Object>().count(),
            1,
            "a saved share should be the collapsed tree root"
        );
        assert!(unsafe {
            share_list
                .data::<Rc<dyn Fn(Folder)>>(FOLDER_REMOVE_KEY)
                .is_some()
        });

        let share_row = share_list
            .first_child()
            .and_then(|widget| widget.downcast::<gtk::ListBoxRow>().ok())
            .unwrap();
        let controllers = share_row.observe_controllers();
        let has_right_click = (0..controllers.n_items())
            .filter_map(|index| controllers.item(index))
            .filter_map(|controller| controller.downcast::<gtk::GestureClick>().ok())
            .any(|gesture| gesture.button() == 3);
        assert!(
            has_right_click,
            "saved shares should install the folder context menu"
        );

        let state = sidebar_state(&sidebar).unwrap();
        state.borrow_mut().expanded_folders.insert(1);
        let no_unavailable: Rc<dyn Fn()> = Rc::new(|| {});
        refresh_network_shares(&sidebar, &folders, &state, &no_unavailable);
        assert_eq!(
            share_list.observe_children().iter::<glib::Object>().count(),
            2,
            "expanding a share should reveal its indexed child folders"
        );
        let child_row = share_list
            .last_child()
            .and_then(|widget| widget.downcast::<gtk::ListBoxRow>().ok())
            .unwrap();
        assert!(unsafe {
            child_row
                .data::<SidebarFilter>("picasa-filter")
                .is_some_and(|filter| *filter.as_ref() == SidebarFilter::Folder(2))
        });
        let mode_toggle = stored_widget::<gtk::Button>(&sidebar, SHARE_MODE_TOGGLE_KEY).unwrap();
        mode_toggle.emit_clicked();
        assert_eq!(
            share_list.observe_children().iter::<glib::Object>().count(),
            1,
            "the share list mode should show imported roots only"
        );
        mode_toggle.emit_clicked();
        assert_eq!(
            share_list.observe_children().iter::<glib::Object>().count(),
            2,
            "the share tree mode should restore expanded child folders"
        );

        let share_scroll = share_list
            .ancestor(gtk::ScrolledWindow::static_type())
            .and_then(|widget| widget.downcast::<gtk::ScrolledWindow>().ok())
            .unwrap();
        assert!(share_scroll.vexpands());
        assert_eq!(share_scroll.vscrollbar_policy(), gtk::PolicyType::Automatic);
        assert_eq!(share_scroll.max_content_height(), -1);

        let share_revealer = share_scroll
            .ancestor(gtk::Revealer::static_type())
            .and_then(|widget| widget.downcast::<gtk::Revealer>().ok())
            .unwrap();
        assert!(share_revealer.vexpands());

        apply_visibility(
            &sidebar,
            SidebarVisibility {
                library: false,
                albums: false,
                folders: false,
                network_shares: false,
                all_photos: false,
                favourites: true,
                recently_added: false,
            },
        );
        assert!(!stored_widget::<gtk::Box>(&sidebar, LIBRARY_HEADING_KEY)
            .unwrap()
            .is_visible());
        assert!(!stored_widget::<gtk::Box>(&sidebar, ALBUM_HEADING_KEY)
            .unwrap()
            .is_visible());
        assert!(!stored_widget::<gtk::Box>(&sidebar, FOLDER_SECTION_KEY)
            .unwrap()
            .is_visible());
        assert!(!stored_widget::<gtk::Box>(&sidebar, SHARE_SECTION_KEY)
            .unwrap()
            .is_visible());

        apply_visibility(
            &sidebar,
            SidebarVisibility {
                library: true,
                all_photos: false,
                favourites: true,
                recently_added: false,
                ..SidebarVisibility::default()
            },
        );
        let library_list = stored_widget::<gtk::ListBox>(&sidebar, LIBRARY_LIST_KEY).unwrap();
        assert!(!row_for_filter(&library_list, SidebarFilter::All)
            .unwrap()
            .is_visible());
        assert!(row_for_filter(&library_list, SidebarFilter::Favorites)
            .unwrap()
            .is_visible());
        assert!(!row_for_filter(&library_list, SidebarFilter::RecentlyAdded)
            .unwrap()
            .is_visible());
    }
}
