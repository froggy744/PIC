pub(crate) fn set_grid_scrub_active(active: bool) {
    GRID_SCRUB_ACTIVE.with(|flag| flag.set(active));
}

pub(crate) fn set_grid_zoom_animation_active(active: bool) {
    GRID_ZOOM_ANIMATION_ACTIVE.with(|flag| flag.set(active));
}

fn grid_scrub_active() -> bool {
    GRID_SCRUB_ACTIVE.with(Cell::get)
}

fn grid_zoom_animation_active() -> bool {
    GRID_ZOOM_ANIMATION_ACTIVE.with(Cell::get)
}

fn preserve_grid_paintable_during_motion() -> bool {
    grid_scrub_active() || grid_zoom_animation_active()
}

fn folder_thumbnail_cache_get(path: &str) -> Option<gtk::gdk::Paintable> {
    FOLDER_THUMBNAIL_CACHE.with(|cache| {
        let mut cache = cache.borrow_mut();
        let index = cache
            .iter()
            .position(|(cached_path, _)| cached_path == path)?;
        let entry = cache.remove(index)?;
        let paintable = entry.1.clone();
        cache.push_back(entry);
        Some(paintable)
    })
}

fn folder_thumbnail_cache_insert(path: String, paintable: gtk::gdk::Paintable) {
    FOLDER_THUMBNAIL_CACHE.with(|cache| {
        let mut cache = cache.borrow_mut();
        cache.retain(|(cached_path, _)| cached_path != &path);
        cache.push_back((path, paintable));
        while cache.len() > FOLDER_THUMBNAIL_CACHE_CAPACITY {
            cache.pop_front();
        }
    });
}

fn folder_thumbnail_cache_remove(key: &str) {
    FOLDER_THUMBNAIL_CACHE.with(|cache| {
        cache
            .borrow_mut()
            .retain(|(cached_key, _)| cached_key != key);
    });
}

fn photo_presentation_key(photo: &PhotoObject) -> Option<String> {
    let cached = photo.cached_thumbnail_path()?;
    Some(crate::thumbnail_display::presentation_key(
        &cached,
        &photo.path(),
        photo.rotation(),
        &photo.edit_recipe(),
        photo.width(),
        photo.height(),
    ))
}

fn photo_presentation_request(
    photo: &PhotoObject,
    visible_priority: bool,
) -> Option<crate::thumbnail_display::DisplayRequest> {
    let cached = photo.cached_thumbnail_path()?;
    Some(crate::thumbnail_display::request_for(
        cached,
        photo.path(),
        photo.mtime(),
        photo.size_bytes(),
        photo.rotation(),
        photo.edit_recipe(),
        photo.width(),
        photo.height(),
        visible_priority,
    ))
}

fn queue_photo_presentation_async(photo: &PhotoObject, visible_priority: bool) -> bool {
    let Some(request) = photo_presentation_request(photo, visible_priority) else {
        return false;
    };
    if folder_thumbnail_cache_get(&request.key).is_some() {
        return false;
    }
    crate::thumbnail_display::submit(request)
}

const FILENAME_CAPTION_HEIGHT: i32 = 24;

/// Row pitch that already surrounds every tile: 6 px of CSS padding/margin on
/// the top and bottom edge of the grid item or Folder line.
const TILE_ROW_SPACING: i32 = 12;

/// Margin every folder tile keeps around its thumbnail (the padding the old
/// FlowBoxChild supplied). GTK adds it to the tile's placed position, so a
/// section heading needs the same margin to line up with the first column
/// instead of sitting 6 px to its left.
pub(crate) const FOLDER_ITEM_MARGIN: i32 = 6;

thread_local! {
    static FILENAME_LABEL_TRACE_STATS: RefCell<(u64, u128, u128)> =
        const { RefCell::new((0, 0, 0)) };
}

/// Height of the single-line filename row drawn under the square thumbnail.
/// It is always *added* to the tile: the image never gives up any of its own
/// height for the caption.
fn filename_caption_height(visible: bool) -> i32 {
    if visible {
        FILENAME_CAPTION_HEIGHT
    } else {
        0
    }
}

/// Total height of one grid item: the square thumbnail plus the optional
/// filename row below it. Every row-pitch calculation must go through this so
/// rows can never overlap a caption.
fn tile_block_height(tile_height: i32, filename_visible: bool) -> i32 {
    tile_height.max(1) + filename_caption_height(filename_visible)
}

/// Pure geometry for one tile, split out of `size_allocate` so the square-image
/// guarantee is testable without a display.
///
/// The image frame keeps the full `tile_width x tile_height` square whenever
/// the parent allocates at least that much; the caption row is laid out under
/// the square and only ever extends the block downwards.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct TileLayout {
    frame_x: i32,
    frame_y: i32,
    frame_width: i32,
    frame_height: i32,
    caption_y: i32,
    caption_height: i32,
    block_height: i32,
}

fn tile_layout(
    tile_width: i32,
    tile_height: i32,
    allocated_width: i32,
    allocated_height: i32,
    caption_visible: bool,
) -> TileLayout {
    let tile_width = tile_width.max(1);
    let tile_height = tile_height.max(1);
    let allocated_width = allocated_width.max(1);
    let allocated_height = allocated_height.max(1);
    let caption_height = filename_caption_height(caption_visible);
    let frame_width = tile_width.min(allocated_width);
    let frame_height = tile_height.min(allocated_height);
    let block_height = frame_height + caption_height;
    let frame_x = ((allocated_width - frame_width) / 2).max(0);
    let frame_y = ((allocated_height - block_height) / 2).max(0);
    TileLayout {
        frame_x,
        frame_y,
        frame_width,
        frame_height,
        caption_y: frame_y + frame_height,
        caption_height,
        block_height,
    }
}

fn update_filename_label(label: &gtk::Label, filename: &str) {
    let text_changed = label.text().as_str() != filename;
    let tooltip_changed = label.tooltip_text().as_deref() != Some(filename);
    if !text_changed && !tooltip_changed {
        return;
    }

    let tracing = std::env::var_os("PICASA_TRACE").is_some();
    let started = tracing.then(Instant::now);
    if text_changed {
        label.set_text(filename);
    }
    if tooltip_changed {
        label.set_tooltip_text(Some(filename));
    }
    let Some(started) = started else {
        return;
    };

    let elapsed_us = started.elapsed().as_micros();
    let batch = FILENAME_LABEL_TRACE_STATS.with(|stats| {
        let mut stats = stats.borrow_mut();
        stats.0 += 1;
        stats.1 += elapsed_us;
        stats.2 = stats.2.max(elapsed_us);
        if stats.0 >= 64 {
            let batch = *stats;
            *stats = (0, 0, 0);
            Some(batch)
        } else {
            None
        }
    });
    if let Some((count, total_us, max_us)) = batch {
        eprintln!(
            "PIC_FILENAME label_update_batch count={count} total_us={total_us} max_us={max_us}"
        );
    }
}

mod square_tile {
    use std::cell::{Cell, RefCell};
    use std::rc::Rc;

    use glib::subclass::prelude::*;
    use gtk::prelude::*;
    use gtk::subclass::prelude::*;
    use gtk4 as gtk;

    use crate::photo_object::PhotoObject;

    #[derive(Default)]
    pub struct SquareTile {
        pub width: Cell<i32>,
        pub height: Cell<i32>,
        // Presentation-only FLIP offset. GTK allocation remains at the real
        // destination; snapshotting is temporarily translated from the old
        // visual position while a resize reflow animates.
        pub presentation_offset_x: Cell<f32>,
        pub presentation_offset_y: Cell<f32>,
        // In-cell zoom scale. GTK allocation stays at the destination tile
        // size; snapshotting scales the image frame around its centre.
        // Zero means identity so the derived Default stays safe.
        pub presentation_scale: Cell<f32>,
        pub filename_visible: Cell<bool>,
        pub filename_label: RefCell<Option<gtk::Label>>,
        pub favorite_indicators_visible: Cell<bool>,
        pub photo: RefCell<Option<PhotoObject>>,
        pub visual_loaded: Cell<bool>,
        pub applied_visual_key: RefCell<Option<String>>,
        // Folder mode stores the backing photo index on each realized tile so
        // prefetch can warm the photo model ahead of the viewport rather than
        // being limited to GTK's currently realized widget pool.
        pub photo_index: Cell<Option<usize>>,
        // Stored so the offline badge can be created lazily on first use
        // (folder tiles no longer build it eagerly).
        pub unavailable: RefCell<Option<Rc<dyn Fn(PhotoObject, gtk::Widget)>>>,
    }

    #[glib::object_subclass]
    impl ObjectSubclass for SquareTile {
        const NAME: &'static str = "PicasaSquareTile";
        type Type = super::SquareTile;
        type ParentType = gtk::Widget;
    }

    impl ObjectImpl for SquareTile {
        fn dispose(&self) {
            self.photo.take();
            while let Some(child) = self.obj().first_child() {
                child.unparent();
            }
        }
    }

    impl SquareTile {
        fn caption_visible(&self) -> bool {
            self.filename_visible.get()
                && self
                    .filename_label
                    .borrow()
                    .as_ref()
                    .is_some_and(|label| label.is_visible())
        }
    }

    impl WidgetImpl for SquareTile {
        fn measure(&self, orientation: gtk::Orientation, _for_size: i32) -> (i32, i32, i32, i32) {
            let requested = match orientation {
                gtk::Orientation::Horizontal => self.width.get().max(1),
                // The vertical request is the square thumbnail plus the
                // filename row underneath it, so a caption can never squeeze
                // the image out of its TILE_SIZE x TILE_SIZE allocation.
                gtk::Orientation::Vertical => {
                    self.height.get().max(1) + super::filename_caption_height(self.caption_visible())
                }
                _ => self.width.get().max(1),
            };

            (requested, requested, -1, -1)
        }

        fn size_allocate(&self, width: i32, height: i32, baseline: i32) {
            let layout = super::tile_layout(
                self.width.get(),
                self.height.get(),
                width,
                height,
                self.caption_visible(),
            );

            if let Some(child) = self.obj().first_child() {
                let transform = gtk::gsk::Transform::new().translate(&gtk::graphene::Point::new(
                    layout.frame_x as f32,
                    layout.frame_y as f32,
                ));

                child.allocate(
                    layout.frame_width,
                    layout.frame_height,
                    baseline,
                    Some(transform),
                );
                if layout.caption_height > 0 {
                    if let Some(label) = self.filename_label.borrow().as_ref() {
                        let label_transform = gtk::gsk::Transform::new().translate(
                            &gtk::graphene::Point::new(
                                layout.frame_x as f32,
                                layout.caption_y as f32,
                            ),
                        );
                        label.allocate(
                            layout.frame_width,
                            layout.caption_height,
                            baseline,
                            Some(label_transform),
                        );
                    }
                }
            }
        }

        fn snapshot(&self, snapshot: &gtk::Snapshot) {
            let dx = self.presentation_offset_x.get();
            let dy = self.presentation_offset_y.get();
            let stored_scale = self.presentation_scale.get();
            let scale = if stored_scale > 0.001 { stored_scale } else { 1.0 };
            let scaled = (scale - 1.0).abs() > 0.001;
            let translated = dx.abs() > 0.01 || dy.abs() > 0.01;
            let width = self.obj().width() as f32;
            let height = self.obj().height() as f32;

            // Clip the thumbnail to the cell while it is scaled. Zoom-out
            // starts above 1.0; without a clip it paints over neighbours and
            // reads as tiles sliding around.
            if scaled {
                snapshot.push_clip(&gtk::graphene::Rect::new(
                    0.0,
                    0.0,
                    width.max(1.0),
                    height.max(1.0),
                ));
            }

            let mut child = self.obj().first_child();
            let mut is_frame = true;
            while let Some(widget) = child {
                let next = widget.next_sibling();
                if widget.is_visible() {
                    // Scale only the image frame, around its own centre. The
                    // filename caption stays put so zoom is a thumbnail
                    // transform, not a whole-tile FLIP.
                    if scaled && is_frame {
                        snapshot.save();
                        let layout = super::tile_layout(
                            self.width.get(),
                            self.height.get(),
                            width.round() as i32,
                            height.round() as i32,
                            self.caption_visible(),
                        );
                        let cx = (layout.frame_x + layout.frame_width / 2) as f32;
                        let cy = (layout.frame_y + layout.frame_height / 2) as f32;
                        snapshot.translate(&gtk::graphene::Point::new(cx, cy));
                        snapshot.scale(scale, scale);
                        snapshot.translate(&gtk::graphene::Point::new(-cx, -cy));
                        if translated {
                            snapshot.translate(&gtk::graphene::Point::new(dx, dy));
                        }
                        self.obj().snapshot_child(&widget, snapshot);
                        snapshot.restore();
                    } else if translated && is_frame {
                        snapshot.save();
                        snapshot.translate(&gtk::graphene::Point::new(dx, dy));
                        self.obj().snapshot_child(&widget, snapshot);
                        snapshot.restore();
                    } else {
                        self.obj().snapshot_child(&widget, snapshot);
                    }
                }
                is_frame = false;
                child = next;
            }

            if scaled {
                snapshot.pop();
            }
        }
    }
}

#[cfg(test)]
mod filename_caption_tests {
    use super::*;

    /// The four smallest zoom-ladder levels that were reported to render the
    /// thumbnail visibly non-square once the filename row was present.
    const VERIFY_SIZES: [i32; 4] = [100, 117, 137, 160];

    #[test]
    fn caption_row_is_appended_below_the_square_image() {
        for tile_size in VERIFY_SIZES {
            for caption_visible in [false, true] {
                let caption = filename_caption_height(caption_visible);
                assert_eq!(caption, if caption_visible { 24 } else { 0 });
                assert_eq!(tile_block_height(tile_size, caption_visible), tile_size + caption);

                // A parent that allocates exactly the measured block height
                // must still hand the image its whole square.
                let block = tile_size + caption;
                let layout = tile_layout(tile_size, tile_size, tile_size, block, caption_visible);
                assert_eq!(layout.frame_width, tile_size, "width at {tile_size}px");
                assert_eq!(layout.frame_height, tile_size, "height at {tile_size}px");
                assert_eq!(layout.caption_height, caption);
                assert_eq!(layout.block_height, block);
                assert_eq!(layout.caption_y, layout.frame_y + tile_size);
                assert!(layout.caption_y + caption <= block);
            }
        }
    }

    #[test]
    fn filename_visibility_never_changes_the_image_allocation() {
        for tile_size in VERIFY_SIZES {
            let without = tile_layout(tile_size, tile_size, tile_size, tile_size, false);
            let with = tile_layout(
                tile_size,
                tile_size,
                tile_size,
                tile_size + FILENAME_CAPTION_HEIGHT,
                true,
            );
            assert_eq!(with.frame_width, without.frame_width);
            assert_eq!(with.frame_height, without.frame_height);
            assert_eq!(with.frame_height, tile_size);
            assert_eq!(with.frame_width, with.frame_height, "frame must stay square");
        }
    }

    #[test]
    fn folder_rows_reserve_the_caption_between_squares() {
        for tile_size in VERIFY_SIZES {
            assert_eq!(folder_line_height(tile_size, false), tile_size + 12);
            assert_eq!(
                folder_line_height(tile_size, true),
                tile_size + FILENAME_CAPTION_HEIGHT + 12
            );
        }
    }

    /// Real GTK allocation check: the Overlay that owns the picture must end
    /// up exactly `size x size` whether or not the filename row is shown.
    #[test]
    #[ignore = "requires a GTK display; run with --ignored --test-threads=1"]
    fn allocated_thumbnail_frame_is_square_at_every_zoom_level() {
        gtk::init().unwrap();
        let context = glib::MainContext::default();
        let settle = || {
            for _ in 0..30 {
                while context.pending() {
                    context.iteration(false);
                }
                std::thread::sleep(std::time::Duration::from_millis(10));
            }
        };

        for tile_size in VERIFY_SIZES {
            for caption_visible in [false, true] {
                let frame = gtk::Overlay::new();
                let tile = SquareTile::new(tile_size, tile_size, &frame);
                tile.set_halign(gtk::Align::Start);
                tile.set_valign(gtk::Align::Start);
                tile.set_filename_visible(caption_visible);
                let window = gtk::Window::builder().child(&tile).build();
                window.present();
                settle();

                let (_, natural_width, _, _) = tile.measure(gtk::Orientation::Horizontal, -1);
                let (_, natural_height, _, _) = tile.measure(gtk::Orientation::Vertical, -1);
                assert_eq!(
                    natural_height,
                    tile_size + filename_caption_height(caption_visible),
                    "tile height at {tile_size}px caption={caption_visible}"
                );
                assert_eq!(natural_width, tile_size, "tile width at {tile_size}px");
                assert_eq!(
                    (frame.width(), frame.height()),
                    (tile_size, tile_size),
                    "image frame at {tile_size}px caption={caption_visible}"
                );
                window.close();
                settle();
            }
        }
    }
}

glib::wrapper! {
    pub struct SquareTile(ObjectSubclass<square_tile::SquareTile>)
        @extends gtk::Widget,
        @implements gtk::Accessible, gtk::Buildable, gtk::ConstraintTarget;
}

impl SquareTile {
    pub(crate) fn new(width: i32, height: i32, child: &impl IsA<gtk::Widget>) -> Self {
        let tile: Self = glib::Object::new();
        tile.imp().width.set(width.max(1));
        tile.imp().height.set(height.max(1));
        tile.imp().filename_visible.set(false);
        tile.imp().favorite_indicators_visible.set(true);
        child.as_ref().set_parent(&tile);
        tile
    }

    pub(crate) fn photo(&self) -> Option<PhotoObject> {
        self.imp().photo.borrow().as_ref().cloned()
    }

    pub(crate) fn transition_paintable(&self) -> Option<gtk::gdk::Paintable> {
        let frame = self.first_child().and_downcast::<gtk::Overlay>()?;
        let picture = frame.child().and_downcast::<gtk::Picture>()?;
        picture.paintable()
    }

    pub(crate) fn presentation_offset(&self) -> (f32, f32) {
        (
            self.imp().presentation_offset_x.get(),
            self.imp().presentation_offset_y.get(),
        )
    }

    pub(crate) fn set_presentation_offset(&self, x: f32, y: f32) {
        if (self.imp().presentation_offset_x.get() - x).abs() < 0.01
            && (self.imp().presentation_offset_y.get() - y).abs() < 0.01
        {
            return;
        }
        self.imp().presentation_offset_x.set(x);
        self.imp().presentation_offset_y.set(y);
        self.queue_draw();
    }

    pub(crate) fn presentation_scale(&self) -> f32 {
        let scale = self.imp().presentation_scale.get();
        if scale > 0.001 { scale } else { 1.0 }
    }

    pub(crate) fn set_presentation_scale(&self, scale: f32) {
        let scale = scale.clamp(0.01, 4.0);
        if (self.presentation_scale() - scale).abs() < 0.001 {
            return;
        }
        self.imp().presentation_scale.set(scale);
        self.queue_draw();
    }

    fn set_tile_size(&self, width: i32, height: i32) {
        let width = width.max(1);
        let height = height.max(1);
        if self.imp().width.get() == width && self.imp().height.get() == height {
            return;
        }
        self.imp().width.set(width);
        self.imp().height.set(height);
        self.queue_resize();
    }

    /// Show a single-line filename in its own row below the square thumbnail.
    ///
    /// The caption is *added* to the tile's vertical size request: the image
    /// frame always keeps its full TILE_SIZE x TILE_SIZE square, and row
    /// geometry (grid item height, Folder line height) grows by exactly
    /// `filename_caption_height()`.
    pub(crate) fn set_filename_visible(&self, visible: bool) -> bool {
        let changed = self.imp().filename_visible.replace(visible) != visible;
        let mut created = false;
        if visible && self.imp().filename_label.borrow().is_none() {
            let label = gtk::Label::new(None);
            label.set_xalign(0.0);
            label.set_yalign(0.5);
            label.set_ellipsize(gtk::pango::EllipsizeMode::End);
            label.set_single_line_mode(true);
            label.set_margin_start(4);
            label.set_margin_end(4);
            label.set_can_target(false);
            label.add_css_class("thumbnail-filename");
            label.set_parent(self);
            self.imp().filename_label.replace(Some(label));
            created = true;
        }
        if let Some(label) = self.imp().filename_label.borrow().as_ref() {
            if let Some(photo) = self.photo() {
                update_filename_label(label, &photo.filename());
            }
            label.set_visible(visible);
        }
        if changed || created {
            // The vertical size request changed (caption row added/removed),
            // so parents must re-measure, not just re-allocate.
            self.queue_resize();
        }
        created
    }

    /// Switch between cropping photos to the tile (Cover, the default) and
    /// letterboxing the whole photo (Contain) so portrait and landscape
    /// thumbnails both show the complete picture.
    fn set_content_fit(&self, fit: gtk::ContentFit) {
        let Some(frame) = self.first_child().and_downcast::<gtk::Overlay>() else {
            return;
        };
        if let Some(picture) = frame.child().and_downcast::<gtk::Picture>() {
            picture.set_content_fit(fit);
        }
    }

    /// Remember how to open the unavailable dialog so the offline badge can be
    /// created lazily instead of on every folder tile.
    fn set_unavailable_handler(&self, handler: Rc<dyn Fn(PhotoObject, gtk::Widget)>) {
        self.imp().unavailable.replace(Some(handler));
    }

    fn ensure_offline_badge(&self, frame: &gtk::Overlay) -> gtk::Button {
        if let Some(existing) = find_overlay_child(frame, "offline-badge") {
            if let Ok(button) = existing.downcast::<gtk::Button>() {
                return button;
            }
        }
        let badge = gtk::Button::with_label("!");
        badge.set_halign(gtk::Align::Start);
        badge.set_valign(gtk::Align::Start);
        badge.set_margin_top(8);
        badge.set_margin_start(8);
        badge.add_css_class("offline-badge");
        badge.set_tooltip_text(Some("Original photo unavailable"));
        badge.set_visible(false);
        frame.add_overlay(&badge);
        if let Some(handler) = self.imp().unavailable.borrow().clone() {
            let tile = self.downgrade();
            badge.connect_clicked(move |badge| {
                let Some(tile) = tile.upgrade() else {
                    return;
                };
                let Some(photo) = tile.imp().photo.borrow().as_ref().cloned() else {
                    return;
                };
                handler(photo, badge.clone().upcast());
            });
        }
        badge
    }

    fn set_favorite_indicator_visible(&self, visible: bool) {
        self.imp().favorite_indicators_visible.set(visible);
        self.refresh_favorite_indicator();
    }

    fn refresh_favorite_indicator(&self) {
        let Some(photo) = self.imp().photo.borrow().clone() else {
            return;
        };
        let Some(frame) = self.first_child().and_downcast::<gtk::Overlay>() else {
            return;
        };
        let visible = self.imp().favorite_indicators_visible.get() && photo.favorite();
        if visible {
            ensure_favorite_badge(&frame).set_visible(true);
        } else if let Some(child) = find_overlay_child(&frame, "favorite-badge") {
            child.set_visible(false);
        }
        self.refresh_rating_indicator();
    }

    fn refresh_rating_indicator(&self) {
        let Some(photo) = self.imp().photo.borrow().clone() else {
            return;
        };
        let Some(frame) = self.first_child().and_downcast::<gtk::Overlay>() else {
            return;
        };
        let rating = photo.rating().clamp(0, 5);
        if rating == 0 {
            if let Some(child) = find_overlay_child(&frame, "rating-badge") {
                child.set_visible(false);
            }
            return;
        }

        let favorite_visible =
            self.imp().favorite_indicators_visible.get() && photo.favorite();
        let badge = ensure_rating_badge(&frame);
        badge.set_text(&format!("★ {rating}"));
        badge.set_tooltip_text(Some(&format!("Rating: {rating} of 5")));
        // With no Favourite heart the rating owns the normal bottom-right
        // position. When both are present, leave the heart at the far right
        // and shift the rating just far enough left to sit beside it.
        badge.set_margin_end(if favorite_visible { 32 } else { 8 });
        badge.set_visible(true);
    }

    fn set_photo_deferred(&self, photo: &PhotoObject) {
        let same_photo = self
            .imp()
            .photo
            .borrow()
            .as_ref()
            .is_some_and(|current| current.id() == photo.id());
        let same_visual = same_photo
            && *self.imp().applied_visual_key.borrow() == photo_presentation_key(photo);
        if !same_visual {
            self.unload_visual();
        }
        self.imp().photo.replace(Some(photo.clone()));
    }

    fn apply_presentation_paintable(
        &self,
        expected_key: &str,
        paintable: &gtk::gdk::Paintable,
    ) -> bool {
        let started = std::time::Instant::now();
        let Some(photo) = self.imp().photo.borrow().as_ref().cloned() else {
            return false;
        };
        if photo_presentation_key(&photo).as_deref() != Some(expected_key) {
            return false;
        }
        if self.imp().visual_loaded.get()
            && self.imp().applied_visual_key.borrow().as_deref() == Some(expected_key)
        {
            return true;
        }
        let Some(frame) = self.first_child().and_downcast::<gtk::Overlay>() else {
            return false;
        };
        let Some(picture) = frame.child().and_downcast::<gtk::Picture>() else {
            return false;
        };
        picture.set_paintable(Some(paintable));
        if picture.has_css_class("missing-thumbnail") {
            picture.remove_css_class("missing-thumbnail");
        }
        if let Some(placeholder) = picture.next_sibling().and_downcast::<gtk::Image>() {
            if placeholder.is_visible() {
                placeholder.set_visible(false);
            }
        }
        photo.set_thumbnail_available(true);
        self.imp().visual_loaded.set(true);
        *self.imp().applied_visual_key.borrow_mut() = Some(expected_key.to_owned());
        if std::env::var_os("PICASA_TRACE").is_some() { eprintln!("PIC_THUMBNAIL paintable_assign elapsed_us={}", started.elapsed().as_micros()); }
        true
    }

    fn mark_presentation_missing(&self, expected_key: &str) -> bool {
        let Some(photo) = self.imp().photo.borrow().as_ref().cloned() else {
            return false;
        };
        if photo_presentation_key(&photo).as_deref() != Some(expected_key) {
            return false;
        }
        let Some(frame) = self.first_child().and_downcast::<gtk::Overlay>() else {
            return false;
        };
        let Some(picture) = frame.child().and_downcast::<gtk::Picture>() else {
            return false;
        };
        picture.set_paintable(gtk::gdk::Paintable::NONE);
        if !picture.has_css_class("missing-thumbnail") {
            picture.add_css_class("missing-thumbnail");
        }
        if let Some(placeholder) = picture.next_sibling().and_downcast::<gtk::Image>() {
            if !placeholder.is_visible() {
                placeholder.set_visible(true);
            }
        }
        photo.set_thumbnail_available(false);
        // The presentation worker has already requested background regeneration.
        // Treat the placeholder as the current settled state so a frame pump does
        // not requeue the same missing cache file continuously. A targeted
        // ThumbnailCreated/priority completion invalidates this state.
        self.imp().visual_loaded.set(true);
        true
    }

    fn refresh_badges_from_model(&self) {
        let Some(photo) = self.imp().photo.borrow().as_ref().cloned() else {
            return;
        };
        let Some(frame) = self.first_child().and_downcast::<gtk::Overlay>() else {
            return;
        };

        if let Some(label) = self.imp().filename_label.borrow().as_ref() {
            update_filename_label(label, &photo.filename());
            if label.is_visible() != self.imp().filename_visible.get() {
                label.set_visible(self.imp().filename_visible.get());
            }
        }

        if let Some(caption) = photo.history_caption() {
            let label = find_overlay_child(&frame, "history-caption")
                .and_then(|child| child.downcast::<gtk::Label>().ok())
                .unwrap_or_else(|| {
                    let label = gtk::Label::new(None);
                    label.add_css_class("history-caption");
                    label.add_css_class("osd");
                    label.set_valign(gtk::Align::End);
                    label.set_halign(gtk::Align::Fill);
                    label.set_ellipsize(gtk::pango::EllipsizeMode::End);
                    label.set_margin_bottom(30);
                    label.set_can_target(false);
                    frame.add_overlay(&label);
                    label
                });
            label.set_text(&caption);
            label.set_tooltip_text(Some(&caption));
            label.set_visible(true);
        } else if let Some(label) = find_overlay_child(&frame, "history-caption") {
            label.set_visible(false);
        }

        let unavailable = !photo.original_available();
        if unavailable {
            let badge = self.ensure_offline_badge(&frame);
            if !badge.is_visible() {
                badge.set_visible(true);
            }
        } else if let Some(child) = find_overlay_child(&frame, "offline-badge") {
            if child.is_visible() {
                child.set_visible(false);
            }
        }

        let favorite = self.imp().favorite_indicators_visible.get() && photo.favorite();
        if favorite {
            ensure_favorite_badge(&frame).set_visible(true);
        } else if let Some(child) = find_overlay_child(&frame, "favorite-badge") {
            child.set_visible(false);
        }
        self.refresh_rating_indicator();

        let edited = !crate::edit::EditRecipe::decode(&photo.edit_recipe()).is_default();
        if edited {
            ensure_edited_badge(&frame).set_visible(true);
        } else if let Some(child) = find_overlay_child(&frame, "edited-badge") {
            child.set_visible(false);
        }
    }

    fn queue_presentation_visual_async(&self, visible_priority: bool) -> bool {
        let Some(photo) = self.imp().photo.borrow().as_ref().cloned() else {
            return false;
        };
        let Some(request) = photo_presentation_request(&photo, visible_priority) else {
            return false;
        };

        if let Some(paintable) = folder_thumbnail_cache_get(&request.key) {
            self.apply_presentation_paintable(&request.key, &paintable);
            return true;
        }

        // During a direct scrollbar scrub GTK can recycle the same handful of
        // GridView cells hundreds of times per second. Keep the previous
        // paintable as a transient visual backstop instead of flashing the
        // empty template on every rebind. The correct thumbnail replaces it
        // atomically when the worker completion arrives. Once scrubbing
        // settles, refresh_visible_grid_tiles() clears any unresolved stale
        // image and restores the normal placeholder behavior.
        if !preserve_grid_paintable_during_motion() {
            if let Some(frame) = self.first_child().and_downcast::<gtk::Overlay>() {
                if let Some(picture) = frame.child().and_downcast::<gtk::Picture>() {
                    picture.set_paintable(gtk::gdk::Paintable::NONE);
                    if !picture.has_css_class("missing-thumbnail") {
                        picture.add_css_class("missing-thumbnail");
                    }
                    if let Some(placeholder) = picture.next_sibling().and_downcast::<gtk::Image>() {
                        if !placeholder.is_visible() {
                            placeholder.set_visible(true);
                        }
                    }
                }
            }
        }

        crate::thumbnail_display::submit(request)
    }

    fn load_visual(&self) {
        self.refresh_badges_from_model();
        if self.imp().visual_loaded.get() {
            return;
        }
        let Some(photo) = self.imp().photo.borrow().as_ref().cloned() else {
            return;
        };
        let cache_hit = if let Some(key) = photo_presentation_key(&photo) {
            if let Some(paintable) = folder_thumbnail_cache_get(&key) {
                self.apply_presentation_paintable(&key, &paintable);
                true
            } else {
                false
            }
        } else {
            false
        };
        if !cache_hit {
            self.queue_presentation_visual_async(true);
        }
    }

    fn unload_visual(&self) {
        self.imp().visual_loaded.set(false);
        self.imp().applied_visual_key.borrow_mut().take();
        if !preserve_grid_paintable_during_motion() {
            if let Some(frame) = self.first_child().and_downcast::<gtk::Overlay>() {
                if let Some(picture) = frame.child().and_downcast::<gtk::Picture>() {
                    picture.set_paintable(gtk::gdk::Paintable::NONE);
                }
            }
        }
    }

    fn bind_photo(&self, photo: &PhotoObject) {
        let started = std::time::Instant::now();
        self.set_photo_deferred(photo);
        self.load_visual();
        if std::env::var_os("PICASA_TRACE").is_some() { eprintln!("PIC_THUMBNAIL gtk_bind elapsed_us={} id={}", started.elapsed().as_micros(), photo.id()); }
    }

    /// Folder ListView bind must stay strictly presentation-only.
    ///
    /// GtkListView can recycle hundreds or thousands of rows during a large
    /// scrollbar jump. Do not stat files, probe originals, request thumbnail
    /// generation, or render RAW/edit transforms here. Those operations turn
    /// harmless widget recycling into synchronous main-thread work.
    fn bind_photo_folder_fast(&self, photo: &PhotoObject, photo_index: usize) {
        // Folder bind immediately paints the correct paintable, so replace the
        // photo in place instead of running the full unload path. The old path
        // cleared the paintable and toggled CSS on every recycled tile, which
        // invalidated GTK's style tree for the whole realized list on each
        // scroll frame (measured: gtk_css_node_validate_internal dominated).
        let same_photo = self
            .imp()
            .photo
            .borrow()
            .as_ref()
            .is_some_and(|current| current.id() == photo.id());
        if !same_photo {
            self.imp().photo.replace(Some(photo.clone()));
        }
        self.imp().photo_index.set(Some(photo_index));

        let Some(bound) = self.imp().photo.borrow().as_ref().cloned() else {
            return;
        };
        if let Some(label) = self.imp().filename_label.borrow().as_ref() {
            update_filename_label(label, &bound.filename());
            if label.is_visible() != self.imp().filename_visible.get() {
                label.set_visible(self.imp().filename_visible.get());
            }
        }
        let Some(frame) = self.first_child().and_downcast::<gtk::Overlay>() else {
            return;
        };
        let Some(picture) = frame.child().and_downcast::<gtk::Picture>() else {
            return;
        };

        // RAM-only fast path. Never touch the filesystem from ListView bind,
        // but reuse a paintable that the settled-viewport loader has already
        // decoded. This keeps nearby thumbnails visible during wheel scrolling
        // without restoring the old per-bind I/O/RAW/edit work.
        let memory_hit = photo_presentation_key(&bound)
            .as_deref()
            .and_then(folder_thumbnail_cache_get);
        if let Some(paintable) = memory_hit.as_ref() {
            picture.set_paintable(Some(paintable));
            if picture.has_css_class("missing-thumbnail") {
                picture.remove_css_class("missing-thumbnail");
            }
        } else {
            // Do not blank a recycled Folder tile just because the destination
            // thumbnail is not in RAM yet. Keep the previous paintable as a
            // temporary visual backstop and immediately submit the *current*
            // photo to the async presentation queue. The completion drain
            // validates the presentation key before replacing the paintable, so
            // a tile that gets recycled again cannot receive the wrong image.
            //
            // This is intentionally different from the old Folder design,
            // which displayed an empty template here and waited for a later
            // viewport pump to rediscover the tile. During Page Up/Down and
            // scrollbar scrubbing that rediscovery can lag several frames.
            if picture.paintable().is_none() {
                if !picture.has_css_class("missing-thumbnail") {
                    picture.add_css_class("missing-thumbnail");
                }
            }
            if let Some(request) = photo_presentation_request(&bound, true) {
                crate::thumbnail_display::submit_latest_visible(request);
            }
        }

        let unavailable = !bound.original_available();
        if unavailable {
            let badge = self.ensure_offline_badge(&frame);
            if !badge.is_visible() {
                badge.set_visible(true);
            }
            if badge.tooltip_text().as_deref() != Some("Original photo unavailable") {
                badge.set_tooltip_text(Some("Original photo unavailable"));
            }
        } else if let Some(child) = find_overlay_child(&frame, "offline-badge") {
            if child.is_visible() {
                child.set_visible(false);
            }
        }
        let favorite = self.imp().favorite_indicators_visible.get() && bound.favorite();
        if favorite {
            ensure_favorite_badge(&frame).set_visible(true);
        } else if let Some(child) = find_overlay_child(&frame, "favorite-badge") {
            child.set_visible(false);
        }
        let edited = !crate::edit::EditRecipe::decode(&bound.edit_recipe()).is_default();
        if edited {
            let badge = ensure_edited_badge(&frame);
            badge.set_visible(true);
            if badge.tooltip_text().as_deref() != Some("Edited") {
                badge.set_tooltip_text(Some("Edited"));
            }
        } else if let Some(child) = find_overlay_child(&frame, "edited-badge") {
            child.set_visible(false);
        }
        if let Some(placeholder) = picture.next_sibling().and_downcast::<gtk::Image>() {
            // Only show the empty template when there is genuinely no paintable
            // to keep on screen. A recycled tile with an old paintable stays
            // visually populated until its correct async result arrives.
            let visible = memory_hit.is_none() && picture.paintable().is_none();
            if placeholder.is_visible() != visible {
                placeholder.set_visible(visible);
            }
        }
        self.imp().visual_loaded.set(memory_hit.is_some());
    }

    /// Queue a cached folder thumbnail without blocking the GTK thread.
    ///
    /// Fast Folder scrolling can recycle rows faster than the settled viewport
    /// loader runs. The bind path remains RAM-only; cache-file probing, JPEG
    /// reading, and decoding happen on a bounded worker set here. The result is
    /// applied only if this recycled tile still represents the same photo.
    fn queue_folder_cached_visual_async(&self, visible_priority: bool) -> bool {
        let Some(photo) = self.imp().photo.borrow().as_ref().cloned() else {
            return false;
        };
        let Some(request) = photo_presentation_request(&photo, visible_priority) else {
            return false;
        };

        if let Some(paintable) = folder_thumbnail_cache_get(&request.key) {
            self.apply_presentation_paintable(&request.key, &paintable);
            return true;
        }

        // Folder ListView rows are recycled aggressively when their model is
        // rebound. Keep any existing paintable as a temporary visual backstop
        // until the key-validated async result arrives. Missing/failed results
        // still clear the tile through mark_presentation_missing().
        crate::thumbnail_display::submit(request)
    }

    /// Load the final viewport thumbnail after Folder scrolling settles.
    ///
    /// Even after motion settles, thumbnail cache probing, decoding and visual
    /// transforms stay on the shared worker queue. The GTK thread only updates
    /// tooltip/badge state and submits a request when RAM has no paintable.
    fn load_folder_cached_visual(&self) {
        let Some(photo) = self.imp().photo.borrow().as_ref().cloned() else {
            return;
        };
        let Some(frame) = self.first_child().and_downcast::<gtk::Overlay>() else {
            return;
        };
        let Some(picture) = frame.child().and_downcast::<gtk::Picture>() else {
            return;
        };

        // Tooltip work stays out of the high-frequency bind path. Once motion
        // settles this is presentation-only and does not touch the original or
        // thumbnail file.
        let filename = photo.filename();
        if picture.tooltip_text().as_deref() != Some(filename.as_str()) {
            picture.set_tooltip_text(Some(&filename));
        }

        // Scrolling never probes originals. Offline state comes from the
        // folder/mount snapshot plus explicit background availability refreshes.
        if !self.imp().visual_loaded.get() {
            self.queue_folder_cached_visual_async(true);
        }
    }

    /// Reset a recycled Folder tile without blanking its current paintable.
    ///
    /// GtkListView can unbind/rebind the same tile pool during a Folder model
    /// splice. Clearing every image at unbind produces a wall of placeholders
    /// while async cache decodes catch up. The next bind immediately changes
    /// the photo identity and queues the correct presentation key; completion
    /// application validates that key before replacing this temporary backstop.
    fn clear_photo_folder_recycle(&self) {
        self.imp().visual_loaded.set(false);
        self.imp().applied_visual_key.borrow_mut().take();
        self.imp().photo.take();
        self.imp().photo_index.set(None);
        if let Some(frame) = self.first_child().and_downcast::<gtk::Overlay>() {
            if let Some(picture) = frame.child().and_downcast::<gtk::Picture>() {
                picture.set_tooltip_text(None);
                if let Some(placeholder) = picture.next_sibling().and_downcast::<gtk::Image>() {
                    let visible = picture.paintable().is_none();
                    if placeholder.is_visible() != visible {
                        placeholder.set_visible(visible);
                    }
                }
            }
            for class_name in ["manual-selected", "folder-photo-selected"] {
                frame.remove_css_class(class_name);
            }
            let mut child = frame.first_child();
            while let Some(current) = child {
                if let Some(image) = current.downcast_ref::<gtk::Image>() {
                    if image.has_css_class("favorite-badge")
                        || image.has_css_class("edited-badge")
                        || image.has_css_class("selection-badge")
                    {
                        image.set_visible(false);
                    }
                }
                if let Some(button) = current.downcast_ref::<gtk::Button>() {
                    if button.has_css_class("offline-badge") {
                        button.set_visible(false);
                    }
                }
                child = current.next_sibling();
            }
        }
    }

    fn clear_photo(&self) {
        self.unload_visual();
        self.imp().photo.take();
        self.imp().photo_index.set(None);
        if let Some(frame) = self.first_child().and_downcast::<gtk::Overlay>() {
            if let Some(picture) = frame.child().and_downcast::<gtk::Picture>() {
                // A fast Folder scrollbar scrub unbinds/rebinds rows faster
                // than thumbnail decodes can land. Blanking the paintable
                // here would leave the recycled tile with nothing to show
                // when bind_photo_folder_fast tries to keep the previous
                // image as a transient backstop. The settle refresh clears
                // any unresolved stale image once scrubbing stops; the
                // completion drain validates presentation keys before
                // applying, so no wrong image can persist on screen.
                if !preserve_grid_paintable_during_motion() {
                    picture.set_paintable(gtk::gdk::Paintable::NONE);
                }
                picture.set_tooltip_text(None);
            }
            for class_name in ["manual-selected", "folder-photo-selected"] {
                frame.remove_css_class(class_name);
            }
            let mut child = frame.first_child();
            while let Some(current) = child {
                if let Some(image) = current.downcast_ref::<gtk::Image>() {
                    if image.has_css_class("favorite-badge")
                        || image.has_css_class("edited-badge")
                        || image.has_css_class("selection-badge")
                    {
                        image.set_visible(false);
                    }
                }
                if let Some(button) = current.downcast_ref::<gtk::Button>() {
                    if button.has_css_class("offline-badge") {
                        button.set_visible(false);
                    }
                }
                child = current.next_sibling();
            }
        }
    }

    fn set_manual_selected(&self, selected: bool) {
        let Some(frame) = self.first_child().and_downcast::<gtk::Overlay>() else {
            return;
        };
        // `clear_photo` hides the selection badge when a tile is recycled.
        // Opacity is the real on/off switch via CSS, so make the badge visible
        // again here or recycled tiles lose their indicator.
        if selected {
            let badge = ensure_selection_badge(&frame);
            if !badge.is_visible() {
                badge.set_visible(true);
            }
        }
        let has_class = frame.has_css_class("folder-photo-selected");
        if selected && !has_class {
            frame.add_css_class("folder-photo-selected");
        } else if !selected && has_class {
            frame.remove_css_class("folder-photo-selected");
        }
    }

    fn refresh_thumbnail(&self) {
        self.refresh_thumbnail_with_probe(true);
    }

    fn refresh_availability(&self) {
        let Some(photo) = self.imp().photo.borrow().clone() else {
            return;
        };
        // Read the value the async probe or the availability worker already
        // stored; never stat the original on the GTK thread here.
        let available = photo.original_available();

        if let Some(frame) = self.first_child().and_downcast::<gtk::Overlay>() {
            if !available {
                self.ensure_offline_badge(&frame).set_visible(true);
            } else if let Some(child) = find_overlay_child(&frame, "offline-badge") {
                child.set_visible(false);
            }
        }
    }

    fn refresh_thumbnail_with_probe(&self, _probe_thumbnail: bool) {
        let Some(photo) = self.imp().photo.borrow().clone() else {
            return;
        };
        if let Some(key) = photo_presentation_key(&photo) {
            folder_thumbnail_cache_remove(&key);
        }
        self.imp().visual_loaded.set(false);
        self.imp().applied_visual_key.borrow_mut().take();
        self.refresh_badges_from_model();
        self.queue_presentation_visual_async(true);
    }
}

fn find_overlay_child(frame: &gtk::Overlay, css_class: &str) -> Option<gtk::Widget> {
    let mut child = frame.first_child();
    while let Some(current) = child {
        if current.has_css_class(css_class) {
            return Some(current);
        }
        child = current.next_sibling();
    }
    None
}

/// Folder tiles are built without badges; almost no photo needs one, and
/// creating four extra widgets per tile was the dominant cost of rebuilding the
/// Folder rows (~250-520 ms per column change). These helpers create a badge the
/// first time it is actually needed.
fn ensure_favorite_badge(frame: &gtk::Overlay) -> gtk::Image {
    if let Some(existing) = find_overlay_child(frame, "favorite-badge") {
        if let Ok(image) = existing.downcast::<gtk::Image>() {
            return image;
        }
    }
    let badge = gtk::Image::from_icon_name("emote-love-symbolic");
    badge.set_pixel_size(18);
    badge.set_halign(gtk::Align::End);
    badge.set_valign(gtk::Align::End);
    badge.set_margin_bottom(8);
    badge.set_margin_end(8);
    badge.add_css_class("favorite-badge");
    badge.set_visible(false);
    frame.add_overlay(&badge);
    badge
}

fn ensure_rating_badge(frame: &gtk::Overlay) -> gtk::Label {
    if let Some(existing) = find_overlay_child(frame, "rating-badge") {
        if let Ok(label) = existing.downcast::<gtk::Label>() {
            return label;
        }
    }
    let badge = gtk::Label::new(None);
    badge.set_halign(gtk::Align::End);
    badge.set_valign(gtk::Align::End);
    badge.set_margin_bottom(8);
    badge.set_margin_end(8);
    badge.add_css_class("rating-badge");
    badge.add_css_class("osd");
    badge.add_css_class("caption");
    badge.set_can_target(false);
    badge.set_visible(false);
    frame.add_overlay(&badge);
    badge
}

fn ensure_edited_badge(frame: &gtk::Overlay) -> gtk::Image {
    if let Some(existing) = find_overlay_child(frame, "edited-badge") {
        if let Ok(image) = existing.downcast::<gtk::Image>() {
            return image;
        }
    }
    let badge = gtk::Image::from_icon_name("document-edit-symbolic");
    badge.set_pixel_size(18);
    badge.set_halign(gtk::Align::Start);
    badge.set_valign(gtk::Align::End);
    badge.set_margin_bottom(8);
    badge.set_margin_start(8);
    badge.add_css_class("edited-badge");
    badge.set_tooltip_text(Some("Edited"));
    badge.set_visible(false);
    frame.add_overlay(&badge);
    badge
}

fn ensure_selection_badge(frame: &gtk::Overlay) -> gtk::Image {
    if let Some(existing) = find_overlay_child(frame, "selection-badge") {
        if let Ok(image) = existing.downcast::<gtk::Image>() {
            return image;
        }
    }
    let badge = gtk::Image::from_icon_name("object-select-symbolic");
    badge.set_pixel_size(18);
    badge.set_halign(gtk::Align::End);
    badge.set_valign(gtk::Align::Start);
    badge.set_margin_top(8);
    badge.set_margin_end(8);
    badge.add_css_class("selection-badge");
    badge.set_visible(false);
    frame.add_overlay(&badge);
    badge
}

/// Nikon RAW thumbnails can contain a letterboxed embedded preview whose
/// pixel aspect ratio does not match the camera image dimensions. GTK cannot
/// crop bars that are already part of the cached pixels, so crop the small
/// cached image before handing it to the normal Cover-rendered Picture.
pub(crate) fn raw_cached_thumbnail(photo: &PhotoObject, path: &str) -> Option<gtk::gdk::Paintable> {
    let source_path = photo.path();
    if !crate::image_format::uses(&source_path, crate::image_format::DecoderKind::Raw) {
        return None;
    }

    let source_width = photo.width();
    let source_height = photo.height();
    if source_width <= 0 || source_height <= 0 {
        return None;
    }

    let rotation = photo.rotation().rem_euclid(360);
    let edit_recipe = photo.edit_recipe();
    let recipe = crate::edit::EditRecipe::decode(&edit_recipe);
    if let Some(paintable) = raw_thumbnail_cache_get(&source_path, rotation, &edit_recipe) {
        return Some(paintable);
    }

    let mut image = image::open(path).ok()?.to_rgba8();
    let image_width = image.width();
    let image_height = image.height();
    if image_width == 0 || image_height == 0 {
        return None;
    }

    // Cached thumbnails have already had EXIF orientation applied during
    // generation. Raw dimensions are reported in sensor orientation, so
    // orientations 5-8 require the target axes to be swapped as well.
    let orientation = crate::thumbnail::exif_orientation(&source_path);
    let (display_width, display_height) = if matches!(orientation, 5..=8) {
        (source_height, source_width)
    } else {
        (source_width, source_height)
    };
    let target_ratio = display_width as f64 / display_height as f64;
    let image_ratio = image_width as f64 / image_height as f64;
    if image_ratio > target_ratio {
        let crop_width =
            ((image_height as f64 * target_ratio).round() as u32).clamp(1, image_width);
        let left = (image_width - crop_width) / 2;
        image = image::imageops::crop_imm(&image, left, 0, crop_width, image_height).to_image();
    } else if image_ratio < target_ratio {
        let crop_height =
            ((image_width as f64 / target_ratio).round() as u32).clamp(1, image_height);
        let top = (image_height - crop_height) / 2;
        image = image::imageops::crop_imm(&image, 0, top, image_width, crop_height).to_image();
    }

    image = match rotation {
        90 => image::imageops::rotate90(&image),
        180 => image::imageops::rotate180(&image),
        270 => image::imageops::rotate270(&image),
        _ => image,
    };
    if !recipe.is_default() {
        image = crate::edit::render::apply_recipe(image, &recipe);
    }

    let width = image.width() as i32;
    let height = image.height() as i32;
    let bytes = glib::Bytes::from_owned(image.into_raw());
    let texture = gtk::gdk::MemoryTexture::new(
        width,
        height,
        gtk::gdk::MemoryFormat::R8g8b8a8,
        &bytes,
        width as usize * 4,
    );
    let paintable: gtk::gdk::Paintable = texture.upcast();
    raw_thumbnail_cache_insert(source_path, rotation, edit_recipe, paintable.clone());
    Some(paintable)
}

fn raw_thumbnail_cache_get(path: &str, rotation: i32, recipe: &str) -> Option<gtk::gdk::Paintable> {
    RAW_THUMBNAIL_CACHE.with(|cache| {
        let mut cache = cache.borrow_mut();
        let index = cache
            .iter()
            .position(|(cached_path, cached_rotation, cached_recipe, _)| {
                cached_path == path && *cached_rotation == rotation && cached_recipe == recipe
            })?;
        let entry = cache.remove(index)?;
        let paintable = entry.3.clone();
        cache.push_back(entry);
        Some(paintable)
    })
}

fn raw_thumbnail_cache_insert(
    path: String,
    rotation: i32,
    recipe: String,
    paintable: gtk::gdk::Paintable,
) {
    RAW_THUMBNAIL_CACHE.with(|cache| {
        let mut cache = cache.borrow_mut();
        cache.retain(|(cached_path, cached_rotation, cached_recipe, _)| {
            cached_path != &path || *cached_rotation != rotation || cached_recipe != &recipe
        });
        cache.push_back((path, rotation, recipe, paintable));
        while cache.len() > RAW_THUMBNAIL_CACHE_CAPACITY {
            cache.pop_front();
        }
    });
}
