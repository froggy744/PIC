include!("dialogs.rs");
include!("navigation.rs");

pub fn build(app: &adw::Application, connection: Connection) -> adw::ApplicationWindow {
    let build_started = Instant::now();
    let window = adw::ApplicationWindow::new(app);
    window.set_title(Some("PIC"));
    let connection = Rc::new(RefCell::new(connection));
    let saved_window_width = numeric_setting(&connection.borrow(), WINDOW_WIDTH_SETTING_KEY)
        .unwrap_or(1440)
        .clamp(640, 7680);
    let saved_window_height = numeric_setting(&connection.borrow(), WINDOW_HEIGHT_SETTING_KEY)
        .unwrap_or(900)
        .clamp(480, 4320);
    let saved_window_maximized = db::setting(&connection.borrow(), WINDOW_MAXIMIZED_SETTING_KEY)
        .ok()
        .flatten()
        .as_deref()
        == Some("true");
    window.set_default_size(saved_window_width, saved_window_height);
    if saved_window_maximized {
        window.maximize();
    }

    let folders = db::folders(&connection.borrow()).unwrap_or_default();
    let folder_cache = Rc::new(RefCell::new(folders.clone()));
    let albums = db::albums(&connection.borrow()).unwrap_or_default();
    let initial_filter = sidebar_filter_from_setting(
        db::setting(&connection.borrow(), LAST_VIEW_SETTING_KEY)
            .ok()
            .flatten()
            .as_deref(),
        &folders,
        &albums,
    );
    let saved_view_photo_id = numeric_setting::<i64>(
        &connection.borrow(),
        LAST_VIEW_PHOTO_ID_SETTING_KEY,
    );
    // "Activated" means the photo most recently opened in the viewer. Keep
    // that identity separate from ordinary selection and viewport scrolling.
    let last_activated_photo_id = Rc::new(Cell::new(numeric_setting::<i64>(
        &connection.borrow(),
        LAST_ACTIVATED_PHOTO_ID_SETTING_KEY,
    )));
    let saved_view_scroll = numeric_setting::<f64>(
        &connection.borrow(),
        LAST_VIEW_SCROLL_SETTING_KEY,
    )
    .unwrap_or(0.0)
    .max(0.0);
    let saved_albums_scroll = numeric_setting::<f64>(
        &connection.borrow(),
        LAST_ALBUMS_SCROLL_SETTING_KEY,
    )
    .unwrap_or(0.0)
    .max(0.0);
    let sidebar_counts = db::sidebar_counts(&connection.borrow()).unwrap_or_default();
    let sort = Rc::new(Cell::new(PhotoSort {
        field: SortField::from_key(
            &db::setting(&connection.borrow(), SORT_FIELD_SETTING_KEY)
                .ok()
                .flatten()
                .unwrap_or_default(),
        ),
        direction: SortDirection::from_key(
            &db::setting(&connection.borrow(), SORT_DIRECTION_SETTING_KEY)
                .ok()
                .flatten()
                .unwrap_or_default(),
        ),
    }));
    // Rating filtering is session-only. Starting PIC with a stale saved
    // star filter is surprising and can make rating shortcuts appear to throw
    // the gallery around or hide the photo immediately.
    let rating_filter = Rc::new(Cell::new(RatingFilter::All));
    if let Err(error) = db::set_setting(
        &connection.borrow(),
        RATING_FILTER_SETTING_KEY,
        RatingFilter::All.key(),
    ) {
        eprintln!("Could not clear photo rating filter at startup: {error}");
    }
    let saved_group_mode = group_mode_from_key(
        &db::setting(&connection.borrow(), GROUP_MODE_SETTING_KEY)
            .ok()
            .flatten()
            .unwrap_or_default(),
    );
    let group_mode = Rc::new(Cell::new(if group_date_for_sort(sort.get()).is_some() {
        saved_group_mode
    } else {
        grid::GroupMode::None
    }));
    let mut photos = match initial_filter {
        sidebar::SidebarFilter::Library | sidebar::SidebarFilter::Albums => Vec::new(),
        sidebar::SidebarFilter::Album(album_id) => {
            db::photos_in_album(&connection.borrow(), album_id, None).unwrap_or_default()
        }
        sidebar::SidebarFilter::Favorites => {
            db::photos(&connection.borrow(), None, true, None).unwrap_or_default()
        }
        _ => db::photos(&connection.borrow(), None, false, None).unwrap_or_default(),
    };
    retain_enabled_formats(&connection.borrow(), &mut photos);
    limit_recently_added(
        &connection.borrow(),
        initial_filter,
        &mut photos,
    );
    apply_rating_filter(&mut photos, rating_filter.get());
    if matches!(initial_filter, sidebar::SidebarFilter::Folder(_)) {
        let display_mode = sidebar::FolderDisplayMode::from_setting(
            db::setting(
                &connection.borrow(),
                sidebar::FOLDER_DISPLAY_MODE_SETTING_KEY,
            )
            .ok()
            .flatten()
            .as_deref(),
        );
        sort_folder_stream(&mut photos, &folders, sort.get(), display_mode);
    } else {
        sort_photos(&mut photos, sort.get());
    }
    let startup_photos = Rc::new(photos);
    eprintln!(
        "STARTUP cold_start_ms={} photos={} displayed={} folders={} albums={} scan=disabled rss_mb={}",
        build_started.elapsed().as_millis(),
        sidebar_counts.photos,
        startup_photos.len(),
        folders.len(),
        albums.len(),
        crate::diagnostics::rss_mb()
    );

    let info = Rc::new(InfoBar::new());
    info.set_photo(None);

    let selected_photo = Rc::new(RefCell::new(None));

    let lightbox = Rc::new(Lightbox::new());
    let info_for_lightbox = info.clone();
    let selected_photo_for_lightbox = selected_photo.clone();
    let last_activated_for_lightbox = last_activated_photo_id.clone();
    let connection_for_lightbox = connection.clone();

    // Appearance themes are discovered from the themes folder at runtime; the
    // engine applies them, persists the choice, and is shared with the
    // Settings → Themes picker (the single theme list in the app).
    let display = gtk::gdk::Display::default().expect("a display is required");
    let theme_engine = crate::window::theme::ThemeEngine::new(
        display.clone(),
        connection.clone(),
        lightbox.clone(),
    );
    lightbox.set_photo_changed_handler(move |photo| {
        last_activated_for_lightbox.set(Some(photo.id()));
        if let Err(error) = db::set_setting(
            &connection_for_lightbox.borrow(),
            LAST_ACTIVATED_PHOTO_ID_SETTING_KEY,
            &photo.id().to_string(),
        ) {
            eprintln!("Could not save last activated photo: {error}");
        }
        info_for_lightbox.set_photo(Some(&photo));
        // Navigating to another photo restores the viewer's normal fit state.
        info_for_lightbox.one_to_one.set_active(false);
        selected_photo_for_lightbox.replace(Some(photo));
    });

    // Space opens the fullscreen viewer from the gallery. While the viewer
    // is open, it toggles between fit and 1:1 viewing.
    // The actual open action is installed after Gallery exists.
    let space_open_slot: Rc<RefCell<Option<Rc<dyn Fn()>>>> = Rc::new(RefCell::new(None));
    let edit_space_slot: Rc<RefCell<Option<Rc<dyn Fn() -> bool>>>> = Rc::new(RefCell::new(None));
    let collection_navigation_slot: Rc<RefCell<Option<Rc<dyn Fn(i32)>>>> =
        Rc::new(RefCell::new(None));
    let search_popup_slot: Rc<RefCell<Option<gtk::Popover>>> = Rc::new(RefCell::new(None));
    let space_toggle_in_progress = Rc::new(Cell::new(false));

    include!("shortcuts.rs");

    let info_for_grid = info.clone();
    let selected_photo_for_grid = selected_photo.clone();
    let lightbox_for_grid = lightbox.clone();
    let filter = Rc::new(Cell::new(initial_filter));
    let search_text = Rc::new(RefCell::new(String::new()));
    let search_entry_slot: Rc<RefCell<Option<gtk::SearchEntry>>> = Rc::new(RefCell::new(None));
    let search_suppressed = Rc::new(Cell::new(false));
    let cleared_search_query = Rc::new(RefCell::new(None::<String>));
    let search_debounce: Rc<RefCell<Option<glib::SourceId>>> = Rc::new(RefCell::new(None));
    let gallery_for_actions: Rc<RefCell<Weak<grid::Gallery>>> = Rc::new(RefCell::new(Weak::new()));
    let sidebar_for_unavailable: Rc<RefCell<Option<gtk::ScrolledWindow>>> =
        Rc::new(RefCell::new(None));
    let sidebar_selection_slot: Rc<RefCell<Option<gtk::ScrolledWindow>>> =
        Rc::new(RefCell::new(None));
    let create_album_slot: Rc<RefCell<Option<Rc<dyn Fn()>>>> = Rc::new(RefCell::new(None));
    let create_album: Rc<dyn Fn()> = {
        let slot = create_album_slot.clone();
        Rc::new(move || {
            if let Some(callback) = slot.borrow().as_ref() {
                callback();
            }
        })
    };
    let import_folder_slot: Rc<RefCell<Option<Rc<dyn Fn()>>>> = Rc::new(RefCell::new(None));
    let edit_open_slot: Rc<RefCell<Option<Rc<dyn Fn(i64)>>>> = Rc::new(RefCell::new(None));
    let edit_clipboard: Rc<RefCell<Option<String>>> = Rc::new(RefCell::new(None));
    let open_edit: Rc<dyn Fn(i64)> = {
        let slot = edit_open_slot.clone();
        Rc::new(move |id| {
            if let Some(callback) = slot.borrow().as_ref() {
                callback(id);
            }
        })
    };
    // Filled with the shared info-bar `export_clicked` once it is built;
    // the context-menu Export item invokes this same callback.
    let export_slot: Rc<RefCell<Option<Rc<dyn Fn()>>>> = Rc::new(RefCell::new(None));
    let export_photos: Rc<dyn Fn()> = {
        let slot = export_slot.clone();
        Rc::new(move || {
            if let Some(callback) = slot.borrow().as_ref() {
                callback();
            }
        })
    };
    let collage_open_slot: Rc<RefCell<Option<Rc<dyn Fn(Vec<i64>)>>>> =
        Rc::new(RefCell::new(None));
    let collage_add_mode_slot: Rc<RefCell<Option<Rc<dyn Fn()>>>> =
        Rc::new(RefCell::new(None));
    let collage_prepare_add_slot: Rc<RefCell<Option<Rc<dyn Fn()>>>> =
        Rc::new(RefCell::new(None));
    let collage_close_slot: Rc<RefCell<Option<Rc<dyn Fn()>>>> =
        Rc::new(RefCell::new(None));
    // True while the user is on the photos page picking images for the open
    // collage. The collage editor must survive that detour; every other
    // transition away from the collage page tears it down.
    let collage_add_mode: Rc<Cell<bool>> = Rc::new(Cell::new(false));
    // True while the photo editor is editing a photo that belongs to the
    // open collage. The collage editor survives that detour, and the
    // editor's Back/Done return to the collage instead of the photos page.
    let collage_editing: Rc<Cell<bool>> = Rc::new(Cell::new(false));
    let open_collage: Rc<dyn Fn(Vec<i64>)> = {
        let slot = collage_open_slot.clone();
        Rc::new(move |ids| {
            if let Some(callback) = slot.borrow().as_ref() {
                callback(ids);
            }
        })
    };
    let refresh_folder_slot: Rc<
        RefCell<Option<Rc<dyn Fn(PhotoScanRequestReason, String)>>>,
    > =
        Rc::new(RefCell::new(None));

    // Keep filesystem monitors alive for exactly the folders the user marked
    // for watching. Raw monitor callbacks only mark the owning imported root
    // dirty; they never start a scan directly.
    let folder_watch_monitors: Rc<RefCell<Vec<gio::FileMonitor>>> =
        Rc::new(RefCell::new(Vec::new()));
    let pending_watch_refreshes: Rc<
        RefCell<std::collections::HashMap<String, Instant>>,
    > = Rc::new(RefCell::new(std::collections::HashMap::new()));
    let rebuild_folder_watches: Rc<dyn Fn()> = {
        let connection = connection.clone();
        let monitors = folder_watch_monitors.clone();
        let pending = pending_watch_refreshes.clone();
        Rc::new(move || {
            for monitor in monitors.borrow_mut().drain(..) {
                monitor.cancel();
            }
            pending.borrow_mut().clear();

            if !db::folder_watching_enabled(&connection.borrow()) {
                
                return;
            }

            let Ok(folders) = db::folders(&connection.borrow()) else {
                eprintln!("WATCH ERROR could not read folders");
                return;
            };
            for folder in folders.iter().filter(|folder| folder.watched && folder.available) {
                let Some(scan_root) = watch_scan_root(&folders, folder.id) else {
                    
                    continue;
                };
                let watched_path = folder.path.clone();
                #[cfg(target_os="linux")]
                if crate::network_shares::private(&watched_path) {
                    // GIO directory monitors may mount a share in the desktop.
                    // Direct network sources use explicit refresh, never GVfs.
                    continue;
                }
                let file = crate::source::file(&watched_path);
                let monitor = match file.monitor_directory(
                    gio::FileMonitorFlags::NONE,
                    gio::Cancellable::NONE,
                ) {
                    Ok(monitor) => monitor,
                    Err(error) => {
                        eprintln!(
                            "WATCH ERROR monitor path={} error={}",
                            watched_path, error
                        );
                        continue;
                    }
                };
                let pending_for_event = pending.clone();
                let scan_root_for_event = scan_root.clone();
                monitor.connect_changed(move |_, file, other_file, event| {
                    // Ignore metadata-only monitor noise. Content changes are
                    // coalesced below before they can authorize any scan.
                    if matches!(
                        event,
                        gio::FileMonitorEvent::AttributeChanged
                            | gio::FileMonitorEvent::PreUnmount
                            | gio::FileMonitorEvent::Unmounted
                    ) {
                        return;
                    }
                    pending_for_event
                        .borrow_mut()
                        .insert(scan_root_for_event.clone(), Instant::now());
                    
                });
                monitors.borrow_mut().push(monitor);
            }
            
        })
    };
    let import_folder: Rc<dyn Fn()> = {
        let slot = import_folder_slot.clone();
        Rc::new(move || {
            if let Some(callback) = slot.borrow().as_ref() {
                callback();
            }
        })
    };
    let add_network_share_slot: Rc<RefCell<Option<Rc<dyn Fn()>>>> = Rc::new(RefCell::new(None));
    let add_network_share: Rc<dyn Fn()> = {
        let slot = add_network_share_slot.clone();
        Rc::new(move || {
            if let Some(callback) = slot.borrow().as_ref() {
                callback();
            }
        })
    };
    let delete_album_slot: Rc<RefCell<Option<Rc<dyn Fn(i64)>>>> = Rc::new(RefCell::new(None));
    let delete_album: Rc<dyn Fn(i64)> = {
        let slot = delete_album_slot.clone();
        Rc::new(move |album_id| {
            if let Some(callback) = slot.borrow().as_ref() {
                callback(album_id);
            }
        })
    };
    let availability_refresh_slot: Rc<RefCell<Option<Rc<dyn Fn()>>>> = Rc::new(RefCell::new(None));
    let availability_refresh: Rc<dyn Fn()> = {
        let connection = connection.clone();
        let folder_cache = folder_cache.clone();
        let gallery = gallery_for_actions.clone();
        let sidebar = sidebar_for_unavailable.clone();
        let slot = availability_refresh_slot.clone();
        let create_album = create_album.clone();
        let import_folder = import_folder.clone();
        let delete_album = delete_album.clone();
        Rc::new(move || {
            
            debug_assert!(PhotoScanRequestReason::AvailabilityUpdate
                .scan_kind()
                .is_none());
            refresh_availability_ui(
                &connection,
                &folder_cache,
                &gallery,
                &sidebar,
                &slot,
                create_album.clone(),
                import_folder.clone(),
                delete_album.clone(),
            );
        })
    };
    availability_refresh_slot.replace(Some(availability_refresh.clone()));
    let albums_home_refresh_slot: Rc<RefCell<Option<Rc<dyn Fn(&[db::Album])>>>> =
        Rc::new(RefCell::new(None));
    let album_home_click_slot: Rc<RefCell<Option<Rc<dyn Fn(i64)>>>> =
        Rc::new(RefCell::new(None));
    let library_navigation_slot: Rc<RefCell<Option<Rc<dyn Fn(sidebar::SidebarFilter)>>>> =
        Rc::new(RefCell::new(None));
    let folder_navigation_slot: Rc<RefCell<Option<Rc<dyn Fn(i64, i64)>>>> =
        Rc::new(RefCell::new(None));
    // Open in Folder keeps this exact target alive briefly so a sidebar
    // Tree-mode reorder cannot replace it with a generic folder-header scroll.
    let open_in_folder_exact_target: Rc<Cell<Option<i64>>> = Rc::new(Cell::new(None));
    let navigate_to_folder: Rc<dyn Fn(i64, i64)> = {
        let slot = folder_navigation_slot.clone();
        Rc::new(move |folder_id, photo_id| {
            if let Some(callback) = slot.borrow().as_ref() {
                callback(folder_id, photo_id);
            }
        })
    };
    let context_menu_host: Rc<RefCell<Option<glib::WeakRef<gtk::Overlay>>>> =
        Rc::new(RefCell::new(None));
    let operation_progress = OperationProgressUi::new();
    let action_context = PhotoActionContext {
        connection: connection.clone(),
        gallery: gallery_for_actions.clone(),
        filter: filter.clone(),
        search: search_text.clone(),
        sort: sort.clone(),
        info: info.clone(),
        selected_photo: selected_photo.clone(),
        lightbox: Rc::downgrade(&lightbox),
        sidebar: sidebar_for_unavailable.clone(),
        create_album: create_album.clone(),
        import_folder: import_folder.clone(),
        delete_album: delete_album.clone(),
        on_unavailable: availability_refresh.clone(),
        navigate_to_folder: navigate_to_folder.clone(),
        open_collage: open_collage.clone(),
        open_edit: open_edit.clone(),
        edit_clipboard: edit_clipboard.clone(),
        export: export_photos.clone(),
        refresh_albums_home: {
            let slot = albums_home_refresh_slot.clone();
            Rc::new(move |albums| {
                if let Some(refresh) = slot.borrow().as_ref() {
                    refresh(albums);
                }
            })
        },
        window: window.clone().upcast::<gtk::Window>().downgrade(),
        context_menu_host: context_menu_host.clone(),
        operation_progress: operation_progress.clone(),
    };
    let saved_grid_thumbnail_size = grid_thumbnail_size_from_setting(&connection.borrow());
    let grid_zoom_syncing = Rc::new(Cell::new(false));
    info.grid_zoom.set_value(grid_zoom_slider_value(
        saved_grid_thumbnail_size.unwrap_or(DEFAULT_GRID_THUMBNAIL_SIZE),
    ));

    // Result activation should dismiss the visible search UI without running the
    // normal empty-query handler. Running that handler here would immediately
    // rebuild the current full library/folder model while the user is opening a
    // result, which is both unnecessary and can stall the GTK thread.
    let clear_search_after_result: Rc<dyn Fn()> = {
        let search_entry = search_entry_slot.clone();
        let search_text = search_text.clone();
        let suppressed = search_suppressed.clone();
        let debounce = search_debounce.clone();
        let cleared_query = cleared_search_query.clone();
        Rc::new(move || {
            if let Some(source) = debounce.borrow_mut().take() {
                let _ = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| source.remove()));
            }
            let query = search_text.borrow().clone();
            cleared_query.replace(Some(query.clone()));
            suppressed.set(true);
            if let Some(entry) = search_entry.borrow().as_ref() {
                entry.set_text("");
            }
            search_text.replace(String::new());
            suppressed.set(false);
            let cleared_query_for_timeout = cleared_query.clone();
            glib::timeout_add_local_once(Duration::from_millis(500), move || {
                if cleared_query_for_timeout.borrow().as_deref() == Some(query.as_str()) {
                    cleared_query_for_timeout.replace(None);
                }
            });
            
        })
    };

    let gallery = Rc::new(grid::Gallery::new(
        &[],
        saved_grid_thumbnail_size.unwrap_or(DEFAULT_GRID_THUMBNAIL_SIZE),
        move |photo| {
            info_for_grid.set_photo(photo.as_ref());
            selected_photo_for_grid.replace(photo);
        },
        {
            let availability_refresh = availability_refresh.clone();
            let clear_search_after_result = clear_search_after_result.clone();
            let filter = filter.clone();
            let search_text = search_text.clone();
            let connection = connection.clone();
            let open_edit = open_edit.clone();
            let open_collage = open_collage.clone();
            move |photos, selected_index, source| {
                if filter.get() == sidebar::SidebarFilter::History
                    && search_text.borrow().is_empty()
                {
                    if let Some(photo) = photos.get(selected_index) {
                        let is_collage = db::collage_project(&connection.borrow(), photo.id())
                            .ok()
                            .flatten()
                            .is_some();
                        if is_collage {
                            open_collage(vec![photo.id()]);
                        } else {
                            open_edit(photo.id());
                        }
                    }
                    return;
                }
                if photos
                    .get(selected_index)
                    .is_some_and(|photo| !photo.original_available())
                {
                    availability_refresh();
                }
                lightbox_for_grid.open_from_source(photos, selected_index, source);
                clear_search_after_result();
            }
        },
        {
            let action_context = action_context.clone();
            move |photo, anchor, x, y| {
                show_photo_context_menu(photo, anchor, action_context.clone(), x, y);
            }
        },
        {
            let connection = connection.clone();
            let availability_refresh = availability_refresh.clone();
            move |photo, anchor| {
                show_unavailable_dialog(
                    &anchor,
                    photo,
                    connection.clone(),
                    availability_refresh.clone(),
                );
            }
        },
        {
            let connection = connection.clone();
            let grid_zoom = info.grid_zoom.clone();
            let grid_zoom_syncing = grid_zoom_syncing.clone();
            let lightbox = lightbox.clone();
            move |width| {
                if let Err(error) = db::set_setting(
                    &connection.borrow(),
                    GRID_THUMBNAIL_SIZE_SETTING_KEY,
                    &width.to_string(),
                ) {
                    eprintln!("Could not save grid thumbnail size: {error}");
                }

                // A gallery zoom may finish just after the viewer opens.
                // Never let that stale completion overwrite the lightbox's
                // 0..100 zoom slider.
                if !lightbox.root.is_visible() {
                    grid_zoom_syncing.set(true);
                    grid_zoom.set_value(grid_zoom_slider_value(width));
                    grid_zoom_syncing.set(false);
                }
            }
        },
    ));
    // No stored size (or only the untouched legacy default): adopt the
    // ~4-thumbnails-per-row view level on the first real layout.
    if saved_grid_thumbnail_size.is_none() {
        gallery.enable_auto_default_zoom();
    }
    // Resolved size for views that only need a number (album covers).
    let grid_thumbnail_size = saved_grid_thumbnail_size.unwrap_or(DEFAULT_GRID_THUMBNAIL_SIZE);

    // Thumbnail appearance (Settings > Interface). Square corners toggle a CSS
    // class on the main window; whole-photo fit is applied to the gallery and
    // re-applied live when the toggles change.
    if crate::settings::saved_bool(
        &connection.borrow(),
        crate::db::THUMBNAIL_SQUARE_CORNERS_SETTING_KEY,
    )
    .unwrap_or(false)
    {
        window.add_css_class("square-corners");
    }
    gallery.set_fit_whole_photo(
        crate::settings::saved_bool(
            &connection.borrow(),
            crate::db::THUMBNAIL_FIT_WHOLE_PHOTO_SETTING_KEY,
        )
        .unwrap_or(false),
    );
    gallery.set_show_file_names(
        crate::settings::saved_bool(
            &connection.borrow(),
            crate::db::THUMBNAIL_FILE_NAMES_SETTING_KEY,
        )
        .unwrap_or(false),
    );
    gallery_for_actions.replace(Rc::downgrade(&gallery));
    apply_gallery_grouping(&gallery, filter.get(), sort.get(), group_mode.get(), true);

    // Reuse the gallery model for the Space shortcut. Re-querying the database
    // and rebuilding the complete library model here blocked the GTK thread.
    {
        let gallery = gallery.clone();
        let selected_photo = selected_photo.clone();
        let lightbox = lightbox.clone();
        let availability_refresh = availability_refresh.clone();
        let filter = filter.clone();
        let search_text = search_text.clone();

        space_open_slot.replace(Some(Rc::new(move || {
            if filter.get() == sidebar::SidebarFilter::Library && search_text.borrow().is_empty() {
                return;
            }
            let photos = gallery.photo_objects();
            let selected_id = selected_photo
                .borrow()
                .as_ref()
                .map(|photo| photo.id())
                .filter(|id| photos.iter().any(|photo| photo.id() == *id))
                .or_else(|| gallery.selected_photo_ids(None).into_iter().next());
            let Some(selected_id) = selected_id else {
                return;
            };
            let Some(index) = photos.iter().position(|photo| photo.id() == selected_id) else {
                return;
            };
            if !photos[index].original_available() {
                availability_refresh();
            }
            lightbox.open(photos, index);
        })));
    }

    let create_context = action_context.clone();
    let create_parent = window.clone();
    create_album_slot.replace(Some(Rc::new(move || {
        show_create_album_dialog(
            create_parent.clone().upcast(),
            Vec::new(),
            create_context.clone(),
        );
    })));
    let delete_context = action_context.clone();
    let delete_parent = window.clone();
    delete_album_slot.replace(Some(Rc::new(move |album_id| {
        show_delete_album_confirmation(
            delete_parent.clone().upcast(),
            album_id,
            delete_context.clone(),
        );
    })));

    configure_infobar_album_menu(&info.add_to_album, action_context.clone());

    // Destructive maintenance actions for the Settings → Library page. The
    // settings window owns the buttons and confirmation dialogs; the actual
    // behaviour stays here where the gallery and refresh context live.
    let settings_maintenance = crate::settings::LibraryMaintenance {
        clear_thumbnails: {
            let connection = connection.clone();
            let gallery = gallery.clone();
            let filter = filter.clone();
            let search = search_text.clone();
            let sort = sort.clone();
            let availability_refresh = availability_refresh.clone();
            Rc::new(move || {
                if let Err(error) = crate::thumbnail::clear_cache() {
                    eprintln!("Could not clear thumbnails: {error}");
                }
                refresh_grid(
                    &connection,
                    filter.get(),
                    &search.borrow(),
                    sort.get(),
                    &gallery,
                );
                availability_refresh();
            })
        },
        clear_database: {
            let connection = connection.clone();
            let gallery = gallery.clone();
            let filter = filter.clone();
            let search = search_text.clone();
            let sort = sort.clone();
            let availability_refresh = availability_refresh.clone();
            Rc::new(move || {
                if let Err(error) = db::clear_photos(&connection.borrow()) {
                    eprintln!("Could not clear database: {error}");
                }
                refresh_grid(
                    &connection,
                    filter.get(),
                    &search.borrow(),
                    sort.get(),
                    &gallery,
                );
                availability_refresh();
            })
        },
        clear_all: {
            let connection = connection.clone();
            let gallery = gallery.clone();
            let filter = filter.clone();
            let search = search_text.clone();
            let sort = sort.clone();
            let availability_refresh = availability_refresh.clone();
            Rc::new(move || {
                if let Err(error) = db::clear_all(&connection.borrow()) {
                    eprintln!("Could not clear database: {error}");
                }
                if let Err(error) = crate::thumbnail::clear_cache() {
                    eprintln!("Could not clear thumbnails: {error}");
                }
                refresh_grid(
                    &connection,
                    filter.get(),
                    &search.borrow(),
                    sort.get(),
                    &gallery,
                );
                availability_refresh();
            })
        },
    };

    let switch_library_slot: Rc<RefCell<Option<Rc<dyn Fn(&str) -> Result<(), String>>>>> =
        Rc::new(RefCell::new(None));
    let settings_window = crate::settings::SettingsWindow::default();
    let settings_window_for_switch = settings_window.clone();
    let settings_parent = window.clone();
    let settings_surface = window.clone();
    let settings_gallery_for_thumbs = gallery.clone();
    let settings_connection = connection.clone();
    let settings_gallery = gallery.clone();
    let settings_filter = filter.clone();
    let settings_search = search_text.clone();
    let settings_sort = sort.clone();
    let settings_lightbox = lightbox.clone();
    let settings_sidebar = sidebar_for_unavailable.clone();
    let settings_on_unavailable = availability_refresh.clone();
    let settings_albums_refresh = albums_home_refresh_slot.clone();
    let settings_rebuild_folder_watches = rebuild_folder_watches.clone();
    let settings_theme_engine = theme_engine.clone();
    let settings_switch_library_slot = switch_library_slot.clone();
    let present_settings: Rc<dyn Fn(Option<&'static str>)> = Rc::new(move |initial_page| {
        let connection = settings_connection.clone();
        let gallery = settings_gallery.clone();
        let filter = settings_filter.clone();
        let search = settings_search.clone();
        let sort = settings_sort.clone();
        let lightbox = settings_lightbox.clone();
        let sidebar = settings_sidebar.clone();
        let on_unavailable = settings_on_unavailable.clone();
        let theme_connection = settings_connection.clone();
        let theme_albums_refresh = settings_albums_refresh.clone();
        let watch_connection = settings_connection.clone();
        let watch_sidebar = settings_sidebar.clone();
        let watch_on_unavailable = settings_on_unavailable.clone();
        let maintenance = settings_maintenance.clone();
        let thumbs_window = settings_surface.clone();
        let thumbs_gallery = settings_gallery_for_thumbs.clone();
        let thumbs_connection = settings_connection.clone();
        let visibility_connection = settings_connection.clone();
        let visibility_sidebar = settings_sidebar.clone();
        let switch_library_slot = settings_switch_library_slot.clone();
        settings_window.present(
            &settings_parent,
            settings_connection.clone(),
            Rc::new(move || {
                lightbox.close();
                refresh_grid(
                    &connection,
                    filter.get(),
                    &search.borrow(),
                    sort.get(),
                    &gallery,
                );
                if let Some(sidebar) = sidebar.borrow().as_ref().cloned() {
                    if let Ok(folders) = db::folders(&connection.borrow()) {
                        sidebar::refresh_folder_rows(&sidebar, &folders, &on_unavailable);
                    }
                    if let Ok(counts) = db::sidebar_counts(&connection.borrow()) {
                        sidebar::refresh_library_counts(&sidebar, counts, &on_unavailable);
                    }
                }
            }),
            Rc::new(move || {
                let albums = db::albums(&theme_connection.borrow()).unwrap_or_default();
                if let Some(refresh) = theme_albums_refresh.borrow().as_ref() {
                    refresh(&albums);
                }
            }),
            Rc::new(move || {
                crate::window::debug_log("THUMB SETTINGS: apply callback entered");
                let square = crate::settings::saved_bool(
                    &thumbs_connection.borrow(),
                    crate::db::THUMBNAIL_SQUARE_CORNERS_SETTING_KEY,
                )
                .unwrap_or(false);
                let fit = crate::settings::saved_bool(
                    &thumbs_connection.borrow(),
                    crate::db::THUMBNAIL_FIT_WHOLE_PHOTO_SETTING_KEY,
                )
                .unwrap_or(false);
                let show_file_names = crate::settings::saved_bool(
                    &thumbs_connection.borrow(),
                    crate::db::THUMBNAIL_FILE_NAMES_SETTING_KEY,
                )
                .unwrap_or(false);
                if square {
                    thumbs_window.add_css_class("square-corners");
                } else {
                    thumbs_window.remove_css_class("square-corners");
                }
                crate::window::debug_log(&format!(
                    "THUMB SETTINGS: css class applied (square={square}), deferring fit={fit} to idle"
                ));
                // Defer the tile walk out of the switch notification so the
                // settings UI settles before the gallery relayouts.
                let gallery_for_fit = thumbs_gallery.clone();
                glib::idle_add_local_once(move || {
                    crate::window::debug_log("THUMB SETTINGS: set_fit_whole_photo begin");
                    gallery_for_fit.set_fit_whole_photo(fit);
                    crate::window::debug_log("THUMB SETTINGS: set_fit_whole_photo end");
                });
                let gallery_for_names = thumbs_gallery.clone();
                glib::idle_add_local_once(move || {
                    gallery_for_names.set_show_file_names(show_file_names);
                });
                crate::window::debug_log("THUMB SETTINGS: apply callback exit");
            }),
            Rc::new(move || {
                if let Some(sidebar) = visibility_sidebar.borrow().as_ref().cloned() {
                    let visibility = sidebar::SidebarVisibility::from_connection(
                        &visibility_connection.borrow(),
                    );
                    sidebar::apply_visibility(&sidebar, visibility);
                }
            }),
            {
                let rebuild_folder_watches = settings_rebuild_folder_watches.clone();
                Rc::new(move || {
                    rebuild_folder_watches();
                    if let Some(sidebar) = watch_sidebar.borrow().as_ref().cloned() {
                        if let Ok(folders) = db::folders(&watch_connection.borrow()) {
                            sidebar::refresh_folder_rows(
                                &sidebar,
                                &folders,
                                &watch_on_unavailable,
                            );
                        }
                    }
                })
            },
            maintenance,
            crate::settings::DatabaseManagement {
                switch_library: Rc::new(move |id| {
                    switch_library_slot
                        .borrow()
                        .as_ref()
                        .ok_or_else(|| "library switcher is not ready".to_owned())?(id)
                }),
            },
            settings_theme_engine.clone(),
            initial_page,
        );
    });
    let present_settings_from_more = present_settings.clone();
    info.more.connect_clicked(move |_| {
        present_settings_from_more(None);
    });

    let action_context_for_lightbox = action_context.clone();
    lightbox.set_context_menu_handler(move |photo, anchor, x, y| {
        show_photo_context_menu(photo, anchor, action_context_for_lightbox.clone(), x, y);
    });

    // Existing collection navigation remains available to the non-Folder
    // lightbox views. Folder mode no longer switches collections: its gallery
    // already contains the complete continuous folder stream.
    let connection_for_collection_nav = connection.clone();
    let filter_for_collection_nav = filter.clone();
    let search_for_collection_nav = search_text.clone();
    let sort_for_collection_nav = sort.clone();
    let rating_filter_for_collection_nav = rating_filter.clone();
    let group_mode_for_collection_nav = group_mode.clone();
    let gallery_for_collection_nav = gallery.clone();
    let lightbox_for_collection_nav = lightbox.clone();
    let sidebar_selection_for_collection_nav = sidebar_selection_slot.clone();
    let selected_photo_for_collection_nav = selected_photo.clone();
    let collection_navigation: Rc<dyn Fn(i32)> = Rc::new(move |direction| {
        if direction == 0 {
            return;
        }

        let step: isize = if direction < 0 { -1 } else { 1 };
        let current_filter = filter_for_collection_nav.get();
        // Folder mode is already one continuous collection, so Up/Down must
        // not rebuild the grid into another single-folder page. Other existing
        // collection navigation (Albums/Library) keeps its previous behavior.
        if matches!(current_filter, sidebar::SidebarFilter::Folder(_)) {
            return;
        }
        let search = search_for_collection_nav.borrow().clone();

        match current_filter {
            sidebar::SidebarFilter::Folder(current_folder_id) => {
                // Navigate in the order the user can actually see in the
                // Folders sidebar. Tree mode therefore follows visible tree
                // rows, while Imported-only mode contains only imported roots.
                let folders = db::folders(&connection_for_collection_nav.borrow())
                    .unwrap_or_default();
                let folder_ids = sidebar_selection_for_collection_nav
                    .borrow()
                    .as_ref()
                    .map(sidebar::visible_folder_ids)
                    .unwrap_or_else(|| folders.iter().map(|folder| folder.id).collect());
                let Some(current_index) = folder_ids
                    .iter()
                    .position(|folder_id| *folder_id == current_folder_id)
                else {
                    return;
                };

                let mut candidate = current_index as isize + step;
                while candidate >= 0 && candidate < folder_ids.len() as isize {
                    let folder_id = folder_ids[candidate as usize];
                    let Some(folder) = folders.iter().find(|folder| folder.id == folder_id) else {
                        candidate += step;
                        continue;
                    };
                    let mut photos = db::photos(
                        &connection_for_collection_nav.borrow(),
                        Some(folder.id),
                        false,
                        (!search.is_empty()).then_some(search.as_str()),
                    )
                    .unwrap_or_default();
                    retain_enabled_formats(&connection_for_collection_nav.borrow(), &mut photos);
                    apply_rating_filter(&mut photos, rating_filter_for_collection_nav.get());
                    sort_photos(&mut photos, sort_for_collection_nav.get());

                    if !photos.is_empty() {
                        let new_filter = sidebar::SidebarFilter::Folder(folder.id);
                        filter_for_collection_nav.set(new_filter);
                        if let Some(sidebar) = sidebar_selection_for_collection_nav.borrow().as_ref() {
                            sidebar::set_active_filter(sidebar, new_filter);
                            let sidebar = sidebar.clone();
                            let folder_id = folder.id;
                            glib::timeout_add_local_once(Duration::from_millis(100), move || {
                                sidebar::scroll_to_folder(&sidebar, folder_id);
                            });
                        }
                        apply_gallery_grouping(
                            &gallery_for_collection_nav,
                            new_filter,
                            sort_for_collection_nav.get(),
                            group_mode_for_collection_nav.get(),
                            search.is_empty(),
                        );
                        gallery_for_collection_nav.replace(&photos);
                        let objects = photos
                            .iter()
                            .map(crate::photo_object::PhotoObject::from_photo)
                            .collect::<Vec<_>>();
                        if lightbox_for_collection_nav.root.is_visible() {
                            lightbox_for_collection_nav.open(objects, 0);
                        }
                        return;
                    }

                    candidate += step;
                }
            }
            sidebar::SidebarFilter::Album(current_album_id) => {
                let albums = db::albums(&connection_for_collection_nav.borrow())
                    .unwrap_or_default();
                let Some(current_index) = albums
                    .iter()
                    .position(|album| album.id == current_album_id)
                else {
                    return;
                };
                let first_available_album = albums.iter().position(|album| {
                    let mut photos = db::photos_in_album(
                        &connection_for_collection_nav.borrow(),
                        album.id,
                        (!search.is_empty()).then_some(search.as_str()),
                    )
                    .unwrap_or_default();
                    retain_enabled_formats(&connection_for_collection_nav.borrow(), &mut photos);
                    apply_rating_filter(&mut photos, rating_filter_for_collection_nav.get());
                    !photos.is_empty()
                });
                let last_available_album = albums.iter().rposition(|album| {
                    let mut photos = db::photos_in_album(
                        &connection_for_collection_nav.borrow(),
                        album.id,
                        (!search.is_empty()).then_some(search.as_str()),
                    )
                    .unwrap_or_default();
                    retain_enabled_formats(&connection_for_collection_nav.borrow(), &mut photos);
                    apply_rating_filter(&mut photos, rating_filter_for_collection_nav.get());
                    !photos.is_empty()
                });

                // The album sequence is connected to Recently Added at its
                // upper boundary. Selecting the last item here makes reverse
                // navigation feel continuous instead of opening another
                // album unexpectedly.
                if direction < 0 && Some(current_index) == first_available_album {
                    let mut photos = db::photos(
                        &connection_for_collection_nav.borrow(),
                        None,
                        false,
                        (!search.is_empty()).then_some(search.as_str()),
                    )
                    .unwrap_or_default();
                    retain_enabled_formats(&connection_for_collection_nav.borrow(), &mut photos);
                    limit_recently_added(
                        &connection_for_collection_nav.borrow(),
                        sidebar::SidebarFilter::RecentlyAdded,
                        &mut photos,
                    );
                    apply_rating_filter(&mut photos, rating_filter_for_collection_nav.get());
                    sort_photos(&mut photos, sort_for_collection_nav.get());
                    if !photos.is_empty() {
                        let new_filter = sidebar::SidebarFilter::RecentlyAdded;
                        filter_for_collection_nav.set(new_filter);
                        if let Some(sidebar) = sidebar_selection_for_collection_nav.borrow().as_ref() {
                            sidebar::set_active_filter(sidebar, new_filter);
                        }
                        apply_gallery_grouping(
                            &gallery_for_collection_nav,
                            new_filter,
                            sort_for_collection_nav.get(),
                            group_mode_for_collection_nav.get(),
                            search.is_empty(),
                        );
                        gallery_for_collection_nav.replace(&photos);
                        gallery_for_collection_nav.select_last_photo();
                        let objects = photos
                            .iter()
                            .map(crate::photo_object::PhotoObject::from_photo)
                            .collect::<Vec<_>>();
                        if lightbox_for_collection_nav.root.is_visible() {
                            lightbox_for_collection_nav.open(objects, photos.len() - 1);
                        }
                        return;
                    }
                }

                // The last album connects to the first available folder.
                if direction > 0 && Some(current_index) == last_available_album {
                    let folders = db::folders(&connection_for_collection_nav.borrow())
                        .unwrap_or_default();
                    for folder in folders {
                        let mut photos = db::photos(
                            &connection_for_collection_nav.borrow(),
                            Some(folder.id),
                            false,
                            (!search.is_empty()).then_some(search.as_str()),
                        )
                        .unwrap_or_default();
                        retain_enabled_formats(&connection_for_collection_nav.borrow(), &mut photos);
                        apply_rating_filter(&mut photos, rating_filter_for_collection_nav.get());
                        sort_photos(&mut photos, sort_for_collection_nav.get());
                        if photos.is_empty() {
                            continue;
                        }

                        let new_filter = sidebar::SidebarFilter::Folder(folder.id);
                        filter_for_collection_nav.set(new_filter);
                        if let Some(sidebar) = sidebar_selection_for_collection_nav.borrow().as_ref() {
                            sidebar::set_active_filter(sidebar, new_filter);
                            let sidebar = sidebar.clone();
                            let folder_id = folder.id;
                            glib::timeout_add_local_once(Duration::from_millis(100), move || {
                                sidebar::scroll_to_folder(&sidebar, folder_id);
                            });
                        }
                        apply_gallery_grouping(
                            &gallery_for_collection_nav,
                            new_filter,
                            sort_for_collection_nav.get(),
                            group_mode_for_collection_nav.get(),
                            search.is_empty(),
                        );
                        gallery_for_collection_nav.replace(&photos);
                        let objects = photos
                            .iter()
                            .map(crate::photo_object::PhotoObject::from_photo)
                            .collect::<Vec<_>>();
                        if lightbox_for_collection_nav.root.is_visible() {
                            lightbox_for_collection_nav.open(objects, 0);
                        }
                        return;
                    }
                }

                let mut candidate = current_index as isize + step;
                while candidate >= 0 && candidate < albums.len() as isize {
                    let album = &albums[candidate as usize];
                    let mut photos = db::photos_in_album(
                        &connection_for_collection_nav.borrow(),
                        album.id,
                        (!search.is_empty()).then_some(search.as_str()),
                    )
                    .unwrap_or_default();
                    retain_enabled_formats(&connection_for_collection_nav.borrow(), &mut photos);
                    apply_rating_filter(&mut photos, rating_filter_for_collection_nav.get());
                    sort_photos(&mut photos, sort_for_collection_nav.get());

                    if !photos.is_empty() {
                        let new_filter = sidebar::SidebarFilter::Album(album.id);
                        filter_for_collection_nav.set(new_filter);
                        if let Some(sidebar) = sidebar_selection_for_collection_nav.borrow().as_ref() {
                            sidebar::set_active_filter(sidebar, new_filter);
                        }
                        apply_gallery_grouping(
                            &gallery_for_collection_nav,
                            new_filter,
                            sort_for_collection_nav.get(),
                            group_mode_for_collection_nav.get(),
                            search.is_empty(),
                        );
                        gallery_for_collection_nav.replace(&photos);
                        let objects = photos
                            .iter()
                            .map(crate::photo_object::PhotoObject::from_photo)
                            .collect::<Vec<_>>();
                        if lightbox_for_collection_nav.root.is_visible() {
                            lightbox_for_collection_nav.open(objects, 0);
                        }
                        return;
                    }

                    candidate += step;
                }
            }
            sidebar::SidebarFilter::All
            | sidebar::SidebarFilter::Favorites
            | sidebar::SidebarFilter::RecentlyAdded => {
                // Photos connects forward to Favorites at its last item.
                if current_filter == sidebar::SidebarFilter::All && direction > 0 {
                    let mut photos = db::photos(
                        &connection_for_collection_nav.borrow(),
                        None,
                        true,
                        (!search.is_empty()).then_some(search.as_str()),
                    )
                    .unwrap_or_default();
                    retain_enabled_formats(&connection_for_collection_nav.borrow(), &mut photos);
                    apply_rating_filter(&mut photos, rating_filter_for_collection_nav.get());
                    sort_photos(&mut photos, sort_for_collection_nav.get());
                    if !photos.is_empty() {
                        let new_filter = sidebar::SidebarFilter::Favorites;
                        filter_for_collection_nav.set(new_filter);
                        if let Some(sidebar) = sidebar_selection_for_collection_nav.borrow().as_ref() {
                            sidebar::set_active_filter(sidebar, new_filter);
                        }
                        apply_gallery_grouping(
                            &gallery_for_collection_nav,
                            new_filter,
                            sort_for_collection_nav.get(),
                            group_mode_for_collection_nav.get(),
                            search.is_empty(),
                        );
                        gallery_for_collection_nav.replace(&photos);
                        let objects = photos
                            .iter()
                            .map(crate::photo_object::PhotoObject::from_photo)
                            .collect::<Vec<_>>();
                        if lightbox_for_collection_nav.root.is_visible() {
                            lightbox_for_collection_nav.open(objects, 0);
                        }
                        return;
                    }
                }

                // Favorites sits between Photos and Recently Added in the
                // keyboard sequence. Keep both boundaries continuous and
                // select the correct end of the destination collection.
                if current_filter == sidebar::SidebarFilter::Favorites
                    && direction < 0
                {
                    let mut photos = db::photos(
                        &connection_for_collection_nav.borrow(),
                        None,
                        false,
                        (!search.is_empty()).then_some(search.as_str()),
                    )
                    .unwrap_or_default();
                    retain_enabled_formats(&connection_for_collection_nav.borrow(), &mut photos);
                    apply_rating_filter(&mut photos, rating_filter_for_collection_nav.get());
                    sort_photos(&mut photos, sort_for_collection_nav.get());
                    if !photos.is_empty() {
                        let new_filter = sidebar::SidebarFilter::All;
                        filter_for_collection_nav.set(new_filter);
                        if let Some(sidebar) = sidebar_selection_for_collection_nav.borrow().as_ref() {
                            sidebar::set_active_filter(sidebar, new_filter);
                        }
                        apply_gallery_grouping(
                            &gallery_for_collection_nav,
                            new_filter,
                            sort_for_collection_nav.get(),
                            group_mode_for_collection_nav.get(),
                            search.is_empty(),
                        );
                        gallery_for_collection_nav.replace(&photos);
                        gallery_for_collection_nav.select_last_photo();
                        let objects = photos
                            .iter()
                            .map(crate::photo_object::PhotoObject::from_photo)
                            .collect::<Vec<_>>();
                        if lightbox_for_collection_nav.root.is_visible() {
                            lightbox_for_collection_nav.open(objects, photos.len() - 1);
                        }
                        return;
                    }
                }

                if current_filter == sidebar::SidebarFilter::Favorites
                    && direction > 0
                {
                    let mut photos = db::photos(
                        &connection_for_collection_nav.borrow(),
                        None,
                        false,
                        (!search.is_empty()).then_some(search.as_str()),
                    )
                    .unwrap_or_default();
                    retain_enabled_formats(&connection_for_collection_nav.borrow(), &mut photos);
                    limit_recently_added(
                        &connection_for_collection_nav.borrow(),
                        sidebar::SidebarFilter::RecentlyAdded,
                        &mut photos,
                    );
                    apply_rating_filter(&mut photos, rating_filter_for_collection_nav.get());
                    sort_photos(&mut photos, sort_for_collection_nav.get());
                    if !photos.is_empty() {
                        let new_filter = sidebar::SidebarFilter::RecentlyAdded;
                        filter_for_collection_nav.set(new_filter);
                        if let Some(sidebar) = sidebar_selection_for_collection_nav.borrow().as_ref() {
                            sidebar::set_active_filter(sidebar, new_filter);
                        }
                        apply_gallery_grouping(
                            &gallery_for_collection_nav,
                            new_filter,
                            sort_for_collection_nav.get(),
                            group_mode_for_collection_nav.get(),
                            search.is_empty(),
                        );
                        gallery_for_collection_nav.replace(&photos);
                        let objects = photos
                            .iter()
                            .map(crate::photo_object::PhotoObject::from_photo)
                            .collect::<Vec<_>>();
                        if lightbox_for_collection_nav.root.is_visible() {
                            lightbox_for_collection_nav.open(objects, 0);
                        }
                        return;
                    }
                }

                if current_filter == sidebar::SidebarFilter::RecentlyAdded
                    && direction < 0
                {
                    let mut photos = db::photos(
                        &connection_for_collection_nav.borrow(),
                        None,
                        true,
                        (!search.is_empty()).then_some(search.as_str()),
                    )
                    .unwrap_or_default();
                    retain_enabled_formats(&connection_for_collection_nav.borrow(), &mut photos);
                    apply_rating_filter(&mut photos, rating_filter_for_collection_nav.get());
                    sort_photos(&mut photos, sort_for_collection_nav.get());
                    if !photos.is_empty() {
                        let new_filter = sidebar::SidebarFilter::Favorites;
                        filter_for_collection_nav.set(new_filter);
                        if let Some(sidebar) = sidebar_selection_for_collection_nav.borrow().as_ref() {
                            sidebar::set_active_filter(sidebar, new_filter);
                        }
                        apply_gallery_grouping(
                            &gallery_for_collection_nav,
                            new_filter,
                            sort_for_collection_nav.get(),
                            group_mode_for_collection_nav.get(),
                            search.is_empty(),
                        );
                        gallery_for_collection_nav.replace(&photos);
                        gallery_for_collection_nav.select_last_photo();
                        let objects = photos
                            .iter()
                            .map(crate::photo_object::PhotoObject::from_photo)
                            .collect::<Vec<_>>();
                        if lightbox_for_collection_nav.root.is_visible() {
                            lightbox_for_collection_nav.open(objects, photos.len() - 1);
                        }
                        return;
                    }
                }

                // Recently Added connects forward to the first album. This
                // boundary must win over folder-based navigation, otherwise
                // the selected photo's folder can jump to an unrelated album.
                if current_filter == sidebar::SidebarFilter::RecentlyAdded && direction > 0 {
                    let albums = db::albums(&connection_for_collection_nav.borrow())
                        .unwrap_or_default();
                    for album in albums {
                        let mut photos = db::photos_in_album(
                            &connection_for_collection_nav.borrow(),
                            album.id,
                            (!search.is_empty()).then_some(search.as_str()),
                        )
                        .unwrap_or_default();
                        retain_enabled_formats(&connection_for_collection_nav.borrow(), &mut photos);
                        apply_rating_filter(&mut photos, rating_filter_for_collection_nav.get());
                        sort_photos(&mut photos, sort_for_collection_nav.get());
                        if photos.is_empty() {
                            continue;
                        }

                        let new_filter = sidebar::SidebarFilter::Album(album.id);
                        filter_for_collection_nav.set(new_filter);
                        if let Some(sidebar) = sidebar_selection_for_collection_nav.borrow().as_ref() {
                            sidebar::set_active_filter(sidebar, new_filter);
                        }
                        apply_gallery_grouping(
                            &gallery_for_collection_nav,
                            new_filter,
                            sort_for_collection_nav.get(),
                            group_mode_for_collection_nav.get(),
                            search.is_empty(),
                        );
                        gallery_for_collection_nav.replace(&photos);
                        let objects = photos
                            .iter()
                            .map(crate::photo_object::PhotoObject::from_photo)
                            .collect::<Vec<_>>();
                        if lightbox_for_collection_nav.root.is_visible() {
                            lightbox_for_collection_nav.open(objects, 0);
                        }
                        return;
                    }
                }

                // Library views contain photos from multiple folders. Use the
                // selected thumbnail's folder as the current position.
                let Some(current_folder_id) = selected_photo_for_collection_nav
                    .borrow()
                    .as_ref()
                    .map(|photo| photo.folder_id())
                    .filter(|folder_id| *folder_id > 0)
                else {
                    return;
                };
                let folders = db::folders(&connection_for_collection_nav.borrow())
                    .unwrap_or_default();
                let Some(current_index) = folders
                    .iter()
                    .position(|folder| folder.id == current_folder_id)
                else {
                    return;
                };

                let mut candidate = current_index as isize + step;
                let favorites_only = current_filter == sidebar::SidebarFilter::Favorites;
                while candidate >= 0 && candidate < folders.len() as isize {
                    let folder = &folders[candidate as usize];
                    let mut photos = db::photos(
                        &connection_for_collection_nav.borrow(),
                        Some(folder.id),
                        favorites_only,
                        (!search.is_empty()).then_some(search.as_str()),
                    )
                    .unwrap_or_default();
                    retain_enabled_formats(&connection_for_collection_nav.borrow(), &mut photos);
                    limit_recently_added(
                        &connection_for_collection_nav.borrow(),
                        current_filter,
                        &mut photos,
                    );
                    apply_rating_filter(&mut photos, rating_filter_for_collection_nav.get());
                    sort_photos(&mut photos, sort_for_collection_nav.get());

                    if !photos.is_empty() {
                        let new_filter = sidebar::SidebarFilter::Folder(folder.id);
                        filter_for_collection_nav.set(new_filter);
                        if let Some(sidebar) = sidebar_selection_for_collection_nav.borrow().as_ref() {
                            sidebar::set_active_filter(sidebar, new_filter);
                            let sidebar = sidebar.clone();
                            let folder_id = folder.id;
                            glib::timeout_add_local_once(Duration::from_millis(100), move || {
                                sidebar::scroll_to_folder(&sidebar, folder_id);
                            });
                        }
                        apply_gallery_grouping(
                            &gallery_for_collection_nav,
                            new_filter,
                            sort_for_collection_nav.get(),
                            group_mode_for_collection_nav.get(),
                            search.is_empty(),
                        );
                        gallery_for_collection_nav.replace(&photos);
                        let objects = photos
                            .iter()
                            .map(crate::photo_object::PhotoObject::from_photo)
                            .collect::<Vec<_>>();
                        if lightbox_for_collection_nav.root.is_visible() {
                            lightbox_for_collection_nav.open(objects, 0);
                        }
                        return;
                    }

                    candidate += step;
                }
            }
            sidebar::SidebarFilter::Library | sidebar::SidebarFilter::History => {}
            sidebar::SidebarFilter::Albums => {
                // The Albums home view is not a photo thumbnail grid.
            }
        }
    });

    // Folder mode now uses native GridView keyboard behavior. Folder-to-folder
    // movement comes from the continuous model itself; there is no special
    // Up/Down collection switch here anymore.

    collection_navigation_slot.replace(Some(collection_navigation.clone()));
    let collection_navigation_for_lightbox = collection_navigation.clone();
    lightbox.set_collection_navigation_handler(move |direction| {
        collection_navigation_for_lightbox(direction)
    });

    gallery.root.add_css_class("photo-grid");

    let content = gtk::Box::new(gtk::Orientation::Vertical, 0);

    // Status/progress is embedded in the header title area (next to the
    // search entry) instead of its own row above the grid: appearing or
    // hiding it must never resize the photo grid.
    let refresh_status_box = operation_progress.root().clone();
    let refresh_status_spinner = operation_progress.spinner().clone();
    let refresh_status_label = operation_progress.label().clone();
    let refresh_status_stop = operation_progress.stop().clone();

    let grid_scroll = gtk::ScrolledWindow::new();
    grid_scroll.set_vexpand(true);
    grid_scroll.set_hexpand(true);
    // GtkGridView remains the direct scrollable child for every non-Folder
    // view, preserving its existing virtualization and selection behavior.
    grid_scroll.set_child(Some(&gallery.root));

    let folder_scroll = gtk::ScrolledWindow::new();
    folder_scroll.set_vexpand(true);
    folder_scroll.set_hexpand(true);
    // Folder mode now uses the section-aware flat-photo surface by default.
    // The legacy ListView remains available behind PICASA_LEGACY_FOLDER_LIST=1.
    if crate::grid::sectioned_folder_view_enabled() {
        folder_scroll.set_child(Some(&gallery.folder_sectioned_root));
        gallery.attach_sectioned_folder_scroll(&folder_scroll);
    } else {
        folder_scroll.set_child(Some(&gallery.folder_root));
    }
    let folder_scroll_overlay = gtk::Overlay::new();
    folder_scroll_overlay.set_hexpand(true);
    folder_scroll_overlay.set_vexpand(true);
    folder_scroll_overlay.set_child(Some(&folder_scroll));
    if !crate::grid::sectioned_folder_view_enabled() {
        // Legacy Folder ListView owns the external rubber-band overlay.
        // SectionedFolderView draws and positions its own band inside GtkFixed.
        folder_scroll_overlay.add_overlay(&gallery.folder_rubberband);
    }

    // A temporary date bubble makes a long chronological All Photos scrollbar
    // usable like a timeline. It is deliberately attached only to the GridView
    // scrollbar: Folder mode is not globally date-sorted.
    let scrub_date_label = gtk::Label::new(None);
    scrub_date_label.set_halign(gtk::Align::End);
    scrub_date_label.set_valign(gtk::Align::Center);
    scrub_date_label.set_margin_end(34);
    scrub_date_label.set_can_target(false);
    scrub_date_label.set_visible(false);
    scrub_date_label.add_css_class("scroll-scrub-date");
    let scrub_dragging = Rc::new(Cell::new(false));
    let scrub_hide_generation = Rc::new(Cell::new(0_u64));
    let update_scrub_date: Rc<dyn Fn(f64)> = Rc::new({
        let gallery = gallery.clone();
        let filter = filter.clone();
        let sort = sort.clone();
        let label = scrub_date_label.clone();
        move |scroll_y: f64| {
            let date = match sort.get().field {
                SortField::DateTaken => grid::GroupDate::Taken,
                SortField::DateAdded => grid::GroupDate::Added,
                _ => {
                    label.set_visible(false);
                    return;
                }
            };
            if filter.get() != sidebar::SidebarFilter::All {
                label.set_visible(false);
                return;
            }
            label.set_text(&gallery.month_label_for_scroll_position(scroll_y, date));
            label.set_visible(true);
        }
    });
    let scrollbar = grid_scroll.vscrollbar();
    let scrub_press = gtk::GestureClick::new();
    scrub_press.set_button(0);
    {
        let dragging = scrub_dragging.clone();
        let hide_generation = scrub_hide_generation.clone();
        let adjustment = grid_scroll.vadjustment();
        let update = update_scrub_date.clone();
        scrub_press.connect_pressed(move |_, _, _, _| {
            hide_generation.set(hide_generation.get().wrapping_add(1));
            dragging.set(true);
            update(adjustment.value());
        });
    }
    {
        let dragging = scrub_dragging.clone();
        let hide_generation = scrub_hide_generation.clone();
        let label = scrub_date_label.clone();
        scrub_press.connect_released(move |_, _, _, _| {
            if !dragging.replace(false) {
                return;
            }
            let generation = hide_generation.get().wrapping_add(1);
            hide_generation.set(generation);
            let label = label.clone();
            let hide_generation = hide_generation.clone();
            glib::timeout_add_local_once(Duration::from_millis(550), move || {
                if hide_generation.get() == generation {
                    label.set_visible(false);
                }
            });
        });
    }
    scrollbar.add_controller(scrub_press);
    {
        let dragging = scrub_dragging.clone();
        let update = update_scrub_date.clone();
        grid_scroll.vadjustment().connect_value_changed(move |adjustment| {
            if dragging.get() {
                update(adjustment.value());
            }
        });
    }

    let gallery_scroll_stack = gtk::Stack::new();
    gallery_scroll_stack.set_hexpand(true);
    gallery_scroll_stack.set_vexpand(true);
    gallery_scroll_stack.add_named(&grid_scroll, Some("grid"));
    gallery_scroll_stack.add_named(&folder_scroll_overlay, Some("folders"));
    {
        let gallery_scroll_stack = gallery_scroll_stack.clone();
        let gallery_for_folder_view = gallery.clone();
        gallery.set_folder_view_changed_handler(move |folder_mode| {
            let folder_sectioned =
                crate::grid::sectioned_folder_view_enabled() && folder_mode;
            let folder_grid_experiment =
                crate::grid::folder_gridview_experiment_enabled()
                    && folder_mode
                    && !folder_sectioned;
            gallery_scroll_stack.set_visible_child_name(if folder_mode && !folder_grid_experiment {
                "folders"
            } else {
                "grid"
            });
            if folder_mode {
                if folder_sectioned {
                    if std::env::var_os("PICASA_TRACE").is_some() {
                        eprintln!("PIC_FOLDER_SECTIONED enabled mode=flat_photo_virtualized");
                    }
                    gallery_for_folder_view.folder_sectioned_root.grab_focus();
                    let gallery = gallery_for_folder_view.clone();
                    glib::idle_add_local_once(move || {
                        gallery.refresh_sectioned_folder();
                    });
                    return;
                }
                if folder_grid_experiment {
                    if std::env::var_os("PICASA_TRACE").is_some() {
                        eprintln!("PIC_FOLDER_GRIDVIEW enabled mode=photo_grid folder_indicator=sticky");
                    }
                    gallery_for_folder_view.root.grab_focus();
                    gallery_for_folder_view
                        .update_group_header_for_scroll(gallery_for_folder_view.scroll_position());
                    let gallery = gallery_for_folder_view.clone();
                    glib::timeout_add_local_once(Duration::from_millis(90), move || {
                        gallery.refresh_visible_grid_tiles();
                    });
                    return;
                }
                // Keep keyboard focus on the widget that is actually shown.
                // Tab/search helpers used to target the hidden GridView.
                let had_grid_focus = gallery_for_folder_view.root.has_focus();
                if had_grid_focus {
                    gallery_for_folder_view.folder_root.grab_focus();
                }
                // The Folder model rebuild is synchronous. This timeout runs
                // after that work returns to GTK and paints only the final
                // visible viewport instead of every intermediate bound row.
                let gallery = gallery_for_folder_view.clone();
                glib::timeout_add_local_once(Duration::from_millis(90), move || {
                    gallery.refresh_visible_folder_tiles();
                });
            }
        });
    }

    // Non-Folder GridView (Library, Favourites, Recently Added, Albums,
    // Search) needs the same current-viewport protection as Folder mode. Fast
    // scrollbar motion can otherwise leave hundreds of stale bind requests in
    // front of the final viewport and make thumbnails appear blank until idle.
    const GRID_THUMBNAIL_MOTION_PUMP_FRAMES: u8 = 12;
    let grid_thumbnail_motion_frames = Rc::new(Cell::new(0u8));
    let grid_thumbnail_motion_frames_for_event = grid_thumbnail_motion_frames.clone();
    let grid_thumbnail_motion_frames_for_tick = grid_thumbnail_motion_frames.clone();
    let grid_thumbnail_motion_phase = Rc::new(Cell::new(0u8));
    let grid_thumbnail_motion_phase_for_tick = grid_thumbnail_motion_phase.clone();
    let grid_scroll_direction = Rc::new(Cell::new(0.0_f64));
    let grid_scroll_direction_for_event = grid_scroll_direction.clone();
    let grid_scroll_direction_for_tick = grid_scroll_direction.clone();
    let last_grid_scroll_y = Rc::new(Cell::new(0.0_f64));
    let last_grid_scroll_y_for_event = last_grid_scroll_y.clone();
    // Large adjustment jumps are scrollbar/page teleports. For a few frames
    // after one, do not spend decoder capacity on speculative ahead-prefetch;
    // the newly targeted viewport must become useful first.
    let grid_scrub_frames = Rc::new(Cell::new(0u8));
    let grid_scrub_frames_for_event = grid_scrub_frames.clone();
    let grid_scrub_frames_for_tick = grid_scrub_frames.clone();
    let grid_scrub_generation = Rc::new(Cell::new(0u64));
    let grid_scrub_generation_for_event = grid_scrub_generation.clone();
    let grid_scrub_active = Rc::new(Cell::new(false));
    let grid_scrub_active_for_event = grid_scrub_active.clone();
    let grid_scrub_active_for_tick = grid_scrub_active.clone();
    // GtkAdjustment emits tiny correction events (often -1/0/+1) while the
    // scrollbar thumb is being dragged. Replacing the visible decode queue on
    // every correction cancels almost-finished work and leaves a wall of
    // placeholders. Coalesce scrub destinations so one viewport gets enough
    // time to finish before we replace it with a newer one.
    let grid_scrub_last_queue = Rc::new(RefCell::new(None::<std::time::Instant>));
    let grid_scrub_last_queue_for_event = grid_scrub_last_queue.clone();
    let grid_scrub_latest_value = Rc::new(Cell::new(0.0_f64));
    let grid_scrub_latest_value_for_event = grid_scrub_latest_value.clone();
    let grid_scrub_latest_page = Rc::new(Cell::new(0.0_f64));
    let grid_scrub_latest_page_for_event = grid_scrub_latest_page.clone();

    let gallery_for_group_scroll = gallery.clone();
    grid_scroll
        .vadjustment()
        .connect_value_changed(move |adjustment| {
            let value = adjustment.value();
            let previous = last_grid_scroll_y_for_event.replace(value);
            let delta = value - previous;
            grid_scroll_direction_for_event.set(delta.signum());
            grid_thumbnail_motion_frames_for_event.set(GRID_THUMBNAIL_MOTION_PUMP_FRAMES);

            // A scrollbar scrub can teleport farther than GTK can realize
            // GridView children in the same frame. Queue the destination from
            // the photo model immediately instead of waiting for widget binds.
            // Treat only multi-page motion as the *start* of a direct
            // scrollbar scrub. Once started, every following adjustment belongs
            // to that same drag until the bar has been quiet for 90 ms. This is
            // important because the user's final thumb movement can be much
            // smaller than the first large jump.
            let jump_threshold = (adjustment.page_size() * 1.75).max(900.0);
            if delta.abs() >= jump_threshold {
                grid_scrub_active_for_event.set(true);
                crate::grid::set_grid_scrub_active(true);
            }

            if grid_scrub_active_for_event.get() {
                grid_scrub_frames_for_event.set(6);
                grid_scrub_latest_value_for_event.set(value);
                grid_scrub_latest_page_for_event.set(adjustment.page_size());

                // Do not repeatedly replace the visible queue for GTK's tiny
                // adjustment corrections. At 40 ms the four/eight local-cache
                // workers get several decode slots per scrub sample, while the
                // newest scrollbar position still wins quickly enough to feel
                // live. A final forced sample is queued when the drag settles.
                let now = std::time::Instant::now();
                let should_queue = grid_scrub_last_queue_for_event
                    .borrow()
                    .as_ref()
                    .map(|last| now.duration_since(*last) >= Duration::from_millis(40))
                    .unwrap_or(true);
                if should_queue {
                    *grid_scrub_last_queue_for_event.borrow_mut() = Some(now);
                    gallery_for_group_scroll.queue_grid_scroll_target_cached_tiles_async(
                        value,
                        adjustment.page_size(),
                        192,
                    );
                }

                // End scrub mode only after the adjustment has stayed quiet for
                // a short interval. Old timeout callbacks are ignored by the
                // generation check, so an active drag cannot be ended early.
                let generation = grid_scrub_generation_for_event
                    .get()
                    .wrapping_add(1);
                grid_scrub_generation_for_event.set(generation);
                let generation_cell = grid_scrub_generation_for_event.clone();
                let scrub_active_cell = grid_scrub_active_for_event.clone();
                let last_queue_cell = grid_scrub_last_queue_for_event.clone();
                let latest_value_cell = grid_scrub_latest_value_for_event.clone();
                let latest_page_cell = grid_scrub_latest_page_for_event.clone();
                let gallery = gallery_for_group_scroll.clone();
                glib::timeout_add_local_once(Duration::from_millis(90), move || {
                    if generation_cell.get() != generation {
                        return;
                    }

                    // Force the final destination once more. The user may have
                    // released the thumb less than 40 ms after our last sample.
                    gallery.queue_grid_scroll_target_cached_tiles_async(
                        latest_value_cell.get(),
                        latest_page_cell.get(),
                        192,
                    );
                    *last_queue_cell.borrow_mut() = None;
                    scrub_active_cell.set(false);
                    crate::grid::set_grid_scrub_active(false);
                    gallery.refresh_visible_grid_tiles();
                });

            }


            gallery_for_group_scroll.update_group_header_for_scroll(value);
        });

    let gallery_for_grid_motion_tick = gallery.clone();
    grid_scroll.add_tick_callback(move |_, _| {
        let frames_left = grid_thumbnail_motion_frames_for_tick.get();
        if frames_left == 0 {
            return glib::ControlFlow::Continue;
        }
        grid_thumbnail_motion_frames_for_tick.set(frames_left.saturating_sub(1));

        // During direct scrollbar scrubbing the model-derived target queued by
        // the adjustment callback is authoritative. Do NOT replace it with
        // widget-derived visibility here: GtkGridView may still expose recycled
        // cells from the previous viewport for several frames. Applying the
        // paintables the workers already finished is still required, though:
        // during fast movement a tile binds once, usually before its decode
        // completes, and the completion drain misses tiles that were recycled
        // again before the decode arrived. Re-checking visible tiles against
        // the RAM cache every frame heals exactly those tiles.
        if grid_scrub_active_for_tick.get() {
            gallery_for_grid_motion_tick.apply_visible_grid_cached_paintables();
        } else {
            gallery_for_grid_motion_tick.queue_visible_grid_cached_tiles_async(128);
        }

        let scrub_left = grid_scrub_frames_for_tick.get();
        if scrub_left > 0 {
            grid_scrub_frames_for_tick.set(scrub_left.saturating_sub(1));
        }

        let phase = grid_thumbnail_motion_phase_for_tick.get().wrapping_add(1);
        grid_thumbnail_motion_phase_for_tick.set(phase);
        // During a scrollbar teleport, all decode capacity belongs to the
        // target viewport. Normal directional warming resumes once GTK has had
        // several frames to rebind the destination cells.
        if scrub_left == 0 && phase % 3 == 0 {
            gallery_for_grid_motion_tick
                .prefetch_grid_cached_tiles(32, grid_scroll_direction_for_tick.get());
        }

        glib::ControlFlow::Continue
    });

    let gallery_for_folder_scroll = gallery.clone();
    let latest_folder_scroll_y = Rc::new(Cell::new(0.0_f64));
    // Last scroll direction, used to warm thumbnails ahead of the user rather
    // than both sides equally.
    let folder_scroll_direction = Rc::new(Cell::new(0.0_f64));
    let folder_scroll_direction_for_event = folder_scroll_direction.clone();
    // Thumbnail loading is intentionally debounced until Folder motion stops.
    // GtkListView may rebind thousands of intermediate rows during a scrollbar
    // jump; loading thumbnails from each bind is pure wasted main-thread work.
    let folder_thumbnail_debounce: Rc<RefCell<Option<glib::SourceId>>> =
        Rc::new(RefCell::new(None));
    let folder_thumbnail_debounce_for_event = folder_thumbnail_debounce.clone();
    let folder_thumbnail_prefetch: Rc<RefCell<Option<glib::SourceId>>> =
        Rc::new(RefCell::new(None));
    let folder_thumbnail_prefetch_for_event = folder_thumbnail_prefetch.clone();
    // Coalesces scrub-target sampling: one sample in the jump frame itself,
    // then at most once per 50 ms while the drag continues. Frame-driven from
    // the motion tick below, not from a wall-clock timeout.
    let folder_scrub_sampler = Rc::new(RefCell::new(FolderScrollbarScrub::default()));
    let folder_scrub_sampler_for_event = folder_scrub_sampler.clone();
    let folder_scrub_sampler_for_tick = folder_scrub_sampler.clone();
    let latest_folder_scroll_y_for_tick = latest_folder_scroll_y.clone();
    let folder_vadjustment = folder_scroll.vadjustment();
    // True only for a real multi-page Folder scrollbar scrub. Page Up/Down is
    // deliberately excluded: Folder row bind now submits its own async visible
    // request, so page navigation must not repeatedly replace the queue.
    let folder_direct_scrub_active = Rc::new(Cell::new(false));
    let folder_direct_scrub_active_for_event = folder_direct_scrub_active.clone();
    let folder_direct_scrub_active_for_tick = folder_direct_scrub_active.clone();
    // The settled loader paints the final viewport after motion stops. During
    // active motion, drive thumbnail work from GTK frame ticks instead of a
    // 16 ms timeout. A timeout can run before GtkListView has rebound/allocated
    // the rows for a large scrollbar jump, which warms the old viewport and
    // leaves the new one blank. The short frame pump keeps retrying long enough
    // for recycled rows and async cache decodes to catch up.
    const FOLDER_THUMBNAIL_MOTION_PUMP_FRAMES: u8 = 12;
    let folder_thumbnail_motion_frames = Rc::new(Cell::new(0u8));
    let folder_thumbnail_motion_frames_for_event = folder_thumbnail_motion_frames.clone();
    let folder_thumbnail_motion_frames_for_tick = folder_thumbnail_motion_frames.clone();
    let folder_thumbnail_motion_phase = Rc::new(Cell::new(0u8));
    let folder_thumbnail_motion_phase_for_tick = folder_thumbnail_motion_phase.clone();
    let gallery_for_thumbnail_motion_tick = gallery.clone();
    let folder_scroll_direction_for_tick = folder_scroll_direction.clone();
    folder_scroll.add_tick_callback(move |_, _| {
        let frames_left = folder_thumbnail_motion_frames_for_tick.get();
        if frames_left == 0 {
            return glib::ControlFlow::Continue;
        }
        folder_thumbnail_motion_frames_for_tick.set(frames_left.saturating_sub(1));

        // Always prioritise the tiles actually visible in the frame GTK is
        // about to paint. queue_visible... uses reserved async capacity, so
        // stale prefetch requests cannot starve a scrollbar jump.
        if folder_direct_scrub_active_for_tick.get() {
            // The model-derived scrub target is authoritative while the thumb is
            // teleporting. GtkListView may still expose rows from the previous
            // viewport, so never let those recycled widgets replace the target
            // queue during an active direct scrub. Thumbnails the workers have
            // already finished must still be displayed: rows bind once, usually
            // before their decode completes, and the completion drain misses
            // rows recycled again mid-scrub. Applying RAM hits every frame
            // heals those rows without touching the decode queue.
            gallery_for_thumbnail_motion_tick.apply_visible_folder_cached_paintables();
        } else {
            gallery_for_thumbnail_motion_tick.queue_visible_folder_cached_tiles_async(96);
        }

        // Scrub decode targets are frame-driven: the first sample fires in the
        // jump frame itself (not a wall-clock interval later), then at most
        // every 50 ms while the drag continues. Coalescing keeps the decode
        // queue owned by one destination instead of one per ±1 px anchor
        // correction GtkListView emits during drags.
        let _scrub_target_queued = if folder_direct_scrub_active_for_tick.get()
            && folder_scrub_sampler_for_tick
                .borrow_mut()
                .sample_due(Instant::now())
        {
            let page = folder_vadjustment.page_size().max(1.0);
            gallery_for_thumbnail_motion_tick.queue_folder_scroll_target_cached_tiles_async(
                latest_folder_scroll_y_for_tick.get(),
                page,
                192,
            )
        } else {
            0
        };

        // Warming ahead is useful, but doing the larger offscreen scan on every
        // frame is unnecessary. Run it every third pump frame so visible work
        // remains dominant and GTK has plenty of time to render.
        let phase = folder_thumbnail_motion_phase_for_tick
            .get()
            .wrapping_add(1);
        folder_thumbnail_motion_phase_for_tick.set(phase);
        if !folder_direct_scrub_active_for_tick.get() && phase % 3 == 0 {
            gallery_for_thumbnail_motion_tick.prefetch_folder_cached_tiles(
                24,
                folder_scroll_direction_for_tick.get(),
            );
        }

        glib::ControlFlow::Continue
    });

    folder_scroll
        .vadjustment()
        .connect_value_changed(move |adjustment| {
            let raw_scroll_y = adjustment.value();
            // GtkListView keeps its scroll anchor on device-pixel boundaries
            // (same reason the wheel path quantizes in
            // install_smooth_gallery_scroll). Fractional scrollbar-drag values
            // make GTK immediately write a rounded value back, which reads as
            // a tiny bounce at drag end. Snap to whole pixels instead; the
            // re-entrant value_changed sees an integral value and no-ops.
            let scroll_y = raw_scroll_y.round();
            if scroll_y != raw_scroll_y {
                adjustment.set_value(scroll_y);
            }
            let previous_y = latest_folder_scroll_y.replace(scroll_y);
            let direction = scroll_y - previous_y;
            if direction != 0.0 {
                folder_scroll_direction_for_event.set(direction);
            }

            // Folder bind now submits its own visible-priority async request on
            // every RAM miss. That is sufficient for wheel motion and Page
            // Up/Down, and avoids the old failure mode where each ~one-page
            // adjustment step replaced another 30-60 useful requests.
            //
            // Only true multi-page scrollbar teleports use model-derived target
            // preloading. Coalesce those samples so workers can finish useful
            // work instead of decoding every intermediate thumb position.
            let page_size = adjustment.page_size().max(1.0);
            let direct_scrub = direction.abs() > page_size * 1.60;
            if direct_scrub {
                folder_direct_scrub_active_for_event.set(true);
                // Folder and grid views are never visible at the same time,
                // so reuse the shared scrub thread-local: it keeps recycled
                // folder tiles from being blanked at unbind while rows are
                // rebound faster than thumbnail decodes can land. The folder
                // settle callback clears it again.
                crate::grid::set_grid_scrub_active(true);
                // First target sample fires in the next frame tick; further
                // samples are coalesced to one per 50 ms by the sampler.
                folder_scrub_sampler_for_event.borrow_mut().begin();
            }

            // Keep only the cheap position bookkeeping in the raw adjustment
            // callback. Widget picking and sidebar work are throttled below so
            // wheel/touchpad/scrollbar motion cannot spend a frame walking GTK
            // widgets merely to update a visual location marker.
            gallery_for_folder_scroll.update_group_header_for_scroll(scroll_y);

            // Cancel the previous settle callback and arm a new one. Only the
            // final viewport after ~90 ms of idle motion gets a full visible
            // refresh. During sustained scrolling, separately warm a tiny
            // budgeted batch so the viewport does not remain blank until the
            // user fully stops.
            if let Some(source) = folder_thumbnail_debounce_for_event.borrow_mut().take() {
                source.remove();
            }
            if let Some(source) = folder_thumbnail_prefetch_for_event.borrow_mut().take() {
                source.remove();
            }
            // Keep a frame-synchronised thumbnail pump alive after every
            // movement. Re-arming it is cheap and covers wheel/touchpad motion,
            // kinetic scrolling, and direct scrollbar jumps with the same path.
            // The pump runs after GtkListView has had frame opportunities to
            // recycle/rebind rows, so it follows the new viewport instead of a
            // stale one captured by a wall-clock timeout.
            folder_thumbnail_motion_frames_for_event
                .set(FOLDER_THUMBNAIL_MOTION_PUMP_FRAMES);
            let gallery_for_visible = gallery_for_folder_scroll.clone();
            let debounce_slot = folder_thumbnail_debounce_for_event.clone();
            let prefetch_slot = folder_thumbnail_prefetch_for_event.clone();
            let direction_for_settle = folder_scroll_direction_for_event.get();
            let final_scroll_y = latest_folder_scroll_y.clone();
            let final_page_size = adjustment.page_size().max(1.0);
            let direct_scrub_active_for_settle = folder_direct_scrub_active_for_event.clone();
            let folder_scrub_sampler_for_settle = folder_scrub_sampler_for_event.clone();
            let source = glib::timeout_add_local(Duration::from_millis(110), move || {
                debounce_slot.borrow_mut().take();
                direct_scrub_active_for_settle.set(false);
                folder_scrub_sampler_for_settle.borrow_mut().end();
                // End the shared scrub window before the visible refresh so
                // tiles that never received their thumbnail drop the stale
                // backstop image and return to the normal placeholder state.
                crate::grid::set_grid_scrub_active(false);
                gallery_for_visible.queue_folder_scroll_target_cached_tiles_async(
                    final_scroll_y.get(),
                    final_page_size,
                    192,
                );
                // Defer the visible refresh to the next main-loop pass so GTK
                // can finish this frame's post-jump anchor/allocation work
                // before tiles drop their stale backstop paintables. Unloading
                // in the same callback interleaves with the ListView's row
                // re-positioning and reads as a small bounce at drag end.
                // Queueing decodes stays inline; it does not touch widgets.
                let gallery_for_settle_refresh = gallery_for_visible.clone();
                glib::timeout_add_local_once(Duration::ZERO, move || {
                    gallery_for_settle_refresh.refresh_visible_folder_tiles();
                });

                // GtkListView can realize the last destination row a few frames
                // *after* the settle callback above. Give those newly-created
                // tiles a short visible-only catch-up window before spending
                // worker capacity on speculative ahead/behind prefetch. This is
                // deliberately additive: it never replaces queued visible work.
                let gallery_for_prefetch = gallery_for_visible.clone();
                let prefetch_slot_for_tick = prefetch_slot.clone();
                let catchup_frames = Rc::new(Cell::new(6u8));
                let catchup_frames_for_tick = catchup_frames.clone();
                let prefetch_source = glib::timeout_add_local(
                    Duration::from_millis(16),
                    move || {
                        let frames_left = catchup_frames_for_tick.get();
                        if frames_left > 0 {
                            gallery_for_prefetch.refresh_visible_folder_tiles();
                            catchup_frames_for_tick.set(frames_left - 1);
                            return glib::ControlFlow::Continue;
                        }

                        let loaded =
                            gallery_for_prefetch.prefetch_folder_cached_tiles(24, direction_for_settle);
                        if loaded == 0 && !gallery_for_prefetch.thumbnail_display_work_pending() {
                            prefetch_slot_for_tick.borrow_mut().take();
                            glib::ControlFlow::Break
                        } else {
                            glib::ControlFlow::Continue
                        }
                    },
                );
                prefetch_slot.replace(Some(prefetch_source));
                glib::ControlFlow::Break
            });
            folder_thumbnail_debounce_for_event.replace(Some(source));

        });

    

    install_smooth_gallery_scroll(&grid_scroll, gallery.clone(), true);
    // Folder mode uses a variable-height GtkListView. Use relative wheel
    // easing rather than an absolute spring target so GTK anchor corrections
    // cannot pull the viewport backwards. Precision touchpads remain native.
    install_folder_smooth_gallery_scroll(&folder_scroll, gallery.clone());

    // While the sidebar divider is being dragged, keep the gallery column
    // count fixed. Otherwise every few pixels can cross a column threshold
    // and repeatedly rebuild visible rows. Apply the final width once after
    // the drag ends.
    let sidebar_resize_active = Rc::new(Cell::new(false));
    // Temporary hover-autohide is presentation only. While that overlay is
    // sliding in or out, keep the gallery's logical width/column model frozen
    // so Folder mode does not rebuild rows just because the pointer touched
    // the left edge. Pin/unpin remains a real layout change and uses the settle
    // gate below to perform one final responsive update after the animation.
    let sidebar_hover_layout_freeze = Rc::new(Cell::new(false));
    // Generation protects against a delayed hide callback unfreezing a newer
    // hover reveal when the pointer returns to the edge very quickly.
    let sidebar_hover_freeze_generation = Rc::new(Cell::new(0u64));
    let sidebar_layout_settle = Rc::new(RefCell::new(WidthSettleGate::new(3)));
    let gallery_for_resize = gallery.clone();
    let sidebar_resize_active_for_tick = sidebar_resize_active.clone();
    let sidebar_hover_layout_freeze_for_tick = sidebar_hover_layout_freeze.clone();
    let sidebar_layout_settle_for_tick = sidebar_layout_settle.clone();
    gallery_scroll_stack.add_tick_callback(move |surface, _clock| {
        gallery_for_resize.drain_thumbnail_display_completions();
        let sectioned_live_resize = gallery_for_resize.using_sectioned_folder_view()
            && sidebar_resize_active_for_tick.get()
            && !sidebar_hover_layout_freeze_for_tick.get();
        if sectioned_live_resize
            || should_observe_width(
                sidebar_resize_active_for_tick.get(),
                sidebar_hover_layout_freeze_for_tick.get(),
            )
        {
            let width = surface.width();
            if width > 100 {
                if gallery_for_resize.using_sectioned_folder_view() {
                    // Sectioned Folder mode only recomputes lightweight geometry;
                    // it never rebuilds photo membership or row objects.
                    gallery_for_resize.update_width(width);
                } else if crate::grid::folder_gridview_experiment_enabled() {
                    // Gallery v2 has no column-sized Folder row model to
                    // rebuild, so react immediately when the window crosses a
                    // column boundary. Delaying until the width settles leaves
                    // GridView's previous min-column request active while the
                    // window is dragged smaller, causing repeated
                    // GtkOverlay/Adwaita minimum-width negotiation.
                    gallery_for_resize.update_width_with_flip(width);
                } else if sidebar_layout_settle_for_tick
                    .borrow_mut()
                    .observe(width)
                {
                    // Legacy Folder ListView still benefits from coalescing
                    // because a column change rebuilds its row model.
                    gallery_for_resize.update_width(width);
                }
            }
        }
        glib::ControlFlow::Continue
    });

    let grid_surface = gtk::Box::new(gtk::Orientation::Vertical, 0);
    grid_surface.set_hexpand(true);
    grid_surface.set_vexpand(true);
    grid_surface.add_css_class("photo-grid");
    // Date grouping keeps its existing heading. Folder grouping hides this
    // widget and renders its headers inside the folder scroller instead.
    grid_surface.append(&gallery.group_header);
    grid_surface.append(&gallery_scroll_stack);

    let grid_overlay = gtk::Overlay::new();
    grid_overlay.set_hexpand(true);
    grid_overlay.set_vexpand(true);
    grid_overlay.set_child(Some(&grid_surface));
    grid_overlay.add_overlay(&scrub_date_label);

    // The context menu is a normal GtkOverlay child, so give it the
    // autohide behaviour GtkPopover used to provide. Any pointer press
    // outside the active menu dismisses it. Presses on menu buttons are
    // left alone so their normal clicked handlers still run.
    let context_menu_autohide = gtk::GestureClick::new();
    context_menu_autohide.set_button(0);
    context_menu_autohide.set_propagation_phase(gtk::PropagationPhase::Capture);
    let window_for_menu_autohide = window.clone();
    let lightbox_for_menu_autohide = lightbox.clone();
    context_menu_autohide.connect_pressed(move |_, _, x, y| {
        let inside_menu = window_for_menu_autohide
            .pick(x, y, gtk::PickFlags::DEFAULT)
            .is_some_and(|picked| photo_context_menu_contains(&picked));
        if !inside_menu && dismiss_active_photo_context_menu() {
            let root = lightbox_for_menu_autohide.root.clone();
            glib::idle_add_local_once(move || {
                if root.is_visible() {
                    root.grab_focus();
                }
            });
        }
    });
    window.add_controller(context_menu_autohide);

    let photo_page = gtk::Box::new(gtk::Orientation::Vertical, 0);
    photo_page.set_hexpand(true);
    photo_page.set_vexpand(true);
    photo_page.append(&grid_overlay);

    let album_theme_changed: Rc<dyn Fn()> = {
        let connection = connection.clone();
        let refresh_slot = albums_home_refresh_slot.clone();
        let sidebar_slot = sidebar_for_unavailable.clone();
        let on_delete_album = delete_album.clone();
        Rc::new(move || {
            let albums = db::albums(&connection.borrow()).unwrap_or_default();
            if let Some(sidebar) = sidebar_slot.borrow().as_ref() {
                sidebar::refresh_album_rows(sidebar, &albums, &on_delete_album);
            }
            if let Some(refresh) = refresh_slot.borrow().as_ref() {
                refresh(&albums);
            }
        })
    };
    // Clone for the theme engine: the original is captured by the layout.rs
    // include below.
    let theme_post_apply = album_theme_changed.clone();
    let albums_home = albums_view::build(
        if initial_filter == sidebar::SidebarFilter::Library {
            &[]
        } else {
            &albums
        },
        connection.clone(),
        grid_thumbnail_size,
        {
            let slot = album_home_click_slot.clone();
            Rc::new(move |album_id| {
                if let Some(open) = slot.borrow().as_ref() {
                    open(album_id);
                }
            })
        },
        album_theme_changed.clone(),
        {
            let present_settings = present_settings.clone();
            Rc::new(move || present_settings(Some("themes")))
        },
    );
    // Albums home is a separate ScrolledWindow, so it needs the same wheel
    // easing as the photo views. Ctrl+wheel must not zoom the hidden gallery.
    install_smooth_gallery_scroll(&albums_home, gallery.clone(), false);
    albums_view::connect_create_album(&albums_home, create_album.clone());
    let main_stack = gtk::Stack::new();
    main_stack.set_hexpand(true);
    main_stack.set_vexpand(true);
    main_stack.add_named(&photo_page, Some("photos"));
    main_stack.add_named(&albums_home, Some("albums"));
    let collage_page = gtk::Box::new(gtk::Orientation::Vertical, 0);
    collage_page.set_hexpand(true);
    collage_page.set_vexpand(true);
    main_stack.add_named(&collage_page, Some("collage"));
    let edit_page = gtk::Box::new(gtk::Orientation::Vertical, 0);
    edit_page.set_hexpand(true);
    edit_page.set_vexpand(true);
    main_stack.add_named(&edit_page, Some("edit"));
    let library_home = crate::library_home::LibraryHome::new(
        db::active_database_path().expect("The library database is already open"),
        {
            let slot = library_navigation_slot.clone();
            Rc::new(move |destination| {
                if let Some(navigate) = slot.borrow().as_ref() {
                    navigate(destination);
                }
            })
        },
        {
            let lightbox = lightbox.clone();
            let connection = connection.clone();
            let open_edit = open_edit.clone();
            let open_collage = open_collage.clone();
            Rc::new(move |photos, index, edited| {
                let Some(photo) = photos.get(index) else {
                    return;
                };
                if edited {
                    let collage = db::collage_project(&connection.borrow(), photo.id())
                        .ok()
                        .flatten()
                        .is_some();
                    if collage {
                        open_collage(vec![photo.id()]);
                    } else {
                        open_edit(photo.id());
                    }
                } else {
                    lightbox.open(photos, index);
                }
            })
        },
    );
    main_stack.add_named(&library_home.root, Some("library"));
    main_stack.set_visible_child_name(if initial_filter == sidebar::SidebarFilter::Library {
        "library"
    } else if initial_filter == sidebar::SidebarFilter::Albums {
        "albums"
    } else {
        "photos"
    });
    // The shared viewer and its menus can cover either the gallery or Home.
    let page_overlay = gtk::Overlay::new();
    page_overlay.set_child(Some(&main_stack));
    page_overlay.add_overlay(&lightbox.root);
    context_menu_host.borrow_mut().replace(page_overlay.downgrade());
    content.append(&page_overlay);
    content.append(&info.root);
    {
        let filter = filter.clone();
        let search_text = search_text.clone();
        let collage_add_mode = collage_add_mode.clone();
        let lightbox = lightbox.clone();
        main_stack.connect_visible_child_notify(move |stack| {
            if !matches!(stack.visible_child_name().as_deref(), Some("photos" | "library")) {
                lightbox.close();
            }
            if filter.get() == sidebar::SidebarFilter::Library
                && search_text.borrow().is_empty()
                && !collage_add_mode.get()
                && stack.visible_child_name().as_deref() == Some("photos")
            {
                stack.set_visible_child_name("library");
            }
        });
    }

    let collage_editor: Rc<RefCell<Option<crate::collage::CollageEditor>>> =
        Rc::new(RefCell::new(None));
    {
        let parent = window.clone().upcast::<gtk::Window>();
        let connection = connection.clone();
        let main_stack = main_stack.clone();
        let collage_page = collage_page.clone();
        let collage_editor = collage_editor.clone();
        let collage_add_mode_slot = collage_add_mode_slot.clone();
        let collage_close_slot = collage_close_slot.clone();
        let collage_add_mode = collage_add_mode.clone();
        // Opens the photo editor while marking the trip as collage-owned so
        // the collage editor survives and Back/Done return to the collage.
        let open_edit_from_collage = {
            let open_edit = open_edit.clone();
            let collage_editing = collage_editing.clone();
            Rc::new(move |id: i64| {
                collage_editing.set(true);
                open_edit(id);
            }) as Rc<dyn Fn(i64)>
        };
        collage_open_slot.replace(Some(Rc::new(move |ids| {
            let add_mode_slot = collage_add_mode_slot.clone();
            let close_slot = collage_close_slot.clone();
            let collage_add_mode = collage_add_mode.clone();
            crate::collage::open(
                &parent,
                connection.clone(),
                ids,
                Rc::new({
                    let parent = parent.clone();
                    let main_stack = main_stack.clone();
                    let collage_page = collage_page.clone();
                    let collage_editor = collage_editor.clone();
                    let collage_add_mode = collage_add_mode.clone();
                    let open_edit_from_collage = open_edit_from_collage.clone();
                    move |photos, draft| {
                        while let Some(child) = collage_page.first_child() {
                            collage_page.remove(&child);
                        }
                        // A fresh editor starts with no add-photos detour
                        // pending; clear any stale picking state so leaving
                        // the collage page tears it down normally.
                        collage_add_mode.set(false);
                        let add_photos = {
                            let slot = add_mode_slot.clone();
                            Rc::new(move || {
                                if let Some(add_mode) = slot.borrow().as_ref() {
                                    add_mode();
                                }
                            }) as Rc<dyn Fn()>
                        };
                        let close = {
                            let slot = close_slot.clone();
                            Rc::new(move || {
                                if let Some(close) = slot.borrow().as_ref() {
                                    close();
                                }
                            }) as Rc<dyn Fn()>
                        };
                        let editor = crate::collage::build_editor(
                            &parent,
                            photos,
                            add_photos,
                            close,
                            draft,
                            open_edit_from_collage.clone(),
                        );
                        collage_page.append(&editor.root);
                        collage_editor.replace(Some(editor));
                        main_stack.set_visible_child_name("collage");
                    }
                }),
            );
        })));
    }

    let edit_editor: Rc<RefCell<Option<crate::edit::EditEditor>>> = Rc::new(RefCell::new(None));
    // Catch-all teardown when the collage/edit pages are left by any path
    // (sidebar navigation, search, opening the editor mid-collage, ...).
    // GtkStack reports the maximum minimum size of all its pages, hidden
    // ones included, so an editor left attached keeps demanding its tall
    // minimum and pushes the shared bottom bar offscreen on short windows.
    // The Exit/Done handlers tear down directly; this runs idempotently for
    // every other transition. The collage editor survives transitions to
    // the photos page while the user is picking images to add.
    {
        let main_stack_for_teardown = main_stack.clone();
        let collage_page = collage_page.clone();
        let collage_editor = collage_editor.clone();
        let edit_page = edit_page.clone();
        let edit_editor = edit_editor.clone();
        let collage_add_mode = collage_add_mode.clone();
        let collage_editing = collage_editing.clone();
        let gallery = gallery.clone();
        let connection_for_teardown = connection.clone();
        let filter_for_history = filter.clone();
        let search_for_history = search_text.clone();
        let sort_for_history = sort.clone();
        main_stack_for_teardown.connect_visible_child_notify(move |stack| {
            let visible = stack.visible_child_name();
            if visible.as_deref() == Some("photos")
                && filter_for_history.get() == sidebar::SidebarFilter::History
            {
                refresh_grid(
                    &connection_for_teardown,
                    filter_for_history.get(),
                    &search_for_history.borrow(),
                    sort_for_history.get(),
                    &gallery,
                );
            }
            if visible.as_deref() != Some("collage")
                && !collage_add_mode.get()
                && !collage_editing.get()
            {
                // try_borrow: the add-photos handler holds the editor borrow
                // while switching pages; skip rather than panic.
                if collage_editor.try_borrow().map(|editor| editor.is_some()).unwrap_or(false) {
                    // Persist the draft on every path out of the editor.
                    if let Ok(editor_handle) = collage_editor.try_borrow() {
                        if let Some(editor) = editor_handle.as_ref() {
                            let json = editor.draft_json();
                            let guard = connection_for_teardown.borrow();
                            let _ =
                                db::set_setting(&guard, crate::collage::DRAFT_SETTING_KEY, &json);
                        }
                    }
                    // Clear the grid selection so the next toolbar collage
                    // click is a blank start and can offer the resume prompt.
                    gallery.set_selected_photo_ids(&[]);
                    while let Some(child) = collage_page.first_child() {
                        collage_page.remove(&child);
                    }
                    collage_editor.replace(None);
                }
            }
            if visible.as_deref() != Some("edit")
                && edit_editor.try_borrow().map(|editor| editor.is_some()).unwrap_or(false)
            {
                // Any exit from the photo editor ends the collage detour.
                collage_editing.set(false);
                while let Some(child) = edit_page.first_child() {
                    edit_page.remove(&child);
                }
                edit_editor.replace(None);
            }
        });
    }
    {
        let parent = window.clone().upcast::<gtk::Window>();
        let connection = connection.clone();
        let main_stack = main_stack.clone();
        let edit_page = edit_page.clone();
        let edit_editor = edit_editor.clone();
        let gallery = gallery.clone();
        let selected_photo = selected_photo.clone();
        let info = info.clone();
        let lightbox = lightbox.clone();
        let edit_space_slot = edit_space_slot.clone();
        let collage_editing = collage_editing.clone();
        let collage_editor = collage_editor.clone();
        // Keep the shared slider synchronization handle available to the rest
        // of build.rs. The editor-open move closure owns only this cheap clone.
        let grid_zoom_syncing_for_editor = grid_zoom_syncing.clone();
        // Edit-mode Export uses the exact same dialog → destination → progress
        // pipeline as the info-bar Export button (size + file type + Stop bar).
        let export_for_editor: Rc<dyn Fn(Vec<crate::edit::export_batch::ExportJob>)> = {
            let window = window.clone().upcast::<gtk::Window>();
            let progress = operation_progress.clone();
            Rc::new(move |jobs| {
                if jobs.is_empty() {
                    return;
                }
                show_photo_export_dialog(&window, jobs, progress.clone());
            })
        };
        edit_open_slot.replace(Some(Rc::new(move |id| {
            let Some(db_photo) = db::photo(&connection.borrow(), id).ok().flatten() else {
                // The open failed; drop any pending collage-edit marker so
                // the flag cannot get stuck and spare the collage forever.
                collage_editing.set(false);
                return;
            };
            edit_space_slot.borrow_mut().take();
            lightbox.close();
            let library_scroll_y = gallery.scroll_position();
            while let Some(child) = edit_page.first_child() {
                edit_page.remove(&child);
            }
            let photo = crate::photo_object::PhotoObject::from_photo(&db_photo);
            info.one_to_one.set_active(false);
            let close = {
                let main_stack = main_stack.clone();
                let one_to_one = info.one_to_one.clone();
                let info = info.clone();
                let grid_zoom_syncing = grid_zoom_syncing_for_editor.clone();
                let gallery = gallery.clone();
                let edit_space_slot = edit_space_slot.clone();
                let edit_page = edit_page.clone();
                let edit_editor = edit_editor.clone();
                let collage_editing = collage_editing.clone();
                let collage_editor = collage_editor.clone();
                let connection = connection.clone();
                Rc::new(move || {
                    edit_space_slot.borrow_mut().take();
                    one_to_one.set_active(false);
                    let returning_to_collage = collage_editing.get();
                    if returning_to_collage {
                        // Bring the collage tile up to date with any edits
                        // saved during this detour.
                        if let Ok(editor_handle) = collage_editor.try_borrow() {
                            if let Some(collage) = editor_handle.as_ref() {
                                if let Some(updated) =
                                    db::photo(&connection.borrow(), id).ok().flatten()
                                {
                                    collage.refresh_photo_metadata(&[
                                        crate::photo_object::PhotoObject::from_photo(&updated),
                                    ]);
                                }
                            }
                        }
                        main_stack.set_visible_child_name("collage");
                    } else {
                        main_stack.set_visible_child_name("photos");
                        grid_zoom_syncing.set(true);
                        info.grid_zoom.set_range(0.0, 7.0);
                        info.grid_zoom.set_increments(1.0, 1.0);
                        info.grid_zoom.set_round_digits(0);
                        info.grid_zoom.clear_marks();
                        info.grid_zoom.add_mark(3.5, gtk::PositionType::Top, None);
                        info.grid_zoom.add_mark(3.5, gtk::PositionType::Bottom, None);
                        info.grid_zoom.set_value(grid_zoom_slider_value(
                            gallery.current_zoom_width(),
                        ));
                        info.grid_zoom
                            .set_tooltip_text(Some("Thumbnail size (Ctrl + wheel)"));
                        grid_zoom_syncing.set(false);
                        gallery.restore_view(id, library_scroll_y);
                    }
                    // Detach the editor so it stops contributing to the
                    // stack's size request and its preview memory is
                    // released; the editor is rebuilt on the next open.
                    while let Some(child) = edit_page.first_child() {
                        edit_page.remove(&child);
                    }
                    edit_editor.replace(None);
                }) as Rc<dyn Fn()>
            };
            let saved = {
                let gallery = gallery.clone();
                let selected_photo = selected_photo.clone();
                let info = info.clone();
                Rc::new(move |photo: crate::photo_object::PhotoObject| {
                    gallery.update_edit_recipe(photo.id(), &photo.edit_recipe());
                    selected_photo.replace(Some(photo.clone()));
                    info.set_photo(Some(&photo));
                }) as Rc<dyn Fn(crate::photo_object::PhotoObject)>
            };
            let editor = crate::edit::build_editor(
                &parent,
                connection.clone(),
                photo,
                close,
                saved,
                export_for_editor.clone(),
            );
            {
                let one_to_one = info.one_to_one.clone();
                editor.set_one_to_one_sync_handler(move |enabled| {
                    one_to_one.set_active(enabled);
                });
            }
            {
                let zoom_scale = info.grid_zoom.clone();
                let syncing = grid_zoom_syncing_for_editor.clone();
                let stack = main_stack.clone();
                editor.set_zoom_sync_handler(move |native_scale, fit_scale| {
                    if stack.visible_child_name().as_deref() != Some("edit") {
                        return;
                    }
                    let value = lightbox_slider_from_scale(native_scale, fit_scale);
                    syncing.set(true);
                    zoom_scale.set_value(value);
                    syncing.set(false);
                });
            }
            {
                let fit_scale = editor.current_fit_scale();
                let native_scale = editor.current_manual_zoom_scale();
                grid_zoom_syncing_for_editor.set(true);
                info.grid_zoom.set_range(0.0, 100.0);
                info.grid_zoom.set_increments(0.25, 5.0);
                info.grid_zoom.set_round_digits(-1);
                info.grid_zoom.clear_marks();
                info.grid_zoom.add_mark(50.0, gtk::PositionType::Top, None);
                info.grid_zoom.add_mark(50.0, gtk::PositionType::Bottom, None);
                info.grid_zoom
                    .set_value(lightbox_slider_from_scale(native_scale, fit_scale));
                info.grid_zoom.set_tooltip_text(Some(
                    "Edit zoom — left: Fit, middle: 100%, right: 200%",
                ));
                grid_zoom_syncing_for_editor.set(false);
            }
            // Make the way back explicit when the editor was opened from a
            // collage tile; Done saves and follows the same return path.
            if collage_editing.get() {
                editor.set_back_label("Back to Collage", "Return to the collage");
            }
            edit_page.append(&editor.root);
            {
                let text_toggle = editor.text_toggle_handle();
                edit_editor.replace(Some(editor));
                let main_stack = main_stack.clone();
                let one_to_one = info.one_to_one.clone();
                let edit_space_slot = edit_space_slot.clone();
                edit_space_slot.replace(Some(Rc::new(move || {
                    if main_stack.visible_child_name().as_deref() != Some("edit") {
                        // Editor left via the Edit toggle (slot not cleared);
                        // let Space fall through to lightbox/grid open.
                        return false;
                    }
                    if !text_toggle.is_active() {
                        one_to_one.set_active(!one_to_one.is_active());
                    }
                    true
                }) as Rc<dyn Fn() -> bool>));
            }
            main_stack.set_visible_child_name("edit");
        })));
    }

    let selected_for_favorite = selected_photo.clone();
    let db_for_favorite = connection.clone();
    let info_favorite = info.clone();
    let gallery_for_favorite = gallery.clone();
    let filter_for_favorite = filter.clone();
    let lightbox_for_favorite = lightbox.clone();
    let sidebar_refresh_for_favorite = availability_refresh.clone();
    let sidebar_for_favorite = sidebar_for_unavailable.clone();

    info.favorite.connect_clicked(move |_| {
        let Some(photo) = selected_for_favorite.borrow().clone() else {
            return;
        };
        let favorite = !photo.favorite();

        if let Err(error) = db::set_favorite(&db_for_favorite.borrow(), photo.id(), favorite) {
            eprintln!("Could not update favourite: {error}");
            return;
        }
        photo.set_favorite(favorite);
        if filter_for_favorite.get() == sidebar::SidebarFilter::Favorites && !favorite {
            gallery_for_favorite.remove_photos(&[photo.id()]);
            if lightbox_for_favorite.root.is_visible() {
                lightbox_for_favorite.remove_photo(photo.id());
            }
        } else {
            gallery_for_favorite.update_favorites(&[photo.id()], favorite);
            info_favorite.set_photo(Some(&photo));
        }
        if let Some(sidebar) = sidebar_for_favorite.borrow().as_ref().cloned() {
            if let Ok(counts) = db::sidebar_counts(&db_for_favorite.borrow()) {
                sidebar::refresh_library_counts(
                    &sidebar,
                    counts,
                    &sidebar_refresh_for_favorite,
                );
            }
        }
        
    });

    for (index, button) in info.rating_buttons.iter().enumerate() {
        let selected_for_rating = selected_photo.clone();
        let db_for_rating = connection.clone();
        let info_for_rating = info.clone();
        let gallery_for_rating = gallery.clone();
        let sort_for_rating = sort.clone();
        let rating_filter_for_rating = rating_filter.clone();
        let filter_for_rating = filter.clone();
        let search_for_rating = search_text.clone();
        let rating = (index + 1) as i32;
        button.connect_clicked(move |_| {
            let Some(photo) = selected_for_rating.borrow().clone() else {
                return;
            };
            let ids = gallery_for_rating.selected_photo_ids(Some(photo.id()));
            let target = if photo.rating() == rating { 0 } else { rating };
            if let Err(error) =
                db::set_rating_for_photos(&db_for_rating.borrow(), &ids, target)
            {
                eprintln!("Could not update rating: {error}");
                return;
            }
            gallery_for_rating.update_ratings(&ids, target);
            photo.set_rating(target);
            info_for_rating.set_photo(Some(&photo));

            // Rebuild only when this edit can change visible membership or
            // ordering. Otherwise rating remains a cheap in-place badge update.
            if rating_filter_for_rating.get() != RatingFilter::All
                || sort_for_rating.get().field == SortField::Rating
            {
                refresh_grid(
                    &db_for_rating,
                    filter_for_rating.get(),
                    &search_for_rating.borrow(),
                    sort_for_rating.get(),
                    &gallery_for_rating,
                );
            }
            if std::env::var_os("PICASA_TRACE").is_some() {
                eprintln!("UI TRACE photo_rating_changed id={} rating={}", photo.id(), target);
            }
        });
    }

    let lightbox_for_one_to_one = lightbox.clone();
    {
        // Keep the toolbar 1:1 toggle in sync when the lightbox changes mode
        // itself (e.g. Ctrl+wheel leaves 1:1 for a manual zoom).
        let one_to_one_button = info.one_to_one.clone();
        lightbox.set_one_to_one_sync_handler(move |enabled| {
            one_to_one_button.set_active(enabled);
        });
    }
    let edit_editor_for_one_to_one = edit_editor.clone();
    let main_stack_for_one_to_one = main_stack.clone();
    let space_toggle_in_progress_for_toggle = space_toggle_in_progress.clone();
    let space_open_slot_for_one_to_one = space_open_slot.clone();
    info.one_to_one.connect_toggled(move |button| {
        let enabled = button.is_active();
        if main_stack_for_one_to_one.visible_child_name().as_deref() == Some("edit") {
            if let Some(editor) = edit_editor_for_one_to_one.borrow().as_ref() {
                editor.set_one_to_one(enabled);
            }
        } else if enabled && !lightbox_for_one_to_one.root.is_visible() {
            if let Some(open_selected) = space_open_slot_for_one_to_one.borrow().as_ref() {
                open_selected();
            }
            let lightbox = lightbox_for_one_to_one.clone();
            glib::idle_add_local_once(move || {
                if lightbox.root.is_visible() {
                    lightbox.set_one_to_one(true);
                    lightbox.root.grab_focus();
                }
            });
        } else {
            lightbox_for_one_to_one.set_one_to_one(enabled);
        }
        if space_toggle_in_progress_for_toggle.get() {
            space_toggle_in_progress_for_toggle.set(false);
        }
    });

    // Keep the UI state reset when the lightbox is closed through any path.
    // Restore the current photo into the shared gallery selection and focus the
    // view that is actually visible (GridView normally, Folder ListView while
    // browsing the continuous Picasa-style Folder stream).
    let one_to_one_for_visibility = info.one_to_one.clone();
    let gallery_for_lightbox_close = gallery.clone();
    let selected_photo_for_lightbox_close = selected_photo.clone();
    lightbox.root.connect_visible_notify(move |root| {
        if root.is_visible() {
            // A previous Lightbox return may still be easing the Folder view.
            // Once the viewer opens, freeze the hidden gallery exactly where it
            // is so no stale scroll callback can keep moving it underneath us.
            gallery_for_lightbox_close.cancel_sectioned_folder_scroll_animation();
            return;
        }

        one_to_one_for_visibility.set_active(false);

        let gallery = gallery_for_lightbox_close.clone();
        let selected_photo = selected_photo_for_lightbox_close.borrow().clone();
        glib::idle_add_local_once(move || {
            if let Some(photo) = selected_photo {
                gallery.restore_activated_photo(photo.id());
            }
            gallery.grab_focus();
        });
    });

    fn lightbox_scale_from_slider(value: f64, fit_scale: f64) -> f64 {
        let value = value.clamp(0.0, 100.0);
        if value <= 0.0 {
            return 0.0;
        }

        let fit_scale = fit_scale.clamp(f64::EPSILON, 1.0);
        if fit_scale >= 0.999 {
            // Fit and 1:1 are the same visual state. Do not waste half the
            // physical slider on a dead Fit->100% range.
            return 1.0
                + (crate::lightbox::LIGHTBOX_MAX_ZOOM_FACTOR - 1.0) * (value / 100.0);
        }

        if value <= 50.0 {
            fit_scale + (1.0 - fit_scale) * (value / 50.0)
        } else {
            1.0
                + (crate::lightbox::LIGHTBOX_MAX_ZOOM_FACTOR - 1.0)
                    * ((value - 50.0) / 50.0)
        }
    }

    fn lightbox_slider_from_scale(scale: f64, fit_scale: f64) -> f64 {
        if scale <= 0.0 {
            return 0.0;
        }

        let fit_scale = fit_scale.clamp(f64::EPSILON, 1.0);
        if fit_scale >= 0.999 {
            return 100.0
                * ((scale - 1.0)
                    / (crate::lightbox::LIGHTBOX_MAX_ZOOM_FACTOR - 1.0))
                    .clamp(0.0, 1.0);
        }

        if scale <= 1.0 {
            50.0 * ((scale - fit_scale) / (1.0 - fit_scale)).clamp(0.0, 1.0)
        } else {
            50.0
                + 50.0
                    * ((scale - 1.0)
                        / (crate::lightbox::LIGHTBOX_MAX_ZOOM_FACTOR - 1.0))
                        .clamp(0.0, 1.0)
        }
    }

    let gallery_for_zoom_slider = gallery.clone();
    let lightbox_for_zoom_slider = lightbox.clone();
    let edit_editor_for_zoom_slider = edit_editor.clone();
    let main_stack_for_zoom_slider = main_stack.clone();
    let grid_zoom_syncing_for_slider = grid_zoom_syncing.clone();
    let slider_last_value = Rc::new(Cell::new(info.grid_zoom.value()));
    let slider_last_value_for_change = slider_last_value.clone();
    // Lightbox slider drags can emit many value changes inside one display
    // frame. Applying every one forces GtkPicture + GtkScrolledWindow to
    // renegotiate geometry and recenter their adjustments repeatedly, which
    // becomes visible as shaking once the image overflows the viewport.
    //
    // Apply the first movement immediately for direct response, then keep only
    // the newest absolute slider value and publish at most once per ~60 Hz
    // frame. This is throttling, not a trailing debounce: the control remains
    // live under the pointer and never waits hundreds of milliseconds.
    let lightbox_slider_latest = Rc::new(Cell::new(info.grid_zoom.value()));
    let lightbox_slider_applied = Rc::new(Cell::new(info.grid_zoom.value()));
    let lightbox_slider_tick_running = Rc::new(Cell::new(false));
    let lightbox_slider_latest_for_change = lightbox_slider_latest.clone();
    let lightbox_slider_applied_for_change = lightbox_slider_applied.clone();
    let lightbox_slider_tick_running_for_change = lightbox_slider_tick_running.clone();

    info.grid_zoom.connect_value_changed(move |scale| {
        if std::env::var_os("PICASA_TRACE").is_some() {
            eprintln!(
                "PIC_ZOOM_UI event=value_changed value={:.3} lightbox_visible={} edit_visible={} syncing={} last={:.3}",
                scale.value(),
                lightbox_for_zoom_slider.root.is_visible(),
                main_stack_for_zoom_slider.visible_child_name().as_deref() == Some("edit"),
                grid_zoom_syncing_for_slider.get(),
                slider_last_value_for_change.get(),
            );
        }
        if grid_zoom_syncing_for_slider.get() {
            slider_last_value_for_change.set(scale.value());
            lightbox_slider_latest_for_change.set(scale.value());
            lightbox_slider_applied_for_change.set(scale.value());
            return;
        }

        if lightbox_for_zoom_slider.root.is_visible() {
            let value = scale.value();
            lightbox_slider_latest_for_change.set(value);
            if std::env::var_os("PICASA_TRACE").is_some() {
                let fit = lightbox_for_zoom_slider.current_fit_scale();
                eprintln!(
                    "PIC_ZOOM_UI lightbox_input slider={value:.3} fit={fit:.6} native_req={:.6} current_native={:.6}",
                    lightbox_scale_from_slider(value, fit),
                    lightbox_for_zoom_slider.current_manual_zoom_scale(),
                );
            }

            if !lightbox_slider_tick_running_for_change.get() {
                lightbox_slider_tick_running_for_change.set(true);

                // Drive geometry from GTK's real frame clock rather than an
                // approximate 16 ms wall-clock timer. A timer can fire between
                // layout/paint phases and make GtkPicture resize twice around
                // one rendered frame, which shows up as a small flash. The
                // frame callback applies only the newest absolute slider value.
                let lightbox = lightbox_for_zoom_slider.clone();
                let latest = lightbox_slider_latest_for_change.clone();
                let applied = lightbox_slider_applied_for_change.clone();
                let running = lightbox_slider_tick_running_for_change.clone();
                let tick_root = lightbox.root.clone();
                tick_root.add_tick_callback(move |root, _| {
                    if !root.is_visible() {
                        running.set(false);
                        return glib::ControlFlow::Break;
                    }

                    let value = latest.get();
                    if (value - applied.get()).abs() <= f64::EPSILON {
                        running.set(false);
                        return glib::ControlFlow::Break;
                    }

                    let fit_scale = lightbox.current_fit_scale();
                    let requested = lightbox_scale_from_slider(value, fit_scale);
                    if std::env::var_os("PICASA_TRACE").is_some() {
                        eprintln!(
                            "PIC_ZOOM_UI frame_apply slider={value:.3} fit={fit_scale:.6} native_req={requested:.6} previous_slider={:.3}",
                            applied.get(),
                        );
                    }
                    lightbox.request_slider_zoom(requested);
                    applied.set(value);
                    glib::ControlFlow::Continue
                });
            }
        } else if main_stack_for_zoom_slider.visible_child_name().as_deref() == Some("edit") {
            if let Some(editor) = edit_editor_for_zoom_slider.borrow().as_ref() {
                let fit_scale = editor.current_fit_scale();
                editor.set_manual_zoom_scale(lightbox_scale_from_slider(
                    scale.value(),
                    fit_scale,
                ));
            }
        } else {
            gallery_for_zoom_slider
                .request_slider_zoom(grid_zoom_width_from_slider(scale.value()));
        }
        slider_last_value_for_change.set(scale.value());
    });

    // Lightbox drives the same slider when Ctrl+wheel or the 1:1 action changes
    // the viewer zoom. The midpoint is always true native 100%.
    let grid_zoom_for_lightbox_sync = info.grid_zoom.clone();
    let grid_zoom_syncing_for_lightbox = grid_zoom_syncing.clone();
    let slider_last_value_for_sync = slider_last_value.clone();
    let lightbox_for_zoom_sync = lightbox.clone();
    lightbox.set_zoom_sync_handler(move |native_scale| {
        if !lightbox_for_zoom_sync.root.is_visible() {
            return;
        }
        // Fit is always the left endpoint and native 100% is always the
        // midpoint, independent of photo dimensions or window size.
        let fit_scale = lightbox_for_zoom_sync.current_fit_scale();
        let value = lightbox_slider_from_scale(native_scale, fit_scale);
        grid_zoom_syncing_for_lightbox.set(true);
        grid_zoom_for_lightbox_sync.set_value(value);
        grid_zoom_syncing_for_lightbox.set(false);
        slider_last_value_for_sync.set(value);
    });

    // Swap the physical slider between Gallery indices and Lightbox percentages.
    let grid_zoom_for_visibility = info.grid_zoom.clone();
    let grid_zoom_syncing_for_visibility = grid_zoom_syncing.clone();
    let gallery_for_zoom_visibility = gallery.clone();
    let lightbox_for_zoom_visibility = lightbox.clone();
    let slider_last_value_for_visibility = slider_last_value.clone();
    lightbox.root.connect_visible_notify(move |root| {
        grid_zoom_syncing_for_visibility.set(true);
        if root.is_visible() {
            grid_zoom_for_visibility.set_range(0.0, 100.0);
            grid_zoom_for_visibility.set_increments(0.25, 5.0);
            grid_zoom_for_visibility.set_round_digits(-1);
            grid_zoom_for_visibility.clear_marks();
            grid_zoom_for_visibility.add_mark(50.0, gtk::PositionType::Top, None);
            grid_zoom_for_visibility.add_mark(50.0, gtk::PositionType::Bottom, None);
            let native_scale = lightbox_for_zoom_visibility.current_manual_zoom_scale();
            let value = lightbox_slider_from_scale(
                native_scale,
                lightbox_for_zoom_visibility.current_fit_scale(),
            );
            grid_zoom_for_visibility.set_value(value);
            slider_last_value_for_visibility.set(value);
            grid_zoom_for_visibility.set_tooltip_text(Some(
                "Photo zoom — left: Fit, middle: 100%, right: 200%",
            ));
        } else {
            grid_zoom_for_visibility.set_range(0.0, 7.0);
            grid_zoom_for_visibility.set_increments(1.0, 1.0);
            grid_zoom_for_visibility.set_round_digits(0);
            grid_zoom_for_visibility.clear_marks();
            grid_zoom_for_visibility.add_mark(3.5, gtk::PositionType::Top, None);
            grid_zoom_for_visibility.add_mark(3.5, gtk::PositionType::Bottom, None);
            let value = grid_zoom_slider_value(gallery_for_zoom_visibility.current_zoom_width());
            grid_zoom_for_visibility.set_value(value);
            slider_last_value_for_visibility.set(value);
            grid_zoom_for_visibility.set_tooltip_text(Some("Thumbnail size (Ctrl + wheel)"));
        }
        grid_zoom_syncing_for_visibility.set(false);
    });

    let zoom_scale_scroll =
        gtk::EventControllerScroll::new(gtk::EventControllerScrollFlags::VERTICAL);
    zoom_scale_scroll.set_propagation_phase(gtk::PropagationPhase::Capture);
    let zoom_scale_for_scroll = info.grid_zoom.clone();
    let lightbox_for_scale_scroll = lightbox.clone();
    let main_stack_for_scale_scroll = main_stack.clone();
    zoom_scale_scroll.connect_scroll(move |controller, _, dy| {
        if controller
            .current_event_state()
            .contains(gtk::gdk::ModifierType::CONTROL_MASK)
        {
            return glib::Propagation::Proceed;
        }
        if dy == 0.0 {
            return glib::Propagation::Stop;
        }

        let step = if lightbox_for_scale_scroll.root.is_visible() {
            20.0
        } else if main_stack_for_scale_scroll.visible_child_name().as_deref() == Some("edit") {
            10.0
        } else {
            1.0
        };
        let direction = if dy > 0.0 { -1.0 } else { 1.0 };
        let adjustment = zoom_scale_for_scroll.adjustment();
        let next = (zoom_scale_for_scroll.value() + direction * step)
            .clamp(adjustment.lower(), adjustment.upper());
        zoom_scale_for_scroll.set_value(next);

        if std::env::var_os("PICASA_TRACE").is_some() {
            eprintln!(
                "PIC_ZOOM_UI wheel_over_slider dy={dy:.3} unit={:?} step={step:.3} next={next:.3}",
                controller.unit()
            );
        }
        glib::Propagation::Stop
    });
    info.grid_zoom.add_controller(zoom_scale_scroll);

    let grid_zoom_reset_press_x = Rc::new(Cell::new(f64::NAN));
    let grid_zoom_reset_press_x_for_press = grid_zoom_reset_press_x.clone();
    info.grid_zoom_reset.connect_pressed(move |_, _, x, _| {
        if std::env::var_os("PICASA_TRACE").is_some() {
            eprintln!("PIC_ZOOM_UI gesture=press x={x:.2}");
        }
        grid_zoom_reset_press_x_for_press.set(x);
    });

    let gallery_for_zoom_reset = gallery.clone();
    let lightbox_for_zoom_reset = lightbox.clone();
    let edit_editor_for_zoom_reset = edit_editor.clone();
    let main_stack_for_zoom_reset = main_stack.clone();
    let grid_zoom_for_reset = info.grid_zoom.clone();
    let grid_zoom_reset_press_x_for_release = grid_zoom_reset_press_x.clone();
    info.grid_zoom_reset
        .connect_released(move |_, n_press, x, _| {
            let press_x = grid_zoom_reset_press_x_for_release.replace(f64::NAN);
            if n_press != 1 || !press_x.is_finite() || grid_zoom_for_reset.width() <= 0 {
                return;
            }

            let centre_x = f64::from(grid_zoom_for_reset.width()) * 0.5;
            let was_click = (x - press_x).abs() <= 4.0;
            if !was_click || (x - centre_x).abs() > 12.0 {
                return;
            }

            if lightbox_for_zoom_reset.root.is_visible() {
                lightbox_for_zoom_reset.set_manual_zoom_scale(1.0);
            } else if main_stack_for_zoom_reset.visible_child_name().as_deref() == Some("edit") {
                if let Some(editor) = edit_editor_for_zoom_reset.borrow().as_ref() {
                    editor.fit();
                }
            } else {
                gallery_for_zoom_reset.reset_zoom();
            }
        });

    let selected_for_rotate = selected_photo.clone();
    let db_for_rotate = connection.clone();
    let info_rotate = info.clone();
    let gallery_for_rotate = gallery.clone();
    let lightbox_for_rotate = lightbox.clone();
    let edit_editor_for_rotate = edit_editor.clone();
    let main_stack_for_rotate = main_stack.clone();

    info.rotate.connect_clicked(move |_| {
        let Some(photo) = selected_for_rotate.borrow().clone() else {
            return;
        };
        let rotation = (photo.rotation() + 90) % 360;

        if let Err(error) = db::set_rotation(&db_for_rotate.borrow(), photo.id(), rotation) {
            eprintln!("Could not rotate photo: {error}");
            return;
        }
        photo.set_rotation(rotation);
        info_rotate.set_photo(Some(&photo));
        gallery_for_rotate.refresh_thumbnails();
        lightbox_for_rotate.refresh_current();
        if main_stack_for_rotate.visible_child_name().as_deref() == Some("edit") {
            if let Some(editor) = edit_editor_for_rotate.borrow().as_ref() {
                if editor.photo_id() == photo.id() {
                    editor.set_library_rotation(rotation);
                }
            }
        }
        
    });

fn show_photo_export_dialog(
    window: &gtk::Window,
    jobs: Vec<crate::edit::export_batch::ExportJob>,
    progress: Rc<OperationProgressUi>,
) {
    let dialog = gtk::Dialog::new();
    if jobs.len() == 1 {
        dialog.set_title(Some("Export Photo"));
    } else {
        dialog.set_title(Some("Export Photos"));
    }
    dialog.set_transient_for(Some(window));
    dialog.set_modal(true);
    dialog.add_button("Cancel", gtk::ResponseType::Cancel);
    let export_button = dialog.add_button("Export", gtk::ResponseType::Ok);
    export_button.add_css_class("suggested-action");
    dialog.set_default_response(gtk::ResponseType::Ok);

    let content = dialog.content_area();
    content.set_spacing(12);
    content.set_margin_top(18);
    content.set_margin_bottom(6);
    content.set_margin_start(18);
    content.set_margin_end(18);

    let grid = gtk::Grid::new();
    grid.set_row_spacing(12);
    grid.set_column_spacing(12);

    if jobs.len() > 1 {
        let count = gtk::Label::new(Some(&format!("{} photos selected", jobs.len())));
        count.set_xalign(0.0);
        grid.attach(&count, 0, 0, 2, 1);
    }

    let size_label = gtk::Label::new(Some("Size"));
    size_label.set_xalign(0.0);
    let size = gtk::DropDown::from_strings(&[
        "Original size",
        "4K (3840 px)",
        "2048 px",
        "Full HD (1920 px)",
        "HD (1280 px)",
    ]);
    size.set_selected(0);
    let size_row = if jobs.len() > 1 { 1 } else { 0 };
    grid.attach(&size_label, 0, size_row, 1, 1);
    grid.attach(&size, 1, size_row, 1, 1);

    let type_label = gtk::Label::new(Some("File type"));
    type_label.set_xalign(0.0);
    let file_type = gtk::DropDown::from_strings(
        &crate::edit::export_batch::ExportFormat::dialog_labels(),
    );
    file_type.set_selected(0);
    grid.attach(&type_label, 0, size_row + 1, 1, 1);
    grid.attach(&file_type, 1, size_row + 1, 1, 1);
    content.append(&grid);

    {
        let dialog_for_response = dialog.clone();
        let window = window.clone();
        let size = size.clone();
        let file_type = file_type.clone();
        dialog.connect_response(move |_, response| {
            if response != gtk::ResponseType::Ok {
                dialog_for_response.destroy();
                return;
            }
            let max_edge = match size.selected() {
                1 => 3840,
                2 => 2048,
                3 => 1920,
                4 => 1280,
                _ => 0,
            };
            let format =
                crate::edit::export_batch::ExportFormat::from_dialog_index(file_type.selected());
            let jobs = jobs
                .iter()
                .map(|job| {
                    let mut job = job.clone();
                    job.file_name =
                        crate::edit::export_batch::file_name_for_format(&job.file_name, format);
                    job
                })
                .collect::<Vec<_>>();
            dialog_for_response.destroy();
            choose_photo_export_destination(
                &window,
                jobs,
                max_edge,
                format,
                progress.clone(),
            );
        });
    }
    dialog.show();
}

fn choose_photo_export_destination(
    window: &gtk::Window,
    jobs: Vec<crate::edit::export_batch::ExportJob>,
    max_edge: u32,
    format: crate::edit::export_batch::ExportFormat,
    progress: Rc<OperationProgressUi>,
) {
    let multiple = jobs.len() > 1;
    let dialog = gtk::FileChooserNative::new(
        Some(if multiple {
            "Export Photos to Folder"
        } else {
            "Export Photo"
        }),
        Some(window),
        if multiple {
            gtk::FileChooserAction::SelectFolder
        } else {
            gtk::FileChooserAction::Save
        },
        Some("Export"),
        Some("Cancel"),
    );
    if !multiple {
        if let Some(job) = jobs.first() {
            dialog.set_current_name(&job.file_name);
        }
    }
    dialog.connect_response(move |dialog, response| {
        if response == gtk::ResponseType::Accept {
            if let Some(path) = dialog.file().and_then(|file| file.path()) {
                if multiple {
                    start_photo_export_folder(progress.clone(), jobs.clone(), path, max_edge, format);
                } else if let Some(job) = jobs.first().cloned() {
                    start_photo_export_single(progress.clone(), job, path, max_edge, format);
                }
            }
        }
        dialog.destroy();
    });
    dialog.show();
}

enum ExportProgressMessage {
    Update {
        done: usize,
        total: usize,
        filename: String,
        failed: usize,
    },
    Done(crate::edit::export_batch::BatchExportOutcome),
}

fn watch_export_progress(
    progress: Rc<OperationProgressUi>,
    receiver: std::sync::mpsc::Receiver<ExportProgressMessage>,
    total: usize,
) {
    glib::timeout_add_local(Duration::from_millis(80), move || {
        let mut flow = glib::ControlFlow::Continue;
        while let Ok(message) = receiver.try_recv() {
            match message {
                ExportProgressMessage::Update {
                    done,
                    filename,
                    failed,
                    ..
                } => {
                    progress.update("Exporting photos", done, total, &filename, failed);
                }
                ExportProgressMessage::Done(outcome) => {
                    let cancelled = outcome
                        .errors
                        .iter()
                        .any(|error| error.contains("cancelled"));
                    let summary = if cancelled {
                        format!(
                            "Export stopped — {} exported · {} skipped · {} failed",
                            outcome.exported, outcome.skipped, outcome.failed
                        )
                    } else if outcome.failed == 0 && outcome.skipped == 0 {
                        format!("Export complete — {} exported", outcome.exported)
                    } else {
                        format!(
                            "Export complete — {} exported · {} skipped · {} failed",
                            outcome.exported, outcome.skipped, outcome.failed
                        )
                    };
                    for error in outcome.errors.iter().take(5) {
                        eprintln!("Export issue: {error}");
                    }
                    let title = if cancelled {
                        "Export stopped"
                    } else {
                        "Export complete"
                    };
                    progress.finish(title, &summary);
                    flow = glib::ControlFlow::Break;
                }
            }
        }
        flow
    });
}

fn start_photo_export_folder(
    progress: Rc<OperationProgressUi>,
    jobs: Vec<crate::edit::export_batch::ExportJob>,
    folder: std::path::PathBuf,
    max_edge: u32,
    format: crate::edit::export_batch::ExportFormat,
) {
    let total = jobs.len();
    progress.begin("Exporting photos", total);
    let cancel = progress.cancel_flag();
    let (sender, receiver) = std::sync::mpsc::channel();
    watch_export_progress(progress, receiver, total);
    std::thread::spawn(move || {
        let outcome = crate::edit::export_batch::run_batch_export(
            &jobs,
            &folder,
            max_edge,
            crate::edit::export_batch::default_export_quality(),
            format,
            |job| crate::edit::export_batch::render_job(job),
            |done, total, filename, failed| {
                let _ = sender.send(ExportProgressMessage::Update {
                    done,
                    total,
                    filename: filename.to_string(),
                    failed,
                });
            },
            Some(&cancel),
        );
        let _ = sender.send(ExportProgressMessage::Done(outcome));
    });
}

fn start_photo_export_single(
    progress: Rc<OperationProgressUi>,
    job: crate::edit::export_batch::ExportJob,
    destination: std::path::PathBuf,
    max_edge: u32,
    format: crate::edit::export_batch::ExportFormat,
) {
    progress.begin("Exporting photos", 1);
    let cancel = progress.cancel_flag();
    let (sender, receiver) = std::sync::mpsc::channel();
    watch_export_progress(progress, receiver, 1);
    std::thread::spawn(move || {
        let file_name = job.file_name.clone();
        let outcome = if cancel.load(std::sync::atomic::Ordering::Relaxed) {
            crate::edit::export_batch::BatchExportOutcome {
                errors: vec!["cancelled".into()],
                ..Default::default()
            }
        } else if !crate::source::file_available(&job.source_path) {
            crate::edit::export_batch::BatchExportOutcome {
                skipped: 1,
                errors: vec![format!("skipped (missing): {}", job.source_path)],
                ..Default::default()
            }
        } else {
            let result = crate::edit::export_batch::export_job_to(
                &job,
                &destination,
                max_edge,
                crate::edit::export_batch::default_export_quality(),
                format,
                &|job| crate::edit::export_batch::render_job(job),
            );
            match result {
                Ok(()) => crate::edit::export_batch::BatchExportOutcome {
                    exported: 1,
                    ..Default::default()
                },
                Err(error) => crate::edit::export_batch::BatchExportOutcome {
                    failed: 1,
                    errors: vec![format!("{}: {error:#}", job.source_path)],
                    ..Default::default()
                },
            }
        };
        let _ = sender.send(ExportProgressMessage::Update {
            done: 1,
            total: 1,
            filename: file_name,
            failed: outcome.failed,
        });
        let _ = sender.send(ExportProgressMessage::Done(outcome));
    });
}

    let selected_for_export = selected_photo.clone();
    let parent_for_export = window.clone();
    let gallery_for_export = gallery.clone();
    let progress_for_export = operation_progress.clone();

    let export_clicked: Rc<dyn Fn()> = {
        let selected_for_export = selected_for_export;
        let parent_for_export = parent_for_export;
        let gallery_for_export = gallery_for_export;
        let progress_for_export = progress_for_export;
        Rc::new(move || {
            let Some(photo) = selected_for_export.borrow().clone() else {
                return;
            };
            let ids = gallery_for_export.selected_photo_ids(Some(photo.id()));
            let known: std::collections::HashMap<i64, _> = gallery_for_export
                .photo_objects()
                .into_iter()
                .map(|object| (object.id(), object))
                .collect();
            let jobs = ids
                .iter()
                .filter_map(|id| known.get(id))
                .map(|object| {
                    crate::edit::export_batch::ExportJob::from_record(
                        object.path(),
                        object.rotation(),
                        object.edit_recipe(),
                        object.width(),
                        object.height(),
                        &object.filename(),
                    )
                })
                .collect::<Vec<_>>();
            if jobs.is_empty() {
                return;
            }
            show_photo_export_dialog(
                parent_for_export.upcast_ref::<gtk::Window>(),
                jobs,
                progress_for_export.clone(),
            );
        })
    };
    info.export.connect_clicked({
        let export_clicked = export_clicked.clone();
        move |_| export_clicked()
    });
    export_slot.replace(Some(export_clicked.clone()));

    let selected_for_print = selected_photo.clone();
    let window_for_print = window.clone();
    let connection_for_print = connection.clone();
    let gallery_for_print = gallery.clone();

    info.print.connect_clicked(move |_| {
        let Some(photo) = selected_for_print.borrow().clone() else {
            return;
        };

        // Print every selected photo (the full multi-selection, falling back
        // to the anchor photo when nothing extra is selected). PhotoObject is
        // a GTK object and must stay on the GTK thread: copy only Send-safe
        // scalar/string values into the print requests; the renders happen on
        // a worker thread while the dialog runs here.
        let ids = gallery_for_print.selected_photo_ids(Some(photo.id()));
        let requests: Vec<PhotoPrintRequest> = ids
            .iter()
            .filter_map(|id| db::photo(&connection_for_print.borrow(), *id).ok().flatten())
            .map(|record| PhotoPrintRequest {
                job_name: record
                    .path
                    .rsplit('/')
                    .next()
                    .unwrap_or("photo")
                    .to_string(),
                reference: record.path,
                rotation: record.rotation,
                edit_recipe: record.edit_recipe,
                source_width: record.width.unwrap_or(0),
                source_height: record.height.unwrap_or(0),
            })
            .collect();

        print_photos(&window_for_print, &connection_for_print, requests);
    });

    let (
        main_split,
        main_surface,
        sidebar,
        thumbnail_recovery_requested,
        thumbnail_recovery_deferred,
        reconnected_sources,
        sidebar_for_events,
        right_column,
        right_header,
        search,
    ) = include!("layout.rs");

    // Window-level photo shortcuts own keys that must work regardless of
    // whether the GridView, sectioned Folder renderer or Lightbox has focus.
    // Real text editors always keep their normal keyboard behaviour.
    {
        let window_for_keys = window.clone();
        let gallery_for_keys = gallery.clone();
        let filter_for_keys = filter.clone();
        let stack_for_keys = main_stack.clone();
        let lightbox_for_keys = lightbox.clone();
        let selected_for_keys = selected_photo.clone();
        let db_for_keys = connection.clone();
        let info_for_keys = info.clone();
        let sort_for_keys = sort.clone();
        let rating_filter_for_keys = rating_filter.clone();
        let search_for_keys = search_text.clone();

        let photo_keys = gtk::EventControllerKey::new();
        photo_keys.set_propagation_phase(gtk::PropagationPhase::Capture);
        photo_keys.connect_key_pressed(move |_, key, _, modifiers| {
            let typing = std::iter::successors(
                gtk::prelude::RootExt::focus(&window_for_keys),
                |widget| widget.parent(),
            )
            .any(|widget| widget.is::<gtk::Editable>() || widget.is::<gtk::TextView>());
            if typing {
                return glib::Propagation::Proceed;
            }

            let control = modifiers.contains(gtk::gdk::ModifierType::CONTROL_MASK);
            let disallowed_modifier = modifiers.intersects(
                gtk::gdk::ModifierType::ALT_MASK
                    | gtk::gdk::ModifierType::SUPER_MASK
                    | gtk::gdk::ModifierType::META_MASK,
            );
            let photos_page =
                stack_for_keys.visible_child_name().as_deref() == Some("photos");

            if control && !disallowed_modifier && matches!(key, gtk::gdk::Key::a | gtk::gdk::Key::A) {
                if photos_page && !lightbox_for_keys.root.is_visible() {
                    let folder_id = match filter_for_keys.get() {
                        sidebar::SidebarFilter::Folder(sidebar_folder_id) => {
                            gallery_for_keys.selected_folder_id().or(Some(sidebar_folder_id))
                        }
                        _ => None,
                    };
                    if std::env::var_os("PICASA_TRACE").is_some() {
                        eprintln!("UI TRACE ctrl_a folder_id={folder_id:?}");
                    }
                    gallery_for_keys.select_all_keyboard_scope(folder_id);
                    return glib::Propagation::Stop;
                }
                return glib::Propagation::Proceed;
            }

            if control && !disallowed_modifier && matches!(key, gtk::gdk::Key::d | gtk::gdk::Key::D) {
                if photos_page && !lightbox_for_keys.root.is_visible() {
                    gallery_for_keys.clear_keyboard_selection();
                    return glib::Propagation::Stop;
                }
                return glib::Propagation::Proceed;
            }

            // Bare numeric keys are reserved outside text fields so a year such
            // as 2026 cannot accidentally start type-to-search. 0 clears the
            // rating, 1..5 assign that rating to the complete current selection,
            // and 6..9 are intentionally consumed without an action.
            if !control && !disallowed_modifier {
                if let Some(digit) = key
                    .to_unicode()
                    .and_then(|character| character.to_digit(10))
                {
                    if digit <= 5 && (photos_page || lightbox_for_keys.root.is_visible()) {
                        if let Some(photo) = selected_for_keys.borrow().clone() {
                            let rating = digit as i32;
                            let ids = if lightbox_for_keys.root.is_visible() {
                                vec![photo.id()]
                            } else {
                                gallery_for_keys.selected_photo_ids(Some(photo.id()))
                            };
                            if let Err(error) =
                                db::set_rating_for_photos(&db_for_keys.borrow(), &ids, rating)
                            {
                                eprintln!("Could not update rating: {error}");
                            } else {
                                gallery_for_keys.update_ratings(&ids, rating);
                                photo.set_rating(rating);
                                info_for_keys.set_photo(Some(&photo));

                                if rating_filter_for_keys.get() != RatingFilter::All
                                    || sort_for_keys.get().field == SortField::Rating
                                {
                                    refresh_grid(
                                        &db_for_keys,
                                        filter_for_keys.get(),
                                        &search_for_keys.borrow(),
                                        sort_for_keys.get(),
                                        &gallery_for_keys,
                                    );
                                }
                                if std::env::var_os("PICASA_TRACE").is_some() {
                                    eprintln!(
                                        "UI TRACE photo_rating_shortcut ids={} rating={}",
                                        ids.len(),
                                        rating
                                    );
                                }
                            }
                        }
                    }
                    return glib::Propagation::Stop;
                }
            }

            glib::Propagation::Proceed
        });
        window.add_controller(photo_keys);
    }

    // Appearance button: opens Settings → Themes, where the theme list is
    // built from the theme folders on disk. toolbar.rs appends the
    // `settings` button to the header tools.
    let settings = crate::window::theme::appearance_button();
    theme_engine.set_appearance_button(&settings);
    // Theme switches redraw the albums home so covers pick up the palette.
    // Window chrome (traffic lights vs native title buttons) is wired inside
    // layout.rs, where the headers and the placement closure live.
    theme_engine.set_post_apply(theme_post_apply);
    {
        let present_settings_for_appearance = present_settings.clone();
        settings.connect_clicked(move |_| {
            present_settings_for_appearance(Some("themes"));
        });
    }
    let refresh = include!("toolbar.rs");

    right_column.append(&right_header);
    right_column.append(&content);

    window.set_content(Some(&main_surface));

    let startup_gallery = gallery.clone();
    let startup_photos_for_idle = startup_photos.clone();
    let startup_total = startup_photos_for_idle.len();
    let mut startup_offset = 0usize;
    let startup_view_restored = Rc::new(Cell::new(false));
    let last_activated_for_restore = last_activated_photo_id.clone();
    let restore_startup_view: Rc<dyn Fn()> = {
        let restored = startup_view_restored.clone();
        let gallery = gallery.clone();
        let albums_home = albums_home.clone();
        Rc::new(move || {
            if restored.replace(true) {
                return;
            }
            if initial_filter == sidebar::SidebarFilter::Albums {
                let adjustment = albums_home.vadjustment();
                glib::timeout_add_local_once(Duration::from_millis(50), move || {
                    let upper = (adjustment.upper() - adjustment.page_size())
                        .max(adjustment.lower());
                    adjustment
                        .set_value(saved_albums_scroll.clamp(adjustment.lower(), upper));
                });
            } else if !last_activated_for_restore
                .get()
                .is_some_and(|photo_id| gallery.restore_activated_photo(photo_id))
            {
                if let Some(photo_id) = saved_view_photo_id {
                    gallery.restore_view(photo_id, saved_view_scroll);
                }
            }
        })
    };
    let startup_generation = REFRESH_GENERATION.load(std::sync::atomic::Ordering::Relaxed);
    const STARTUP_BATCH_SIZE: usize = 500;
    glib::idle_add_local(move || {
        // A newer filter/navigation owns the grid, including while its query runs.
        if REFRESH_GENERATION.load(std::sync::atomic::Ordering::Relaxed) != startup_generation {
            return glib::ControlFlow::Break;
        }
        if startup_offset >= startup_total {
            restore_startup_view();
            return glib::ControlFlow::Break;
        }

        let end = (startup_offset + STARTUP_BATCH_SIZE).min(startup_total);
        let batch = &startup_photos_for_idle[startup_offset..end];
        if startup_offset == 0 {
            startup_gallery.replace(batch);
        } else {
            startup_gallery.append_photos(batch);
        }
        startup_offset = end;

        if startup_offset >= startup_total {
            restore_startup_view();
            glib::ControlFlow::Break
        } else {
            glib::ControlFlow::Continue
        }
    });

    // Responsive sidebar transition.
    //
    // Do not use an AdwBreakpoint to flip `collapsed` directly: changing
    // collapsed is a structural side-by-side -> overlay switch and therefore
    // looks like the sidebar is cut out before its drawer animation can run.
    //
    // Instead stage the transition:
    //   narrow: slide sidebar out -> then collapse
    //   wide:   expand while hidden -> then slide sidebar in
    //
    // Small hysteresis avoids chattering when the user drags around 1050 px.
    const SIDEBAR_COMPACT_ENTER_WIDTH: i32 = 1050;
    const SIDEBAR_COMPACT_EXIT_WIDTH: i32 = 1080;

    let sidebar_breakpoint_transition = Rc::new(Cell::new(false));
    let sidebar_breakpoint_generation = Rc::new(Cell::new(0u64));
    {
        let window_for_breakpoint = window.clone();
        let main_split_for_breakpoint = main_split.clone();
        let sidebar_for_breakpoint = sidebar.clone();
        let transition = sidebar_breakpoint_transition.clone();
        let generation = sidebar_breakpoint_generation.clone();

        window.add_tick_callback(move |window, _| {
            let width = window.width();

            if !main_split_for_breakpoint.is_collapsed()
                && width <= SIDEBAR_COMPACT_ENTER_WIDTH
                && !transition.get()
            {
                generation.set(generation.get().wrapping_add(1));
                transition.set(true);

                if main_split_for_breakpoint.shows_sidebar() {
                    // Free the gallery width first, but keep the sidebar visible.
                    // In collapsed mode the sidebar becomes an overlay, so the
                    // shrinking window no longer squeezes the side-by-side panes
                    // into invalid/negative allocations while the drawer moves.
                    main_split_for_breakpoint.set_collapsed(true);

                    let split = main_split_for_breakpoint.clone();
                    let transition = transition.clone();
                    // Wait for one real frame with the sidebar visible in
                    // overlay mode before starting the hide. The pin button and
                    // hover auto-hide both use set_show_sidebar() directly;
                    // starting on the following frame gives this responsive
                    // transition the same libadwaita drawer animation instead
                    // of visually merging collapse + hide into one fast cut.
                    split.add_tick_callback(move |split, _| {
                        split.set_show_sidebar(false);
                        transition.set(false);
                        glib::ControlFlow::Break
                    });
                } else {
                    main_split_for_breakpoint.set_collapsed(true);
                    transition.set(false);
                }
            } else if main_split_for_breakpoint.is_collapsed()
                && width >= SIDEBAR_COMPACT_EXIT_WIDTH
                && !transition.get()
            {
                generation.set(generation.get().wrapping_add(1));
                transition.set(true);

                // Expand while the sidebar is still hidden so the structural
                // layout switch is not visible, then reveal through the normal
                // drawer animation on the next main-loop turn.
                main_split_for_breakpoint.set_show_sidebar(false);
                main_split_for_breakpoint.set_collapsed(false);

                let split = main_split_for_breakpoint.clone();
                let sidebar = sidebar_for_breakpoint.clone();
                let transition = transition.clone();
                glib::idle_add_local_once(move || {
                    if sidebar::is_pinned(&sidebar) {
                        split.set_show_sidebar(true);
                    }
                    transition.set(false);
                });
            }

            glib::ControlFlow::Continue
        });
    }

    crate::css::install_foundation(&display);
    // Apply the persisted theme (and the base layer) before the window's
    // first rendered frame. Must run after the foundation so the base theme
    // is added after base.css at the same priority and wins.
    theme_engine.startup();

    let (scan_sender, scan_receiver) = std::sync::mpsc::channel::<ScanUiEvent>();
    let (refresh_prepare_sender, refresh_prepare_receiver) =
        std::sync::mpsc::channel::<RefreshPrepareEvent>();

    let scan_job = Rc::new(RefCell::new(ScanJobState::default()));
    sidebar::bind_refresh_gate(&sidebar, &refresh);
    {
        let job = scan_job.clone();
        let refresh = refresh.downgrade();
        let stop = refresh_status_stop.clone();
        let progress = operation_progress.clone();
        // Includes preparation and cancellation acknowledgement, not merely
        // the time an individual folder worker is active.
        glib::timeout_add_local(Duration::from_millis(50), move || {
            let Some(refresh) = refresh.upgrade() else {
                return glib::ControlFlow::Break;
            };
            let busy = job.borrow().kind.is_some();
            let exporting = progress.is_running();
            refresh.set_sensitive(!busy);
            stop.set_sensitive(busy || exporting);
            glib::ControlFlow::Continue
        });
    }
    let stop_scan = gtk::Button::from_icon_name("process-stop-symbolic");
    stop_scan.set_tooltip_text(Some("Stop current scan"));
    stop_scan.set_visible(false);
    right_header.pack_end(&stop_scan);

    let start_next_scan: Rc<dyn Fn()> = {
        let scan_job = scan_job.clone();
        let scan_sender = scan_sender.clone();
        Rc::new(move || {
            let next = {
                let mut job = scan_job.borrow_mut();
                if job.active.is_some() {
                    None
                } else {
                    job.pending
                        .pop_front()
                        .map(|root| (root, job.generation, job.kind))
                }
            };
            let Some((root, generation, kind)) = next else {
                return;
            };
            
            let Ok(database) = db::active_database_path() else {
                scan_job.borrow_mut().kind = None;
                return;
            };
            let control = spawn_tagged_scan(root, database, generation, scan_sender.clone());
            scan_job.borrow_mut().active = Some(control);
        })
    };

    refresh_folder_slot.replace(Some({
        let scan_job = scan_job.clone();
        let refresh_prepare_sender = refresh_prepare_sender.clone();
        let refresh_status_box = refresh_status_box.clone();
        let refresh_status_spinner = refresh_status_spinner.clone();
        let refresh_status_label = refresh_status_label.clone();
        let stop_scan = stop_scan.clone();
        let refresh = refresh.clone();
        Rc::new(move |reason: PhotoScanRequestReason, path: String| {
            
            if reason.scan_kind().is_none() {
                
                return;
            }
            if scan_job.borrow().kind.is_some() {
                
                refresh_status_label.set_text("Refresh already running…");
                refresh_status_spinner.set_spinning(true);
                refresh_status_box.set_visible(true);
                stop_scan.set_visible(true);
                return;
            }
            // A full Refresh All may still have a background availability/sidebar
            // rebuild pending. Do not let that stale worker mutate the sidebar
            // while a targeted folder refresh is starting.
            refresh.set_sensitive(false);
            invalidate_availability_refreshes();
            refresh_status_label.set_text(&format!("Refreshing {}…", crate::source::filename(&path)));
            refresh_status_spinner.set_spinning(true);
            refresh_status_box.set_visible(true);
            stop_scan.set_visible(true);
            let generation = {
                let mut job = scan_job.borrow_mut();
                job.authorize_photo_scan(reason)
                    .expect("folder refresh reason was authorized")
            };
            let sender = refresh_prepare_sender.clone();
            let database = db::active_database_path();
            std::thread::spawn(move || {
                let imported_root = database
                    .and_then(|database| db::open_existing(&database))
                    .and_then(|connection| db::folders(&connection))
                    .map(|folders| {
                        folders
                            .into_iter()
                            .any(|folder| folder.path == path && folder.imported_root)
                    })
                    .map_err(|error| error.to_string());
                let _ = sender.send(RefreshPrepareEvent::FolderReady {
                    generation,
                    path,
                    imported_root,
                });
            });
        })
    }));

    // Debounce/coalesce monitor activity independently from scan authorization.
    // One busy scan cannot be interrupted by a watch event; the dirty root
    // remains pending and is submitted after the current job becomes idle.
    {
        let pending = pending_watch_refreshes.clone();
        let scan_job = scan_job.clone();
        let refresh_folder_slot = refresh_folder_slot.clone();
        glib::timeout_add_local(Duration::from_millis(250), move || {
            if scan_job.borrow().kind.is_some() {
                return glib::ControlFlow::Continue;
            }
            let now = Instant::now();
            let ready = pending
                .borrow()
                .iter()
                .find_map(|(path, changed_at)| {
                    (now.duration_since(*changed_at) >= Duration::from_millis(750))
                        .then(|| path.clone())
                });
            if let Some(path) = ready {
                pending.borrow_mut().remove(&path);
                
                if let Some(callback) = refresh_folder_slot.borrow().as_ref() {
                    callback(PhotoScanRequestReason::DebouncedWatchRefresh, path);
                }
            }
            glib::ControlFlow::Continue
        });
    }
    rebuild_folder_watches();

    let cancel_scan_job: Rc<dyn Fn()> = {
        let scan_job = scan_job.clone();
        let refresh_status_label = refresh_status_label.clone();
        Rc::new(move || {
            let mut job = scan_job.borrow_mut();
            // Stop means the whole current job. In particular, a library refresh
            // must not continue with the next queued folder after cancellation.
            job.stop_requested = true;
            job.pending.clear();
            if matches!(job.kind, Some(ScanJobKind::Refresh | ScanJobKind::FolderRefresh)) {
                refresh_status_label.set_text("Stopping refresh…");
            }
            if let Some(control) = job.active.as_ref() {
                control.cancel();
            }
        })
    };
    {
        let cancel = cancel_scan_job.clone();
        stop_scan.connect_clicked(move |_| cancel());
    }
    {
        let cancel = cancel_scan_job.clone();
        let progress = operation_progress.clone();
        refresh_status_stop.connect_clicked(move |_| {
            if progress.is_running() {
                progress.request_cancel();
            } else {
                cancel();
            }
        });
    }

    // Recover existing indexed photos at startup, on mount changes, or after
    // manual Refresh. Offline drives may stay disconnected for hours; leave
    // them idle until one of those events requests another recovery pass.
    let startup_paths = std::sync::Arc::new(
        startup_photos
            .iter()
            .map(|photo| photo.path.clone())
            .collect::<std::collections::HashSet<_>>(),
    );
    let start_thumbnail_recovery: Rc<dyn Fn()> = {
        let connection = connection.clone();
        let scan_job = scan_job.clone();
        let sender = scan_sender.clone();
        let requested = thumbnail_recovery_requested.clone();
        let reconnected_sources = reconnected_sources.clone();
        Rc::new(move || {
            if scan_job.borrow().kind.is_some()
                || (!requested.get() && reconnected_sources.borrow().pending.is_empty())
            {
                return;
            }
            let Ok(mut photos) = db::photos(&connection.borrow(), None, false, None) else {
                return;
            };
            if !requested.get() {
                let sources = reconnected_sources.borrow();
                photos.retain(|photo| sources.includes(&photo.path));
            }
            retain_enabled_formats(&connection.borrow(), &mut photos);
            requested.set(false);
            reconnected_sources.borrow_mut().pending.clear();
            // Unrelated mounts need no cache checks, worker, or progress UI.
            if photos.is_empty() {
                return;
            }
            let mut job = scan_job.borrow_mut();
            job.generation = job.generation.wrapping_add(1);
            job.kind = Some(ScanJobKind::Maintenance);
            job.imported_total = 0;
            job.failed_total = 0;
            job.stop_requested = false;
            let control = scanner::ScanControl::default();
            job.active = Some(control.clone());
            spawn_thumbnail_recovery(
                photos,
                startup_paths.clone(),
                job.generation,
                sender.clone(),
                control,
            );
        })
    };
    start_thumbnail_recovery();

    let parent = window.clone();
    let connection_for_import = connection.clone();
    let sidebar_refresh_for_import = availability_refresh.clone();
    let scan_job_for_import = scan_job.clone();
    let start_next_scan_for_import = start_next_scan.clone();

    #[cfg(target_os = "linux")]
    let scan_job_for_network = scan_job_for_import.clone();
    #[cfg(target_os = "linux")]
    let start_next_scan_for_network = start_next_scan_for_import.clone();
    #[cfg(target_os = "linux")]
    let connection_for_network = connection_for_import.clone();
    #[cfg(target_os = "linux")]
    let sidebar_refresh_for_network = sidebar_refresh_for_import.clone();
    #[cfg(target_os = "linux")]
    let parent_for_network = parent.clone();

    import_folder_slot.replace(Some(Rc::new(move || {
        let scan_job=scan_job_for_import.clone();
        let start_next_scan=start_next_scan_for_import.clone();
        let connection=connection_for_import.clone();
        let sidebar_refresh=sidebar_refresh_for_import.clone();
        let selected: Rc<dyn Fn(String)>=Rc::new(move |root: String| {
            if let Err(error)=db::mark_import_root(&connection.borrow(),&root){
                eprintln!("Could not register imported folder {root}: {error}");
                return;
            }
            sidebar_refresh();
            {
                let mut job=scan_job.borrow_mut();
                job.authorize_photo_scan(PhotoScanRequestReason::ImportFolder)
                    .expect("import is an authorized scan reason");
                job.pending.push_back(root);
            }
            start_next_scan();
        });
        let parent_for_local=parent.clone();
        let selected_for_local=selected.clone();
        // The Folders + button imports local folders only. Network shares are
        // added through their own section below Folders.
        let dialog=gtk::FileChooserNative::new(
            Some("Import Local Folder"),Some(&parent_for_local),
            gtk::FileChooserAction::SelectFolder,Some("Import"),Some("Cancel"));
        dialog.connect_response(move |dlg,response| {
            if response==gtk::ResponseType::Accept {
                if let Some(file)=dlg.file(){ selected_for_local(crate::source::reference(&file)); }
            }
            dlg.destroy();
        });
        dialog.show();
    })));

    #[cfg(target_os="linux")]
    add_network_share_slot.replace(Some(Rc::new(move || {
        let scan_job=scan_job_for_network.clone();
        let start_next_scan=start_next_scan_for_network.clone();
        let connection=connection_for_network.clone();
        let sidebar_refresh=sidebar_refresh_for_network.clone();
        let selected: Rc<dyn Fn(String)>=Rc::new(move |root: String| {
            if let Err(error)=db::mark_import_root(&connection.borrow(),&root){
                eprintln!("Could not register imported folder {root}: {error}");
                return;
            }
            sidebar_refresh();
            {
                let mut job=scan_job.borrow_mut();
                job.authorize_photo_scan(PhotoScanRequestReason::ImportFolder)
                    .expect("import is an authorized scan reason");
                job.pending.push_back(root);
            }
            start_next_scan();
        });
        let parent_for_network=parent_for_network.clone();
        crate::network_picker::open(
            parent_for_network.upcast_ref::<gtk::Window>(),selected);
    })));

    let scan_job_for_refresh = scan_job.clone();
    let refresh_prepare_sender_for_click = refresh_prepare_sender.clone();
    let recovery_requested_for_refresh = thumbnail_recovery_requested.clone();
    let refresh_status_box_for_click = refresh_status_box.clone();
    let refresh_status_spinner_for_click = refresh_status_spinner.clone();
    let refresh_status_label_for_click = refresh_status_label.clone();
    let stop_scan_for_refresh_click = stop_scan.clone();

    refresh.connect_clicked(move |button| {
        
        let maintenance_was_active = scan_job_for_refresh
            .borrow()
            .kind
            == Some(ScanJobKind::Maintenance);
        if maintenance_was_active {
            scan_job_for_refresh.borrow_mut().preempt_maintenance();
            
        } else if scan_job_for_refresh.borrow().kind.is_some() {
            
            refresh_status_label_for_click.set_text("Refresh already running…");
            refresh_status_spinner_for_click.set_spinning(true);
            refresh_status_box_for_click.set_visible(true);
            stop_scan_for_refresh_click.set_visible(true);
            return;
        }
        button.set_sensitive(false);
        // Do not request a full post-refresh thumbnail recovery pass here.
        // Refresh scans already create thumbnails for changed items; a recovery
        // pass over the entire 66k-photo library immediately after repeated
        // refreshes can monopolize the app. Startup/mount recovery remains.
        recovery_requested_for_refresh.set(false);
        refresh_status_label_for_click.set_text("Refreshing library…");
        refresh_status_spinner_for_click.set_spinning(true);
        refresh_status_box_for_click.set_visible(true);
        stop_scan_for_refresh_click.set_visible(true);
        

        let generation = {
            let mut job = scan_job_for_refresh.borrow_mut();
            job.authorize_photo_scan(PhotoScanRequestReason::ManualLibraryRefresh)
                .expect("manual library refresh is an authorized scan reason")
        };

        let sender = refresh_prepare_sender_for_click.clone();
        let database = db::active_database_path();
        std::thread::spawn(move || {
            
            let roots = database
                .and_then(|database| db::open_existing(&database))
                .and_then(|connection| db::imported_root_paths(&connection))
                .map_err(|error| error.to_string());
            let count = roots.as_ref().map(|roots| roots.len()).unwrap_or(0);
            
            let _ = sender.send(RefreshPrepareEvent::LibraryReady {
                generation,
                roots,
            });
        });
    });

    let gallery_for_events = gallery.clone();
    let connection_for_events = connection.clone();
    let info_for_events = info.clone();
    let selected_photo_for_events = selected_photo.clone();
    let availability_refresh_for_events = availability_refresh.clone();
    let filter_for_events = filter.clone();
    let search_for_events = search_text.clone();
    let sort_for_events = sort.clone();
    let scan_job_for_events = scan_job.clone();
    let start_next_scan_for_events = start_next_scan.clone();
    let stop_scan_for_events = stop_scan.clone();
    let refresh_status_box_for_events = refresh_status_box.clone();
    let refresh_status_spinner_for_events = refresh_status_spinner.clone();
    let refresh_status_label_for_events = refresh_status_label.clone();
    let mut displayed_generation: Option<u64> = None;
    let mut scan_count: usize = 0;
    let mut pending_photos: VecDeque<db::Photo> = VecDeque::new();
    let mut thumbnail_dirty_paths = VecDeque::<std::path::PathBuf>::new();
    let mut thumbnail_dirty_seen = std::collections::HashSet::<std::path::PathBuf>::new();
    let mut priority_thumbnail_paths = Vec::new();
    let mut failure_message_shown = false;
    let mut thumbnail_total: usize = 0;
    let mut last_progress_update = Instant::now();
    let mut pending_sidebar_counts: Option<db::SidebarCounts> = None;
    let mut photos_since_sidebar_update = 0usize;
    let mut last_sidebar_count_update = Instant::now();

    glib::timeout_add_local(Duration::from_millis(50), move || {
        let ui_tick_started = Instant::now();
        // Drain event-triggered recovery requests once the current scan ends.
        // With no request, this checks only a flag and performs no disk probes.
        start_thumbnail_recovery();
        priority_thumbnail_paths.extend(crate::thumbnail::take_priority_completions());
        let priority_completions = priority_thumbnail_paths.len();
        let priority_pending = crate::thumbnail::priority_pending_count();
        
        while let Ok(prepare_event) = refresh_prepare_receiver.try_recv() {
            match prepare_event {
                RefreshPrepareEvent::LibraryReady {
                    generation,
                    roots,
                } => {
                    if generation != scan_job_for_events.borrow().generation {
                        continue;
                    }
                    let roots = match roots {
                        Ok(roots) => roots.into_iter().collect::<VecDeque<_>>(),
                        Err(error) => {
                            eprintln!("Could not refresh library folders: {error}");
                            let mut job = scan_job_for_events.borrow_mut();
                            job.kind = None;
                            job.active = None;
                            job.pending.clear();
                            refresh_status_spinner_for_events.set_spinning(false);
                            stop_scan_for_events.set_visible(false);
                            refresh_status_label_for_events.set_text("Could not read library folders");
                            refresh_status_box_for_events.set_visible(true);
                            let panel = refresh_status_box_for_events.clone();
                            glib::timeout_add_local_once(Duration::from_millis(3000), move || {
                                panel.set_visible(false);
                            });
                            continue;
                        }
                    };
                    
                    if roots.is_empty() {
                        let mut job = scan_job_for_events.borrow_mut();
                        job.kind = None;
                        job.active = None;
                        job.pending.clear();
                        refresh_status_spinner_for_events.set_spinning(false);
                        stop_scan_for_events.set_visible(false);
                        refresh_status_label_for_events.set_text("No library folders to refresh");
                        refresh_status_box_for_events.set_visible(true);
                        let panel = refresh_status_box_for_events.clone();
                        glib::timeout_add_local_once(Duration::from_millis(2500), move || {
                            panel.set_visible(false);
                        });
                        continue;
                    }
                    let should_start = {
                        let mut job = scan_job_for_events.borrow_mut();
                        if job.stop_requested {
                            job.kind = None;
                            job.active = None;
                            job.pending.clear();
                            false
                        } else {
                            job.pending = roots;
                            true
                        }
                    };
                    if should_start {
                        start_next_scan_for_events();
                    } else {
                        refresh_status_spinner_for_events.set_spinning(false);
                        stop_scan_for_events.set_visible(false);
                        refresh_status_label_for_events.set_text("Library refresh stopped");
                        refresh_status_box_for_events.set_visible(true);
                        let panel = refresh_status_box_for_events.clone();
                        glib::timeout_add_local_once(Duration::from_millis(2500), move || {
                            panel.set_visible(false);
                        });
                    }
                }
                RefreshPrepareEvent::FolderReady {
                    generation,
                    path,
                    imported_root,
                } => {
                    if generation != scan_job_for_events.borrow().generation {
                        continue;
                    }
                    
                    let ok = match imported_root {
                        Ok(ok) => ok,
                        Err(error) => {
                            eprintln!("Could not validate refresh folder: {error}");
                            false
                        }
                    };
                    let should_start = {
                        let mut job = scan_job_for_events.borrow_mut();
                        if !ok || job.stop_requested {
                            job.kind = None;
                            job.active = None;
                            job.pending.clear();
                            false
                        } else {
                            job.pending.clear();
                            job.pending.push_back(path);
                            true
                        }
                    };
                    if should_start {
                        start_next_scan_for_events();
                    } else {
                        refresh_status_spinner_for_events.set_spinning(false);
                        stop_scan_for_events.set_visible(false);
                        refresh_status_label_for_events.set_text("Folder refresh stopped");
                        refresh_status_box_for_events.set_visible(true);
                        let panel = refresh_status_box_for_events.clone();
                        glib::timeout_add_local_once(Duration::from_millis(2500), move || {
                            panel.set_visible(false);
                        });
                    }
                }
            }
        }

        if priority_pending > 0 && thumbnail_total == 0 {
            refresh_status_label_for_events
                .set_text(&format!("Creating visible thumbnails ({priority_pending} queued)"));
            refresh_status_box_for_events.set_visible(true);
        } else if priority_completions > 0 && thumbnail_total == 0 {
            refresh_status_box_for_events.set_visible(false);
        }
        // Drain committed batches promptly, but cap both event count and wall
        // time so input, redraws, scrolling, and Stop remain responsive.
        const MAX_EVENTS_PER_TICK: usize = 64;
        const MAX_EVENT_TIME_PER_TICK: Duration = Duration::from_millis(8);
        let mut handled_events = 0;
        let mut max_event_queue_wait = Duration::ZERO;
        while handled_events < MAX_EVENTS_PER_TICK
            && ui_tick_started.elapsed() < MAX_EVENT_TIME_PER_TICK
        {
            let Ok(ui_event) = scan_receiver.try_recv() else {
                break;
            };
            handled_events += 1;
            max_event_queue_wait = max_event_queue_wait.max(ui_event.queued_at.elapsed());

            // Events from a cancelled/superseded scan are still allowed to
            // finish in their worker threads, but they must never overwrite
            // the progress UI or completion state of the newer job.
            if ui_event.generation != scan_job_for_events.borrow().generation {
                
                continue;
            }

            if displayed_generation != Some(ui_event.generation) {
                displayed_generation = Some(ui_event.generation);
                scan_count = 0;
                thumbnail_total = 0;
                failure_message_shown = false;
                pending_sidebar_counts = None;
                photos_since_sidebar_update = 0;
            }

            let event = ui_event.event;
            match &event {
                scanner::ScanEvent::Started { root } => {
                    
                    scan_count = 0;
                    thumbnail_total = 0;
                    let is_user_job = !matches!(
                        scan_job_for_events.borrow().kind,
                        Some(ScanJobKind::Maintenance) | None
                    );
                    stop_scan_for_events.set_visible(is_user_job);

                    let folder_name = root
                        .file_name()
                        .and_then(|name| name.to_str())
                        .unwrap_or_else(|| root.to_str().unwrap_or("folder"));
                    refresh_status_label_for_events.set_text(&format!("Scanning {folder_name}…"));
                    refresh_status_spinner_for_events.set_spinning(true);
                    refresh_status_box_for_events.set_visible(true);
                }

                scanner::ScanEvent::FolderStarted { folder } => {
                    
                    // Only imports should append rows immediately. Refreshing an
                    // existing library/folder after Refresh All was appending
                    // duplicate sidebar rows; right-clicking those stale rows
                    // could start another refresh against duplicated UI state.
                    if scan_job_for_events.borrow().kind == Some(ScanJobKind::Import) {
                        run_ui_guarded("sidebar folder append", || {
                            sidebar::append_folder(
                                &sidebar_for_events,
                                folder,
                                availability_refresh_for_events.clone(),
                            )
                        });
                    }
                }

                scanner::ScanEvent::DiscoveryProgress { found } => {
                    refresh_status_label_for_events
                        .set_text(&format!("Scanning… found {found} photos"));
                    refresh_status_box_for_events.set_visible(true);
                }

                scanner::ScanEvent::PhotosIndexed { photos, counts } => {
                    scan_count += photos.len();
                    photos_since_sidebar_update += photos.len();
                    pending_sidebar_counts = Some(*counts);

                    let search_active = !search_for_events.borrow().is_empty();
                    if !search_active {
                        for indexed in photos {
                            let photo = &indexed.photo;
                            if indexed.newly_discovered
                                && crate::image_format::path_is_enabled(
                                    &connection_for_events.borrow(),
                                    &photo.path,
                                )
                                && (matches!(filter_for_events.get(), sidebar::SidebarFilter::All)
                                    || matches!(filter_for_events.get(), sidebar::SidebarFilter::Folder(id) if Some(id) == photo.folder_id))
                            {
                                pending_photos.push_back(photo.clone());
                            } else if !indexed.newly_discovered {
                                gallery_for_events.update_photo(photo);
                                if selected_photo_for_events
                                    .borrow()
                                    .as_ref()
                                    .is_some_and(|selected| selected.id() == photo.id)
                                {
                                    let selected = selected_photo_for_events.borrow().clone();
                                    // Folder refreshes deliberately avoid a full
                                    // gallery rebuild. Keep an independently held
                                    // selected object current as well.
                                    if let Some(selected) = selected.as_ref() {
                                        selected.set_from_photo(photo);
                                    }
                                    info_for_events.set_photo(selected.as_ref());
                                }
                            }
                        }
                    }

                    if last_progress_update.elapsed() >= Duration::from_millis(150) {
                        let text = format!("Indexed {scan_count} photos");
                        refresh_status_label_for_events.set_text(&text);
                        refresh_status_box_for_events.set_visible(true);
                        last_progress_update = Instant::now();
                    }
                }

                scanner::ScanEvent::LibraryCountsChanged { counts } => {
                    pending_sidebar_counts = Some(*counts);
                    // Reconciliation and final snapshots should be visible on
                    // the next UI tick even when no photos needed reindexing.
                    photos_since_sidebar_update = photos_since_sidebar_update.max(50);
                }

                scanner::ScanEvent::IndexingFinished { imported } => {
                    if std::env::var_os("PICASA_TRACE").is_some() {
                        eprintln!(
                            "PIC_SCAN_UI indexing_finished queued_ms={} imported={} filter={:?}",
                            ui_event.queued_at.elapsed().as_millis(),
                            imported,
                            filter_for_events.get()
                        );
                    }
                    // Progressive imports append quickly; refresh jobs do one
                    // final rebuild after the whole serialized multi-folder job.
                    if !matches!(
                        scan_job_for_events.borrow().kind,
                        Some(ScanJobKind::Refresh | ScanJobKind::FolderRefresh)
                    ) {
                        refresh_grid(
                            &connection_for_events,
                            filter_for_events.get(),
                            &search_for_events.borrow(),
                            sort_for_events.get(),
                            &gallery_for_events,
                        );
                    }
                    let text = format!("Indexed {imported} photos");
                    refresh_status_label_for_events.set_text(&text);
                    refresh_status_box_for_events.set_visible(true);
                }

                scanner::ScanEvent::ThumbnailsDeferred { total } => {
                    thumbnail_recovery_deferred.set(*total > 0);
                    
                }
                scanner::ScanEvent::ThumbnailsStarted { total } => {
                    if std::env::var_os("PICASA_TRACE").is_some() {
                        eprintln!(
                            "PIC_SCAN_UI thumbnails_started queued_ms={} total={total}",
                            ui_event.queued_at.elapsed().as_millis()
                        );
                    }
                    
                    scan_count = 0;
                    thumbnail_total = *total;
                    refresh_status_label_for_events
                        .set_text(&format!("Creating thumbnails 0 / {total}"));
                    refresh_status_spinner_for_events.set_spinning(true);
                    refresh_status_box_for_events.set_visible(true);
                    stop_scan_for_events.set_visible(true);
                }

                scanner::ScanEvent::ThumbnailCreated { path } => {
                    scan_count += 1;
                    
                    // Coalesce source paths received in this timer tick and
                    // refresh only matching realized tiles. Non-realized rows
                    // will discover the new cache entry through the background
                    // presentation loader when they bind later.
                    if thumbnail_dirty_seen.insert(path.clone()) {
                        thumbnail_dirty_paths.push_back(path.clone());
                    }
                    if last_progress_update.elapsed() >= Duration::from_millis(150) {
                        let text = format!("Creating thumbnails {scan_count} / {thumbnail_total}");
                        refresh_status_label_for_events.set_text(&text);
                        refresh_status_box_for_events.set_visible(true);
                        last_progress_update = Instant::now();
                    }
                }

                scanner::ScanEvent::Failed { path, error } => {
                    eprintln!("SCAN FAILED: {}: {}", path.display(), error);
                    if !failure_message_shown {
                        failure_message_shown = true;
                        refresh_status_label_for_events
                            .set_text(&format!("Some files could not be added: {error}"));
                    } else {
                        refresh_status_label_for_events.set_text("Scanning… some files failed");
                    }
                    refresh_status_box_for_events.set_visible(true);
                }

                scanner::ScanEvent::Finished { imported, failed } => {
                    
                    eprintln!(
                        "===== SCAN COMPLETE: imported={} failed={} | progressive gallery updates complete =====",
                        imported,
                        failed
                    );

                    let (kind, has_more, total_imported, total_failed) = {
                        let mut job = scan_job_for_events.borrow_mut();
                        job.active = None;
                        job.imported_total += *imported;
                        job.failed_total += *failed;
                        (
                            job.kind,
                            !job.pending.is_empty(),
                            job.imported_total,
                            job.failed_total,
                        )
                    };

                    if kind == Some(ScanJobKind::Refresh) && has_more {
                        // Start exactly one next folder. Because scanner::Finished
                        // arrives after that folder's thumbnail pass, refresh
                        // progress remains serialized end-to-end.
                        start_next_scan_for_events();
                        continue;
                    }

                    // An entirely offline (or already cached) pass did no work.
                    // Leave it quiet while waiting for the next reconnect.
                    if kind == Some(ScanJobKind::Maintenance) && thumbnail_total == 0 {
                        scan_job_for_events.borrow_mut().kind = None;
                        continue;
                    }

                    if matches!(kind, Some(ScanJobKind::Refresh | ScanJobKind::FolderRefresh))
                        && !matches!(filter_for_events.get(), sidebar::SidebarFilter::Folder(_))
                    {
                        refresh_grid(
                            &connection_for_events,
                            filter_for_events.get(),
                            &search_for_events.borrow(),
                            sort_for_events.get(),
                            &gallery_for_events,
                        );
                    }

                    if kind != Some(ScanJobKind::FolderRefresh) {
                        crate::settings::refresh_library_availability_stats(
                            connection_for_events.clone(),
                        );
                    }

                    stop_scan_for_events.set_visible(false);
                    refresh_status_spinner_for_events.set_spinning(false);
                    let message = match kind {
                        Some(ScanJobKind::Refresh) => {
                            if total_failed == 0 {
                                format!("Library refresh complete · {total_imported} photos updated")
                            } else {
                                format!(
                                    "Library refresh complete · {total_imported} updated · {total_failed} failed"
                                )
                            }
                        }
                        Some(ScanJobKind::FolderRefresh) => {
                            if total_failed == 0 {
                                format!("Folder refresh complete · {total_imported} photos updated")
                            } else {
                                format!(
                                    "Folder refresh complete · {total_imported} updated · {total_failed} failed"
                                )
                            }
                        }
                        Some(ScanJobKind::Maintenance) => {
                            if total_failed == 0 {
                                if thumbnail_recovery_deferred.get() {
                                    "Available thumbnails recovered · waiting for offline sources".to_string()
                                } else {
                                    "Thumbnail recovery complete".to_string()
                                }
                            } else {
                                format!("Thumbnail recovery complete · {total_failed} failed")
                            }
                        }
                        _ => {
                            if total_failed == 0 {
                                format!("Added {total_imported} photos")
                            } else {
                                format!("Added {total_imported} photos · {total_failed} failed")
                            }
                        }
                    };
                    scan_job_for_events.borrow_mut().kind = None;
                    if kind != Some(ScanJobKind::FolderRefresh) {
                        availability_refresh_for_events();
                    }
                    
                    refresh_status_label_for_events.set_text(&message);
                    refresh_status_box_for_events.set_visible(true);
                    let panel = refresh_status_box_for_events.clone();
                    glib::timeout_add_local_once(Duration::from_millis(2500), move || {
                        panel.set_visible(false);
                    });
                }

                scanner::ScanEvent::Cancelled { imported } => {
                    let kind = {
                        let mut job = scan_job_for_events.borrow_mut();
                        job.active = None;
                        job.pending.clear();
                        job.imported_total += *imported;
                        let kind = job.kind;
                        job.kind = None;
                        kind
                    };
                    stop_scan_for_events.set_visible(false);
                    refresh_status_spinner_for_events.set_spinning(false);
                    let message = match kind {
                        Some(ScanJobKind::Refresh) => {
                            format!("Library refresh stopped · {imported} photos updated")
                        }
                        Some(ScanJobKind::FolderRefresh) => {
                            format!("Folder refresh stopped · {imported} photos updated")
                        }
                        _ => format!("Import stopped · {imported} photos added"),
                    };
                    
                    refresh_status_label_for_events.set_text(&message);
                    refresh_status_box_for_events.set_visible(true);
                    let panel = refresh_status_box_for_events.clone();
                    glib::timeout_add_local_once(Duration::from_millis(2500), move || {
                        panel.set_visible(false);
                    });
                }
            }
        }

        if displayed_generation.is_some()
            && displayed_generation != Some(scan_job_for_events.borrow().generation)
        {
            // A library switch or scan preemption invalidates already-drained
            // photo events as well as events still waiting in the channel.
            pending_photos.clear();
            pending_sidebar_counts = None;
            photos_since_sidebar_update = 0;
            displayed_generation = None;
        }
        if pending_sidebar_counts.is_some()
            && (photos_since_sidebar_update >= 50
                || last_sidebar_count_update.elapsed() >= Duration::from_millis(250))
        {
            if let Some(counts) = pending_sidebar_counts.take() {
                sidebar::update_library_counts(&sidebar_for_events, counts);
            }
            photos_since_sidebar_update = 0;
            last_sidebar_count_update = Instant::now();
        }

        const PHOTO_APPEND_BATCH: usize = 192;
        if !search_for_events.borrow().is_empty() {
            // Search results supersede progressive scan appends. The next
            // debounced refresh will replace the model from the DB.
            pending_photos.clear();
        }
        if !pending_photos.is_empty() {
            let mut batch = Vec::with_capacity(PHOTO_APPEND_BATCH.min(pending_photos.len()));
            for _ in 0..PHOTO_APPEND_BATCH {
                let Some(photo) = pending_photos.pop_front() else {
                    break;
                };
                batch.push(photo);
            }
            let append_started = Instant::now();
            let appended = batch.len();
            run_ui_guarded("photo batch append", || {
                gallery_for_events.append_photos(&batch)
            });
            if std::env::var_os("PICASA_TRACE").is_some()
                && append_started.elapsed() >= Duration::from_millis(20)
            {
                eprintln!(
                    "PIC_SCAN_UI photo_batch_append count={appended} elapsed_ms={}",
                    append_started.elapsed().as_millis()
                );
            }
            
        }
        for path in priority_thumbnail_paths.drain(..) {
            if thumbnail_dirty_seen.insert(path.clone()) {
                thumbnail_dirty_paths.push_back(path);
            }
        }
        const THUMBNAIL_REFRESH_BATCH: usize = 128;
        if !thumbnail_dirty_paths.is_empty() {
            let mut paths = Vec::with_capacity(THUMBNAIL_REFRESH_BATCH.min(thumbnail_dirty_paths.len()));
            for _ in 0..THUMBNAIL_REFRESH_BATCH {
                let Some(path) = thumbnail_dirty_paths.pop_front() else {
                    break;
                };
                thumbnail_dirty_seen.remove(&path);
                paths.push(path);
            }
            run_ui_guarded("targeted thumbnail refresh", || {
                if std::env::var_os("PICASA_TRACE").is_some(){eprintln!("PIC_THUMBNAIL tile_refresh count={}",paths.len());}
                gallery_for_events.refresh_thumbnails_for_paths(&paths)
            });
            
        }

        if std::env::var_os("PICASA_TRACE").is_some()
            && (ui_tick_started.elapsed() >= Duration::from_millis(100)
                || max_event_queue_wait >= Duration::from_millis(500))
        {
            eprintln!(
                "PIC_SCAN_UI tick elapsed_ms={} events={} max_queue_ms={} pending_photos={} thumbnail_progress={}/{} priority_pending={} filter={:?}",
                ui_tick_started.elapsed().as_millis(),
                handled_events,
                max_event_queue_wait.as_millis(),
                pending_photos.len(),
                scan_count,
                thumbnail_total,
                priority_pending,
                filter_for_events.get()
            );
        }
        glib::ControlFlow::Continue
    });

    switch_library_slot.replace(Some({
        let connection = connection.clone();
        let scan_job = scan_job.clone();
        let lightbox = lightbox.clone();
        let selected_photo = selected_photo.clone();
        let info = info.clone();
        let folder_cache = folder_cache.clone();
        let gallery = gallery.clone();
        let sidebar_slot = sidebar_for_unavailable.clone();
        let create_album = create_album.clone();
        let import_folder = import_folder.clone();
        let delete_album = delete_album.clone();
        let on_unavailable = availability_refresh.clone();
        let albums_refresh = albums_home_refresh_slot.clone();
        let filter = filter.clone();
        let search_text = search_text.clone();
        let search_entry = search_entry_slot.clone();
        let sort = sort.clone();
        let group_mode = group_mode.clone();
        let last_activated_photo_id = last_activated_photo_id.clone();
        let main_stack = main_stack.clone();
        let library_home = library_home;
        let rebuild_folder_watches = rebuild_folder_watches.clone();
        let theme_engine = theme_engine.clone();
        let window = window.clone();
        let refresh_status_box = refresh_status_box.clone();
        let refresh_status_spinner = refresh_status_spinner.clone();
        let stop_scan = stop_scan.clone();
        let settings_window = settings_window_for_switch.clone();
        Rc::new(move |id: &str| -> Result<(), String> {
            {
                let mut job = scan_job.borrow_mut();
                if let Some(active) = job.active.take() {
                    active.cancel();
                }
                job.generation = job.generation.wrapping_add(1);
                job.kind = None;
                job.pending.clear();
                job.stop_requested = true;
            }
            invalidate_pending_grid_navigation();
            invalidate_availability_refreshes();
            refresh_status_spinner.set_spinning(false);
            refresh_status_box.set_visible(false);
            stop_scan.set_visible(false);
            lightbox.close();

            let (library, new_connection) = db::select_library(id)
                .map_err(|error| format!("{error:#}"))?;
            let folders = db::folders(&new_connection).map_err(|error| error.to_string())?;
            let albums = db::albums(&new_connection).map_err(|error| error.to_string())?;
            let counts = db::sidebar_counts(&new_connection).unwrap_or_default();
            let new_filter = sidebar_filter_from_setting(
                db::setting(&new_connection, LAST_VIEW_SETTING_KEY)
                    .ok()
                    .flatten()
                    .as_deref(),
                &folders,
                &albums,
            );
            let new_sort = PhotoSort {
                field: SortField::from_key(
                    &db::setting(&new_connection, SORT_FIELD_SETTING_KEY)
                        .ok()
                        .flatten()
                        .unwrap_or_default(),
                ),
                direction: SortDirection::from_key(
                    &db::setting(&new_connection, SORT_DIRECTION_SETTING_KEY)
                        .ok()
                        .flatten()
                        .unwrap_or_default(),
                ),
            };
            let new_group = group_mode_from_key(
                &db::setting(&new_connection, GROUP_MODE_SETTING_KEY)
                    .ok()
                    .flatten()
                    .unwrap_or_default(),
            );
            let mut photos = match new_filter {
                sidebar::SidebarFilter::Library | sidebar::SidebarFilter::Albums => Vec::new(),
                sidebar::SidebarFilter::Album(album_id) => {
                    db::photos_in_album(&new_connection, album_id, None).unwrap_or_default()
                }
                sidebar::SidebarFilter::Favorites => {
                    db::photos(&new_connection, None, true, None).unwrap_or_default()
                }
                sidebar::SidebarFilter::History => {
                    db::history_photos(&new_connection).unwrap_or_default()
                }
                _ => db::photos(&new_connection, None, false, None).unwrap_or_default(),
            };
            retain_enabled_formats(&new_connection, &mut photos);
            limit_recently_added(&new_connection, new_filter, &mut photos);
            if matches!(new_filter, sidebar::SidebarFilter::Folder(_)) {
                let display_mode = sidebar::FolderDisplayMode::from_setting(
                    db::setting(&new_connection, sidebar::FOLDER_DISPLAY_MODE_SETTING_KEY)
                        .ok()
                        .flatten()
                        .as_deref(),
                );
                sort_folder_stream(&mut photos, &folders, new_sort, display_mode);
            } else if new_filter != sidebar::SidebarFilter::History {
                sort_photos(&mut photos, new_sort);
            }

            connection.replace(new_connection);
            folder_cache.replace(folders.clone());
            selected_photo.replace(None);
            info.set_photo(None);
            filter.set(new_filter);
            sort.set(new_sort);
            group_mode.set(new_group);
            last_activated_photo_id.set(numeric_setting::<i64>(
                &connection.borrow(),
                LAST_ACTIVATED_PHOTO_ID_SETTING_KEY,
            ));
            search_text.replace(String::new());
            if let Some(entry) = search_entry.borrow().as_ref() {
                entry.set_text("");
            }
            let display_mode = sidebar::FolderDisplayMode::from_setting(
                db::setting(&connection.borrow(), sidebar::FOLDER_DISPLAY_MODE_SETTING_KEY)
                    .ok()
                    .flatten()
                    .as_deref(),
            );
            gallery.set_folder_catalog(&folders, &folder_stream_order(&folders, display_mode));
            let square = crate::settings::saved_bool(
                &connection.borrow(),
                crate::db::THUMBNAIL_SQUARE_CORNERS_SETTING_KEY,
            )
            .unwrap_or(false);
            if square {
                window.add_css_class("square-corners");
            } else {
                window.remove_css_class("square-corners");
            }
            gallery.set_fit_whole_photo(
                crate::settings::saved_bool(
                    &connection.borrow(),
                    crate::db::THUMBNAIL_FIT_WHOLE_PHOTO_SETTING_KEY,
                )
                .unwrap_or(false),
            );
            gallery.set_show_file_names(
                crate::settings::saved_bool(
                    &connection.borrow(),
                    crate::db::THUMBNAIL_FILE_NAMES_SETTING_KEY,
                )
                .unwrap_or(false),
            );
            if let Some(width) = grid_thumbnail_size_from_setting(&connection.borrow()) {
                gallery.request_slider_zoom(width);
                info.grid_zoom.set_value(grid_zoom_slider_value(width));
            }
            apply_gallery_grouping(&gallery, new_filter, new_sort, new_group, true);
            gallery.replace(&photos);
            if let Some(sidebar) = sidebar_slot.borrow().as_ref() {
                sidebar::refresh(
                    sidebar,
                    &folders,
                    &albums,
                    counts,
                    create_album.clone(),
                    import_folder.clone(),
                    delete_album.clone(),
                    on_unavailable.clone(),
                );
                sidebar::set_active_filter(sidebar, new_filter);
                sidebar::apply_visibility(
                    sidebar,
                    sidebar::SidebarVisibility::from_connection(&connection.borrow()),
                );
            }
            if let Some(refresh) = albums_refresh.borrow().as_ref() {
                refresh(&albums);
            }
            library_home.reload(library.path.clone());
            main_stack.set_visible_child_name(if new_filter == sidebar::SidebarFilter::Library {
                "library"
            } else if new_filter == sidebar::SidebarFilter::Albums {
                "albums"
            } else {
                "photos"
            });
            theme_engine.reload_from_connection();
            rebuild_folder_watches();
            window.set_title(Some(&format!("PIC — {}", library.name)));
            settings_window.reset();
            Ok(())
        })
    }));

    // Persist the browsing destination and its viewport only after the user
    // confirms Exit. Destination changes are also written immediately in
    // layout.rs, so an abnormal process termination still restores the most
    // important part of the session.
    install_close_confirmation(&window, {
        let connection = connection.clone();
        let filter = filter.clone();
        let gallery = gallery.clone();
        let albums_home = albums_home.clone();
        let main_split = main_split.clone();
        let window = window.clone();
        Rc::new(move || {
            let guard = connection.borrow();
            let current_filter = filter.get();
            let _ = db::set_setting(
                &guard,
                LAST_VIEW_SETTING_KEY,
                &sidebar_filter_setting(current_filter),
            );

            if current_filter == sidebar::SidebarFilter::Albums {
                let _ = db::set_setting(
                    &guard,
                    LAST_ALBUMS_SCROLL_SETTING_KEY,
                    &albums_home.vadjustment().value().to_string(),
                );
            } else {
                let scroll_y = gallery.scroll_position();
                let anchor_id = gallery.viewport_center_photo().map(|photo| photo.id());
                let _ = db::set_setting(
                    &guard,
                    LAST_VIEW_SCROLL_SETTING_KEY,
                    &scroll_y.to_string(),
                );
                if let Some(photo_id) = anchor_id {
                    let _ = db::set_setting(
                        &guard,
                        LAST_VIEW_PHOTO_ID_SETTING_KEY,
                        &photo_id.to_string(),
                    );
                } else {
                    let _ = db::delete_setting(&guard, LAST_VIEW_PHOTO_ID_SETTING_KEY);
                }
            }

            let maximized = window.is_maximized();
            let _ = db::set_setting(
                &guard,
                WINDOW_MAXIMIZED_SETTING_KEY,
                if maximized { "true" } else { "false" },
            );
            if !maximized {
                let _ = db::set_setting(
                    &guard,
                    WINDOW_WIDTH_SETTING_KEY,
                    &window.width().to_string(),
                );
                let _ = db::set_setting(
                    &guard,
                    WINDOW_HEIGHT_SETTING_KEY,
                    &window.height().to_string(),
                );
            }
            let _ = db::set_setting(
                &guard,
                SIDEBAR_WIDTH_FRACTION_SETTING_KEY,
                &main_split.sidebar_width_fraction().to_string(),
            );
        })
    });

    window
}
